Instructions for Assignment 5
========================

- In the file `assignment5.v` you will fill in your answers.

- The supplementary file `miniML.v` includes the
  definitions of the miniML language.

- Deliverable: The file `assignment5.v`

- Attention: Fill in your answers only in these files.

- In order to compile the project:

  - On Linux/macOS operating system or on Windows via WSL:

    1. From a terminal open the directory `assignment5`.
    2. Execute the command `make`.
    3. Open the file in your IDE.
       VSCode:
       - Open the directory `assignment5` from within VSCode (File > Open Folder).
       - Select the file `assignment5.v`.
       - The command `From Assignment5 Require Import miniML.` at the beginning of the file should
         succeed.

       Emacs:
       - Open the file `assignment5.v` from within the directory `assignment5`.
       - The command `From Assignment5 Require Import miniML.` at the beginning of the file should
         succeed.

    4. Complete the assignment.

  - On Windows operating system with CoqIDE

    1. Open the file `miniML.v` in CoqIDE. In the Compile menu press
       the option Compile Buffer.
    2. Open the file `assignment5.v` in CoqIDE. The command `From Assignment5
       Require Import miniML.` at the beginning of the file should succeed.
    3. Complete the assignment.
