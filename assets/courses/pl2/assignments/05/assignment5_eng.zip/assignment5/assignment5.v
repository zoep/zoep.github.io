From Stdlib Require Import Strings.String Arith.Arith Lists.List Lia.

Import ListNotations.

Require Import miniML.

Open Scope ML_scope.

(** Student Information
Name:
Student ID:
*)


(** * Assignment 5 (105 points) *)

(** In this assignment you will extend the simply typed lambda
    calculus of the course notes with a fixed-point operator,
    references and errors, and you will prove type safety for the
    extended language.

    Instructions:

    - The submitted file must compile. Files that do not compile will
      not be graded. If you cannot complete a proof, use [admit] for
      the unfinished cases and end the proof with [Admitted].

    - Do not change the code that has been given to you. Do not write
      inside the grading comments. This is necessary for smooth and
      timely grading of assignments. You can write where the
      instruction (* ___ FILL IN HERE ___ *) appears. If it helps, you
      can define helper functions, lemmas, definitions, etc.

    - Add your rules to the definitions of [value], [step] and
      [has_type] at the places marked with (* ___ FILL IN HERE ___ *),
      after the given rules, and use the rule names that the exercises
      specify. Do not change these names. After you complete the
      rules, you should complete the type safety proofs.

    - **Do not change the names of the files**. Write your answers
      only in this file.

    - Fill in your information correctly at the beginning of the file.
      This is necessary for correct grading of assignments. *)

(** ** The language *)

(** The file [miniML.v] contains the syntax of the language. Compared
    to the notes, the language has the following new constructs:

      Types:  A ::= ... | Ref A
      Terms:  t ::= ... | fix t | ref t | !t | t1 ::= t2 | loc l | error | t1 / t2

    - [fix t] is the fixed-point operator (Exercise 1).

    - [ref t] allocates a new memory location and stores the value of
      [t] in it. [!t] returns the value stored at the location [t].
      [t1 ::= t2] stores the value of [t2] at the location [t1] and
      returns [unit] (Exercises 2 and 3).

    - [loc l] is the memory location [l]. Locations do not appear in
      surface syntax. They are created by [ref t] during evaluation.

    - [error] is a run-time error (Exercise 4). When a subterm that is
      being evaluated becomes [error], the whole term becomes [error].

    - [t1 / t2] is the division of natural numbers (Exercise 4.4).

    The store [s] is a list of values: the value at location [l] is
    [nth_error s l], and a new location is allocated at the end of the
    list, i.e., at position [length s] (see [miniML.v]).

    The operational semantics is a relation between configurations
    [t / s], which denote a term [t] together with a store [s].

      t / s --> t' / s'

    The typing judgment is extended with a store typing [Sigma], which
    is a list of types that gives the type of each location.

      Sigma ; Gamma ⊢ t : A

    The definitions and proofs of the notes are given below, adapted to
    stores and store typings.
 *)

(** ** Exercises *)

(** *** Exercise 1: Fixed-point operator and let rec (15 points) *)

(** In the untyped lambda calculus we can define recursion with a
    fixed-point combinator (e.g., Y, Z or Θ). Such combinators
    cannot be typed in the simply typed lambda calculus. Instead, we
    add a primitive operator [fix] that behaves like a fixed-point
    combinator: [fix (fun f : A -> t)] unfolds to the body [t], where
    the recursive calls [f] refer to [fix (fun f : A -> t)] itself.
    You may find "Types and Programming Languages" (Section 11.11)
    useful.

    1.1 (6 points) Add the evaluation rules of [fix] to [step]:
        [Step_FixAbs] (the unfolding of [fix (fun f : A -> t)]) and
        [Step_Fix] (evaluation of the argument of [fix]). Add the
        typing rule [Ty_Fix] to [has_type].

    1.2 (9 points) Define let rec as a derived form, using [fix], and
        prove its typing rule (lemma [letrec_typing]). *)

(** *** Exercise 2: References (25 points) *)

(** 2.1 Which of the new terms are values? Add the necessary rule to
    the [value] predicate and name it [V_New].

    2.2 Add the evaluation rules of references to [step]:
        - [Step_RefValue] (allocation) and [Step_Ref],
        - [Step_DerefLoc] (reading a location) and [Step_Deref],
        - [Step_Assign] (writing a location), [Step_Assign1] and
          [Step_Assign2].
        As for the other constructs, subterms are evaluated from left
        to right. Use [length], [++], [nth_error] and [replace] (see
        [miniML.v]) for the store.

    2.3 Add the typing rules [Ty_Loc], [Ty_Ref], [Ty_Deref] and
        [Ty_Assign] to [has_type]. *)

(** *** Exercise 3: Lemmas about stores (20 points) *)

(** Prove the lemmas [extends_snoc], [store_weakening],
    [store_well_typed_alloc], [store_well_typed_assign] and
    [canonical_forms_ref] below. *)

(** *** Exercise 4: Errors (20 points) *)

(** The rules that pass an error up through the constructs of the notes
    are given ([Step_AppErr1], [Step_AppErr2], etc.).

    4.1 (5 points) Add the corresponding rules for the new constructs:
        [Step_FixErr], [Step_RefErr], [Step_DerefErr], [Step_AssignErr1]
        and [Step_AssignErr2]. Add the typing rule [Ty_Error] to
        [has_type].

    4.2 (5 points) The statement of progress from the notes no longer
        holds. Prove it (lemma [progress_old_false]).

    4.3 (5 points) Write the correct statement of progress (theorem
        [progress]).

    4.4 (5 points) Division [t1 / t2] of natural numbers (operator
        [Div] in [miniML.v]) has no rules yet. Add the typing rule
        [Ty_Div] to [has_type] and the evaluation rules [Step_Div] and
        [Step_DivZero] to [step], so that division by zero is a trapped
        error, that is, it evaluates to [error]. *)

(** *** Exercise 5: Type safety (25 points) *)

(** 5.1 (10 points) Complete the proof of [progress].

    5.2 (15 points) Complete the proof of [preservation]. *)

(** ** Values *)

Inductive value : term -> Prop :=
(* Functions *)
| V_Fun :
  forall x T t,
    value <[ fun x : T -> t ]>
(* Natural Numbers *)
| V_Nat :
  forall (n : nat),
    value <[ n ]>
(* Booleans *)
| V_Bool :
  forall (b : bool),
    value <[ b ]>
(* Unit *)
| V_Unit :
    value <[ unit ]>
(* Sums *)
| V_Inl : forall v T1,
    value v ->
    value <[ inl T1 v ]>
| V_Inr : forall v T1,
    value v ->
    value <[ inr T1 v ]>
(* Pairs *)
| V_Pair : forall v1 v2,
    value v1 ->
    value v2 ->
    value <[ (v1, v2) ]>
(* Exercise 2.1 *)
(* ___ FILL IN HERE ___ *)
(* [value] grade 0/3 *)
.

(** ** Operational Semantics *)

Reserved Notation "t '/' s '-->' t' '/' s'"
  (at level 40, s at next level, t' at next level, left associativity).

Inductive step : term * store -> term * store -> Prop :=
(* pure STLC *)
| Step_AppAbs : forall x T2 t1 v2 s,
    value v2 ->
    <[ (fun x : T2 -> t1) v2 ]> / s --> <[ [x:=v2]t1 ]> / s
| Step_App1 : forall t1 t1' t2 s s',
    t1 / s --> t1' / s' ->
    <[ t1 t2 ]> / s --> <[ t1' t2 ]> / s'
| Step_App2 : forall v1 t2 t2' s s',
    value v1 ->
    t2 / s --> t2' / s' ->
    <[ v1 t2 ]> / s --> <[ v1 t2' ]> / s'
(* Let *)
| Step_LetVal : forall y v1 t2 s,
    value v1 ->
    <[ let y := v1 in t2 ]> / s --> <[ [y := v1] t2 ]> / s
| Step_Let : forall y t1 t1' t2 s s',
    t1 / s --> t1' / s' ->
    <[ let y := t1 in t2 ]> / s --> <[ let y := t1' in t2 ]> / s'
(* If then else *)
| Step_IfTrue : forall t1 t2 s,
    <[ if true then t1 else t2 ]> / s --> t1 / s
| Step_IfFalse : forall t1 t2 s,
    <[ if false then t1 else t2 ]> / s --> t2 / s
| Step_If : forall t t' t1 t2 s s',
    t / s --> t' / s' ->
    <[ if t then t1 else t2 ]> / s --> <[ if t' then t1 else t2 ]> / s'
(* Binary Operators *)
| Step_BOpNat : forall bop (n1 n2 : nat) bop_f s,
    nat_op bop = Some bop_f ->
    (T_BOp bop n1 n2) / s --> T_Nat (bop_f n1 n2) / s
| Step_BOpBool : forall bop (b1 b2 : bool) bop_f s,
    bool_op bop = Some bop_f ->
    (T_BOp bop b1 b2) / s --> T_Bool (bop_f b1 b2) / s
| Step_BOpCmp : forall bop (n1 n2 : nat) bop_f s,
    cmp_op bop = Some bop_f ->
    (T_BOp bop n1 n2) / s --> T_Bool (bop_f n1 n2) / s
| Step_Bop1 : forall bop t1 t1' t2 s s',
    t1 / s --> t1' / s' ->
    (T_BOp bop t1 t2) / s --> (T_BOp bop t1' t2) / s'
| Step_Bop2 : forall bop v1 t2 t2' s s',
    value v1 ->
    t2 / s --> t2' / s' ->
    (T_BOp bop v1 t2) / s --> (T_BOp bop v1 t2') / s'
(* Unary Operators *)
| Step_UOpBool : forall (b : bool) s,
    (T_UOp Neg b) / s --> T_Bool (negb b) / s
| Step_UOp : forall t t' s s',
    t / s --> t' / s' ->
    (T_UOp Neg t) / s --> (T_UOp Neg t') / s'
(* Pairs *)
| Step_Pair1 : forall t1 t1' t2 s s',
    t1 / s --> t1' / s' ->
    <[ (t1, t2) ]> / s --> <[ (t1', t2) ]> / s'
| Step_Pair2 : forall v1 t2 t2' s s',
    value v1 ->
    t2 / s --> t2' / s' ->
    <[ (v1, t2) ]> / s --> <[ (v1, t2') ]> / s'
| Step_FstPair : forall v1 v2 s,
    value v1 -> value v2 ->
    <[ (v1, v2).1 ]> / s --> v1 / s
| Step_Fst : forall t t' s s',
    t / s --> t' / s' ->
    <[ t.1 ]> / s --> <[ t'.1 ]> / s'
| Step_SndPair : forall v1 v2 s,
    value v1 -> value v2 ->
    <[ (v1, v2).2 ]> / s --> v2 / s
| Step_Snd : forall t t' s s',
    t / s --> t' / s' ->
    <[ t.2 ]> / s --> <[ t'.2 ]> / s'
(* Sums *)
| Step_Inl : forall t1 t1' T2 s s',
    t1 / s --> t1' / s' ->
    <[ inl T2 t1 ]> / s --> <[ inl T2 t1' ]> / s'
| Step_Inr : forall t2 t2' T1 s s',
    t2 / s --> t2' / s' ->
    <[ inr T1 t2 ]> / s --> <[ inr T1 t2' ]> / s'
| Step_Case : forall t t' x1 t1 x2 t2 s s',
    t / s --> t' / s' ->
    <[ case t of | inl x1 => t1 | inr x2 => t2 ]> / s -->
    <[ case t' of | inl x1 => t1 | inr x2 => t2 ]> / s'
| Step_CaseInl : forall v x1 t1 x2 t2 T2 s,
    value v ->
    <[ case inl T2 v of | inl x1 => t1 | inr x2 => t2 ]> / s --> <[ [x1:=v]t1 ]> / s
| Step_CaseInr : forall v x1 t1 x2 t2 T1 s,
    value v ->
    <[ case inr T1 v of | inl x1 => t1 | inr x2 => t2 ]> / s --> <[ [x2:=v]t2 ]> / s
(* Errors *)
| Step_AppErr1 : forall t2 s,
    <[ error t2 ]> / s --> <[ error ]> / s
| Step_AppErr2 : forall v1 s,
    value v1 ->
    <[ v1 error ]> / s --> <[ error ]> / s
| Step_LetErr : forall y t2 s,
    <[ let y := error in t2 ]> / s --> <[ error ]> / s
| Step_IfErr : forall t1 t2 s,
    <[ if error then t1 else t2 ]> / s --> <[ error ]> / s
| Step_BopErr1 : forall bop t2 s,
    (T_BOp bop <[ error ]> t2) / s --> <[ error ]> / s
| Step_BopErr2 : forall bop v1 s,
    value v1 ->
    (T_BOp bop v1 <[ error ]>) / s --> <[ error ]> / s
| Step_UOpErr : forall s,
    (T_UOp Neg <[ error ]>) / s --> <[ error ]> / s
| Step_PairErr1 : forall t2 s,
    <[ (error, t2) ]> / s --> <[ error ]> / s
| Step_PairErr2 : forall v1 s,
    value v1 ->
    <[ (v1, error) ]> / s --> <[ error ]> / s
| Step_FstErr : forall s,
    <[ error.1 ]> / s --> <[ error ]> / s
| Step_SndErr : forall s,
    <[ error.2 ]> / s --> <[ error ]> / s
| Step_InlErr : forall T2 s,
    <[ inl T2 error ]> / s --> <[ error ]> / s
| Step_InrErr : forall T1 s,
    <[ inr T1 error ]> / s --> <[ error ]> / s
| Step_CaseErr : forall x1 t1 x2 t2 s,
    <[ case error of | inl x1 => t1 | inr x2 => t2 ]> / s --> <[ error ]> / s
(* Exercise 1.1: fix *)
(* ___ FILL IN HERE ___ *)
(* [step_fix] grade 0/3 *)
(* Exercise 2.2: references *)
(* ___ FILL IN HERE ___ *)
(* [step_ref] grade 0/12 *)
(* Exercise 4.1: errors *)
(* ___ FILL IN HERE ___ *)
(* [step_error] grade 0/3 *)
(* Exercise 4.4: division *)
(* ___ FILL IN HERE ___ *)
(* [step_div] grade 0/3 *)

where "t '/' s '-->' t' '/' s'" := (step (@pair term store t s) (@pair term store t' s')).

Notation "t '/' s '-->*' t' '/' s'" := (multi step (@pair term store t s) (@pair term store t' s'))
  (at level 40, s at next level, t' at next level, left associativity).

(** ** Typing *)

Reserved Notation "Sigma ';' Gamma '⊢' t ':' T"
  (at level 40, t custom ML, T custom ML_ty at level 0).

Inductive has_type (Sigma : store_ty) : context -> term -> type -> Prop :=
  (* Pure STLC *)
  | Ty_Var : forall Gamma x A,
      Gamma x = Some A ->
      Sigma ; Gamma ⊢ x : A
  | Ty_Abs : forall Gamma x t A B,
      Sigma ; (x |-> A ; Gamma) ⊢ t : B ->
      Sigma ; Gamma ⊢ (fun x : A -> t) : (A -> B)
  | Ty_App : forall Gamma t1 t2 A B,
      Sigma ; Gamma ⊢ t1 : (A -> B) ->
      Sigma ; Gamma ⊢ t2 : A ->
      Sigma ; Gamma ⊢ t1 t2 : B
  (* Let *)
  | Ty_Let : forall Gamma x t1 t2 A B,
      Sigma ; Gamma ⊢ t1 : A ->
      Sigma ; (x |-> A ; Gamma) ⊢ t2 : B ->
      Sigma ; Gamma ⊢ (let x := t1 in t2) : B
  (* Bools *)
  | Ty_Bool : forall Gamma (b : bool),
      Sigma ; Gamma ⊢ b : Bool
  | Ty_If : forall Gamma t1 t2 t3 A,
      Sigma ; Gamma ⊢ t1 : Bool ->
      Sigma ; Gamma ⊢ t2 : A ->
      Sigma ; Gamma ⊢ t3 : A ->
      Sigma ; Gamma ⊢ if t1 then t2 else t3 : A
  | Ty_BopBool : forall Gamma bop t1 t2,
      Sigma ; Gamma ⊢ t1 : Bool ->
      Sigma ; Gamma ⊢ t2 : Bool ->
      is_bool_op bop = true ->
      Sigma ; Gamma ⊢ { T_BOp bop t1 t2 } : Bool
  | Ty_UOp : forall Gamma uop t1,
      Sigma ; Gamma ⊢ t1 : Bool ->
      Sigma ; Gamma ⊢ { T_UOp uop t1 } : Bool
  (* Numbers *)
  | Ty_Nat : forall Gamma (n : nat),
      Sigma ; Gamma ⊢ n : Nat
  | Ty_BopNat : forall Gamma bop t1 t2,
      Sigma ; Gamma ⊢ t1 : Nat ->
      Sigma ; Gamma ⊢ t2 : Nat ->
      is_nat_op bop = true ->
      Sigma ; Gamma ⊢ { T_BOp bop t1 t2 } : Nat
  | Ty_BopCmp : forall Gamma bop t1 t2,
      Sigma ; Gamma ⊢ t1 : Nat ->
      Sigma ; Gamma ⊢ t2 : Nat ->
      is_cmp_op bop = true ->
      Sigma ; Gamma ⊢ { T_BOp bop t1 t2 } : Bool
  (* Pairs *)
  | Ty_Pair : forall Gamma t1 t2 A B,
      Sigma ; Gamma ⊢ t1 : A ->
      Sigma ; Gamma ⊢ t2 : B ->
      Sigma ; Gamma ⊢ (t1, t2) : (A * B)
  | Ty_Fst : forall Gamma t1 A B,
      Sigma ; Gamma ⊢ t1 : (A * B) ->
      Sigma ; Gamma ⊢ t1.1 : A
  | Ty_Snd : forall Gamma t1 A B,
      Sigma ; Gamma ⊢ t1 : (A * B) ->
      Sigma ; Gamma ⊢ t1.2 : B
  (* Sums *)
  | Ty_Inl : forall Gamma t1 A B,
      Sigma ; Gamma ⊢ t1 : A ->
      Sigma ; Gamma ⊢ (inl B t1) : (A + B)
  | Ty_Inr : forall Gamma t2 A B,
      Sigma ; Gamma ⊢ t2 : B ->
      Sigma ; Gamma ⊢ (inr A t2) : (A + B)
  | Ty_Case : forall Gamma t x1 A t1 x2 B t2 C,
      Sigma ; Gamma ⊢ t : (A + B) ->
      Sigma ; (x1 |-> A ; Gamma) ⊢ t1 : C ->
      Sigma ; (x2 |-> B ; Gamma) ⊢ t2 : C ->
      Sigma ; Gamma ⊢ (case t of | inl x1 => t1 | inr x2 => t2) : C
  (* Unit *)
  | Ty_Unit : forall Gamma,
      Sigma ; Gamma ⊢ unit : Unit
  (* Exercise 1.1: fix *)
  (* ___ FILL IN HERE ___ *)
  (* [typing_fix] grade 0/3 *)
  (* Exercise 2.3: references *)
  (* ___ FILL IN HERE ___ *)
  (* [typing_ref] grade 0/10 *)
  (* Exercise 4.1: errors *)
  (* ___ FILL IN HERE ___ *)
  (* [typing_error] grade 0/2 *)
  (* Exercise 4.4: division *)
  (* ___ FILL IN HERE ___ *)
  (* [typing_div] grade 0/2 *)

where "Sigma ';' Gamma '⊢' t ':' T" := (has_type Sigma Gamma t T).

#[global] Hint Constructors value : core.
#[global] Hint Constructors step : core.
#[global] Hint Constructors has_type : core.

(** ** Store typing *)

(** [extends Sigma' Sigma]: every location that has a type in [Sigma]
    has the same type in [Sigma']. *)
Definition extends (Sigma' Sigma : store_ty) : Prop :=
  forall l T, nth_error Sigma l = Some T -> nth_error Sigma' l = Some T.

Lemma extends_refl : forall Sigma, extends Sigma Sigma.
Proof. unfold extends. auto. Qed.

#[global] Hint Resolve extends_refl : core.

(** A store [s] is well typed with respect to a store typing [Sigma] if
    they have the same locations, and the value stored at each location
    has the type that [Sigma] gives to the location. *)
Definition store_well_typed (Sigma : store_ty) (s : store) : Prop :=
  length s = length Sigma /\
  (forall l v T,
      nth_error s l = Some v ->
      nth_error Sigma l = Some T ->
      Sigma ; empty ⊢ v : T).

(** ** Exercise 1.2: let rec as a derived form *)

(** [let rec f (x : A) : B := t1 in t2] defines a recursive function
    [f] with an argument [x] of type [A] and result type [B], whose body
    is [t1]. The function [f] can be used in [t1] and in [t2].

    Define [letrec f x A B t1 t2] using [fix]. *)

Definition letrec (f x : string) (A B : type) (t1 t2 : term) : term
  (* := ___ FILL IN HERE ___ *).
Admitted.

(* [letrec] grade 0/4 *)

Notation "'let' 'rec' f '(' x ':' T1 ')' ':' T2 ':=' y 'in' z" :=
  (letrec f x T1 T2 y z)
    (in custom ML at level 90,
        f at level 0,
        x at level 0,
        T1 custom ML_ty at level 99,
        T2 custom ML_ty at level 99,
        y custom ML at level 100,
        z custom ML at level 100, left associativity) : ML_scope.

(** Prove the typing rule of let rec. *)

Lemma letrec_typing : forall Sigma Gamma f x A B C t1 t2,
    Sigma ; (x |-> A ; f |-> <[[ A -> B ]]> ; Gamma) ⊢ t1 : B ->
    Sigma ; (f |-> <[[ A -> B ]]> ; Gamma) ⊢ t2 : C ->
    Sigma ; Gamma ⊢ (let rec f (x : A) : B := t1 in t2) : C.
Proof.
  (* ___ FILL IN HERE ___ *)
Admitted.

(* [letrec_typing] grade 0/5 *)

(** ** Exercise 3: Lemmas about stores *)

(** Allocation does not change the types of the existing locations. *)
Lemma extends_snoc : forall Sigma A,
    extends (Sigma ++ [A]) Sigma.
Proof.
  (* ___ FILL IN HERE ___ *)
Admitted.

(* [extends_snoc] grade 0/3 *)

(** Typing is preserved when the store typing grows. *)
Lemma store_weakening : forall Sigma Sigma' Gamma t A,
    extends Sigma' Sigma ->
    Sigma ; Gamma ⊢ t : A ->
    Sigma' ; Gamma ⊢ t : A.
Proof.
  (* ___ FILL IN HERE ___ *)
Admitted.

(* [store_weakening] grade 0/4 *)

(** Allocation keeps the store well typed. *)
Lemma store_well_typed_alloc : forall Sigma s v A,
    store_well_typed Sigma s ->
    Sigma ; empty ⊢ v : A ->
    store_well_typed (Sigma ++ [A]) (s ++ [v]).
Proof.
  (* ___ FILL IN HERE ___ *)
Admitted.

(* [store_well_typed_alloc] grade 0/5 *)

(** Assignment keeps the store well typed. *)
Lemma store_well_typed_assign : forall Sigma s l v A,
    store_well_typed Sigma s ->
    nth_error Sigma l = Some A ->
    Sigma ; empty ⊢ v : A ->
    store_well_typed Sigma (replace l v s).
Proof.
  (* ___ FILL IN HERE ___ *)
Admitted.

(* [store_well_typed_assign] grade 0/5 *)

(** ** Canonical Forms *)

Lemma canonical_forms_bool : forall Sigma t,
    Sigma ; empty ⊢ t : Bool ->
    value t ->
    (t = <[ true ]>) \/ (t = <[ false ]>).
Proof.
  intros Sigma t Htyp Hval.
  inv Hval; inv Htyp.
  destruct b; auto.
Qed.

Lemma canonical_forms_nat : forall Sigma t,
    Sigma ; empty ⊢ t : Nat ->
    value t ->
    exists (n : nat), t = <[ n ]>.
Proof.
  intros Sigma t Htyp Hval.
  inv Hval; inv Htyp. eauto.
Qed.

Lemma canonical_forms_fun : forall Sigma t A B,
    Sigma ; empty ⊢ t : (A -> B) ->
    value t ->
    exists x u, t = <[ fun x : A -> u ]>.
Proof.
  intros Sigma t A B Htyp Hval.
  inv Hval; inv Htyp. eauto.
Qed.

Lemma canonical_forms_sum : forall Sigma t A B,
    Sigma ; empty ⊢ t : (A + B) ->
    value t ->
    (exists v, t = <[ inl B v ]> /\ value v) \/
    (exists v, t = <[ inr A v ]> /\ value v).
Proof.
  intros Sigma t A B Htyp Hval.
  inv Hval; inv Htyp; eauto.
Qed.

Lemma canonical_forms_prod : forall Sigma t A B,
    Sigma ; empty ⊢ t : (A * B) ->
    value t ->
    exists v1 v2, t = <[ (v1, v2) ]> /\ value v1 /\ value v2.
Proof.
  intros Sigma t A B Htyp Hval.
  inv Hval; inv Htyp; eauto.
Qed.

(** Exercise 3 *)
Lemma canonical_forms_ref : forall Sigma t A,
    Sigma ; empty ⊢ t : (Ref A) ->
    value t ->
    exists l, t = <[ loc l ]>.
Proof.
  (* ___ FILL IN HERE ___ *)
Admitted.

(* [canonical_forms_ref] grade 0/3 *)

(** ** Progress *)

(** *** Exercise 4.2 *)

(** The statement of progress from the notes, adapted to stores. *)
Definition progress_old : Prop :=
  forall t T Sigma s,
    Sigma ; empty ⊢ t : T ->
    store_well_typed Sigma s ->
    value t \/ exists t' s', t / s --> t' / s'.

(** Prove that it does not hold. *)
Lemma progress_old_false : ~ progress_old.
Proof.
  (* ___ FILL IN HERE ___ *)
Admitted.

(* [progress_old_false] grade 0/5 *)

(** *** Exercises 4.3 and 5.1 *)

(** Replace [True] with the correct conclusion of progress (Exercise
    4.3). Do not change the rest of the statement.

    The proof of the cases for the constructs of the notes is given
    below, in a comment. It is written for the correct statement. After
    you write the statement:
    1. delete [Admitted] and the comment marks around the given proof,
    2. add the cases for your new typing rules (Exercise 5.1). *)

Theorem progress : forall t T Sigma s,
    Sigma ; empty ⊢ t : T ->
    store_well_typed Sigma s ->
    (* ___ FILL IN HERE ___ *)
    True.
Proof.
Admitted.
(*
Proof.
  intros t T Sigma s Ht Hst.
  remember empty as Gamma.
  induction Ht; subst.
  - (* Ty_Var *)
    discriminate H.
  - (* Ty_Abs *)
    left. constructor.
  - (* Ty_App *)
    right. right.
    destruct IHHt1 as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    destruct IHHt2 as [Hv2 | [-> | [t2' [s2' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    destruct (canonical_forms_fun Sigma t1 A B Ht1 Hv1) as [x [u ->]].
    eauto.
  - (* Ty_Let *)
    right. right.
    destruct IHHt1 as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | now eauto | now eauto | now eauto ].
  - (* Ty_Bool *)
    left. constructor.
  - (* Ty_If *)
    right. right.
    destruct IHHt1 as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    destruct (canonical_forms_bool Sigma t1 Ht1 Hv1) as [-> | ->]; eauto.
  - (* Ty_BopBool *)
    right. right.
    destruct IHHt1 as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    destruct IHHt2 as [Hv2 | [-> | [t2' [s2' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    edestruct is_bool_op_lemma as [f Hf]; [ eassumption | ].
    destruct (canonical_forms_bool Sigma t1 Ht1 Hv1) as [-> | ->];
      destruct (canonical_forms_bool Sigma t2 Ht2 Hv2) as [-> | ->]; eauto.
  - (* Ty_UOp *)
    right. right.
    (* [Neg] is the only unary operator *)
    match goal with |- context [ T_UOp ?op _ ] => destruct op end.
    destruct IHHt as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    destruct (canonical_forms_bool Sigma t1 Ht Hv1) as [-> | ->]; eauto.
  - (* Ty_Nat *)
    left. constructor.
  - (* Ty_BopNat *)
    right. right.
    destruct IHHt1 as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    destruct IHHt2 as [Hv2 | [-> | [t2' [s2' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    edestruct is_nat_op_lemma as [f Hf]; [ eassumption | ].
    destruct (canonical_forms_nat Sigma t1 Ht1 Hv1) as [n1 ->].
    destruct (canonical_forms_nat Sigma t2 Ht2 Hv2) as [n2 ->].
    eauto.
  - (* Ty_BopCmp *)
    right. right.
    destruct IHHt1 as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    destruct IHHt2 as [Hv2 | [-> | [t2' [s2' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    edestruct is_cmp_op_lemma as [f Hf]; [ eassumption | ].
    destruct (canonical_forms_nat Sigma t1 Ht1 Hv1) as [n1 ->].
    destruct (canonical_forms_nat Sigma t2 Ht2 Hv2) as [n2 ->].
    eauto.
  - (* Ty_Pair *)
    destruct IHHt1 as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | | right; right; now eauto | right; right; now eauto ].
    destruct IHHt2 as [Hv2 | [-> | [t2' [s2' Hstp]]]];
      [ reflexivity | left; now eauto | right; right; now eauto | right; right; now eauto ].
  - (* Ty_Fst *)
    right. right.
    destruct IHHt as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    destruct (canonical_forms_prod Sigma t1 A B Ht Hv1) as [v1 [v2 [-> [Hv1' Hv2']]]].
    eauto.
  - (* Ty_Snd *)
    right. right.
    destruct IHHt as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    destruct (canonical_forms_prod Sigma t1 A B Ht Hv1) as [v1 [v2 [-> [Hv1' Hv2']]]].
    eauto.
  - (* Ty_Inl *)
    destruct IHHt as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | left; now eauto | right; right; now eauto | right; right; now eauto ].
  - (* Ty_Inr *)
    destruct IHHt as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | left; now eauto | right; right; now eauto | right; right; now eauto ].
  - (* Ty_Case *)
    right. right.
    destruct IHHt1 as [Hv | [-> | [t' [s' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    destruct (canonical_forms_sum Sigma t A B Ht1 Hv) as [[v [-> Hv']] | [v [-> Hv']]];
      eauto.
  - (* Ty_Unit *)
    left. constructor.
  (* Exercise 5.1 *)
  (* ___ FILL IN HERE ___ *)
Qed.
*)

(* [progress_statement] grade 0/5 *)

(* [progress] grade 0/10 *)

(** ** Weakening *)

Lemma weakening : forall Sigma Gamma Gamma' t A,
    submap Gamma Gamma' ->
    Sigma ; Gamma ⊢ t : A ->
    Sigma ; Gamma' ⊢ t : A.
Proof.
  intros Sigma Gamma Gamma' t A Hsub Ht.
  revert Gamma' Hsub.
  induction Ht; eauto 7 using submap_update.
Qed.

Corollary weakening_empty : forall Sigma Gamma t A,
    Sigma ; empty ⊢ t : A ->
    Sigma ; Gamma ⊢ t : A.
Proof.
  intros Sigma Gamma t A.
  eapply weakening.
  discriminate.
Qed.

(** ** Substitution Preserves Typing *)

Lemma substitution_preserves_typing : forall Sigma Gamma x v t A B,
    Sigma ; (x |-> B ; Gamma) ⊢ t : A ->
    Sigma ; empty ⊢ v : B ->
    Sigma ; Gamma ⊢ [x:=v]t : A.
Proof.
  intros Sigma Gamma x v t A B Ht Hv.
  revert Gamma A Ht Hv.
  induction t; intros Gamma A Ht1 Ht2; inv Ht1; simpl; eauto.
  - (* T_Abs *)
    destruct (String.eqb_spec x s); subst; apply Ty_Abs.
    + (* x = s *)
      rewrite update_shadow in H4. assumption.
    + (* x <> s *)
      apply IHt; auto.
      rewrite update_permute; auto.
  - (* T_Var *)
    destruct (String.eqb_spec x s); subst.
    + (* x = s *)
      rewrite update_eq in H1. inv H1.
      apply weakening_empty. assumption.
    + (* x <> y *)
      apply Ty_Var. rewrite update_neq in H1; auto.
  - (* T_let *)
    eapply Ty_Let.
    + eapply IHt1; eauto.
    + destruct (String.eqb_spec x s); subst.
      * (* x = s *)
        rewrite update_shadow in H5. assumption.
      * (* x <> s *)
        eapply IHt2; auto.
        rewrite update_permute; eauto.
  - (* T_Case *)
    eapply Ty_Case.
    + now eauto.
    + destruct (String.eqb_spec x s); subst.
      * (* x = s *)
        rewrite update_shadow in H7. assumption.
      * (* x <> s *)
        apply IHt2.
        rewrite update_permute; auto.
        assumption.
    + destruct (String.eqb_spec x s0); subst.
      * (* x = s0 *)
        rewrite update_shadow in H8. assumption.
      * (* x <> s0 *)
        apply IHt3.
        rewrite update_permute; auto.
        assumption.
Qed.

(** ** Preservation *)

(** Three tactics that are used in the proof of preservation. You can
    use them in your cases. *)

(** [impossible_op]: closes cases where an operator is used at the
    wrong type, e.g. [is_nat_op op = true] and [cmp_op op = Some f]. *)
Ltac impossible_op :=
  match goal with
  | H : is_bool_op ?op = true |- _ => destruct op; simpl in *; congruence
  | H : is_nat_op ?op = true |- _ => destruct op; simpl in *; congruence
  | H : is_cmp_op ?op = true |- _ => destruct op; simpl in *; congruence
  end.

(** [same_store]: for steps that do not change the store typing. It
    chooses [Sigma' = Sigma]. Two goals remain: the new term has the
    same type, and the new store is well typed. *)
Ltac same_store :=
  match goal with
  | |- exists Sigma', extends Sigma' ?Sigma /\ _ /\ _ =>
      exists Sigma; split; [ apply extends_refl | split ]
  end.

(** [use_IH IH]: for steps inside a subterm. It uses the induction
    hypothesis [IH] for the subterm, which gives a new store typing
    [Sigma'] that extends [Sigma], the type of the new subterm under
    [Sigma'] ([Hty']), and that the new store is well typed under
    [Sigma'] ([Hst']). One goal remains: the new term has the same type
    under [Sigma']. *)
Ltac use_IH IH :=
  edestruct IH as [Sigma' [Hext [Hty' Hst']]];
  [ reflexivity | eassumption | eassumption |
    exists Sigma'; split; [ exact Hext | split; [ | exact Hst' ] ] ].

(** *** Exercise 5.2 *)

(** The proof of the cases for the constructs of the notes is given
    below, in a comment, because it uses the rule [Ty_Error] (Exercise
    4.1). After you add [Ty_Error]:
    1. delete [Admitted] and the comment marks around the given proof,
    2. add the cases for your new typing rules (Exercise 5.2). *)

Theorem preservation : forall t t' s s' T Sigma,
    Sigma ; empty ⊢ t : T ->
    store_well_typed Sigma s ->
    t / s --> t' / s' ->
    exists Sigma',
      extends Sigma' Sigma /\
      Sigma' ; empty ⊢ t' : T /\
      store_well_typed Sigma' s'.
Proof.
Admitted.
(*
Proof.
  intros t t' s s' T Sigma Ht. revert t' s'.
  remember empty as Gamma.
  induction Ht; intros t' s' Hst Hstep; subst.
  - (* Ty_Var *)
    inv Hstep.
  - (* Ty_Abs *)
    inv Hstep.
  - (* Ty_App *)
    inv Hstep.
    + (* Step_AppAbs *)
      same_store; [ | assumption ].
      inv Ht1. eapply substitution_preserves_typing; eauto.
    + (* Step_App1 *)
      use_IH IHHt1. eauto using store_weakening.
    + (* Step_App2 *)
      use_IH IHHt2. eauto using store_weakening.
    + (* Step_AppErr1 *)
      same_store; auto.
    + (* Step_AppErr2 *)
      same_store; auto.
  - (* Ty_Let *)
    inv Hstep.
    + (* Step_LetVal *)
      same_store; [ | assumption ].
      eapply substitution_preserves_typing; eauto.
    + (* Step_Let *)
      use_IH IHHt1. eauto using store_weakening.
    + (* Step_LetErr *)
      same_store; auto.
  - (* Ty_Bool *)
    inv Hstep.
  - (* Ty_If *)
    inv Hstep; try (same_store; now auto).
    (* Step_If *)
    use_IH IHHt1. eauto using store_weakening.
  - (* Ty_BopBool *)
    (* Cases where the operator has the wrong type are impossible. *)
    inv Hstep; try (same_store; now auto); try impossible_op.
    + (* Step_Bop1 *)
      use_IH IHHt1. eauto using store_weakening.
    + (* Step_Bop2 *)
      use_IH IHHt2. eauto using store_weakening.
  - (* Ty_UOp *)
    inv Hstep; try (same_store; now auto).
    (* Step_UOp *)
    use_IH IHHt. eauto using store_weakening.
  - (* Ty_Nat *)
    inv Hstep.
  - (* Ty_BopNat *)
    (* Cases where the operator has the wrong type are impossible. *)
    inv Hstep; try (same_store; now auto); try impossible_op.
    + (* Step_Bop1 *)
      use_IH IHHt1. eauto using store_weakening.
    + (* Step_Bop2 *)
      use_IH IHHt2. eauto using store_weakening.
  - (* Ty_BopCmp *)
    (* Cases where the operator has the wrong type are impossible. *)
    inv Hstep; try (same_store; now auto); try impossible_op.
    + (* Step_Bop1 *)
      use_IH IHHt1. eauto using store_weakening.
    + (* Step_Bop2 *)
      use_IH IHHt2. eauto using store_weakening.
  - (* Ty_Pair *)
    inv Hstep; try (same_store; now auto).
    + (* Step_Pair1 *)
      use_IH IHHt1. eauto using store_weakening.
    + (* Step_Pair2 *)
      use_IH IHHt2. eauto using store_weakening.
  - (* Ty_Fst *)
    inv Hstep; try (same_store; now auto).
    + (* Step_FstPair *)
      same_store; [ | assumption ].
      inv Ht. assumption.
    + (* Step_Fst *)
      use_IH IHHt. eauto using store_weakening.
  - (* Ty_Snd *)
    inv Hstep; try (same_store; now auto).
    + (* Step_SndPair *)
      same_store; [ | assumption ].
      inv Ht. assumption.
    + (* Step_Snd *)
      use_IH IHHt. eauto using store_weakening.
  - (* Ty_Inl *)
    inv Hstep; try (same_store; now auto).
    (* Step_Inl *)
    use_IH IHHt. eauto using store_weakening.
  - (* Ty_Inr *)
    inv Hstep; try (same_store; now auto).
    (* Step_Inr *)
    use_IH IHHt. eauto using store_weakening.
  - (* Ty_Case *)
    inv Hstep; try (same_store; now auto).
    + (* Step_Case *)
      use_IH IHHt1. eauto using store_weakening.
    + (* Step_CaseInl *)
      same_store; [ | assumption ].
      inv Ht1. eapply substitution_preserves_typing; eauto.
    + (* Step_CaseInr *)
      same_store; [ | assumption ].
      inv Ht1. eapply substitution_preserves_typing; eauto.
  - (* Ty_Unit *)
    inv Hstep.
  (* Exercise 5.2 *)
  (* ___ FILL IN HERE ___ *)
Qed.
*)

(* [preservation] grade 0/15 *)

(** ** Tests *)

(** If your definitions are correct, the tests below succeed. To run a
    test, delete [Admitted] and the comment marks around its proof. *)

(** Hints for the tests: equalities such as [Gamma x = Some A] and
    [nat_op Plus = Some f] are solved by computation, and inequalities
    [l < length s] by [lia]. *)
#[global] Hint Extern 1 (_ = _) => reflexivity : core.
#[global] Hint Extern 1 (_ < _) => simpl; lia : core.

(** The tactic [typecheck] builds a typing derivation, following the
    structure of the term. *)
Ltac typecheck :=
  repeat match goal with
         | |- _ ; _ ⊢ { T_BOp _ _ _ } : _ =>
             first [ eapply Ty_BopNat; [ | | reflexivity ]
                   | eapply Ty_BopBool; [ | | reflexivity ]
                   | eapply Ty_BopCmp; [ | | reflexivity ] ]
         | |- _ ; _ ⊢ _ : _ => econstructor
         | |- _ = _ => reflexivity
         end.

(** The tactic [normalize] evaluates a program step by step. *)
Ltac normalize :=
  repeat (eapply multi_step; [ solve [ eauto 20 ] | simpl ]);
  apply multi_refl.

Definition f : string := "f".
Definition x : string := "x".
Definition n : string := "n".
Definition c : string := "c".
Definition r : string := "r".
Definition u : string := "u".
Definition fact : string := "fact".

(** Factorial with let rec. *)
Definition fact_rec (k : nat) : term :=
  <[ let rec fact (n : Nat) : Nat := if n = 0 then 1 else n * fact (n - 1) in
     fact k ]>.

Example fact_rec_typed : [] ; empty ⊢ {fact_rec 4} : Nat.
Admitted.
(* Proof. unfold fact_rec. apply letrec_typing; typecheck. Qed. *)

Example fact_rec_eval : exists s, fact_rec 4 / [] -->* <[ 24 ]> / s.
Admitted.
(* Proof. eexists. unfold fact_rec, letrec. normalize. Qed. *)

(** A location. *)
Example loc_typed : [Nat] ; empty ⊢ loc 0 : (Ref Nat).
Admitted.
(* Proof. typecheck. Qed. *)

(** A counter. *)
Definition counter : term :=
  <[ let c := ref 40 in
     let u := c ::= !c + 1 in
     let u := c ::= !c + 1 in
     !c ]>.

Example counter_typed : [] ; empty ⊢ counter : Nat.
Admitted.
(* Proof. unfold counter. typecheck. Qed. *)

Example counter_eval : counter / [] -->* <[ 42 ]> / [T_Nat 42].
Admitted.
(* Proof. unfold counter. normalize. Qed. *)

(** Recursion through the store: factorial without [fix]. *)
Definition fact_knot (k : nat) : term :=
  <[ let r := ref (fun n : Nat -> 0) in
     let fact := fun n : Nat -> if n = 0 then 1 else n * (!r) (n - 1) in
     let u := r ::= fact in
     fact k ]>.

Example fact_knot_typed : [] ; empty ⊢ {fact_knot 4} : Nat.
Admitted.
(* Proof. unfold fact_knot. typecheck. Qed. *)

Example fact_knot_eval : exists s, fact_knot 4 / [] -->* <[ 24 ]> / s.
Admitted.
(* Proof. eexists. unfold fact_knot. normalize. Qed. *)

(** Errors. *)
Example error_eval1 : <[ ref (1 + error) ]> / [] -->* <[ error ]> / [].
Admitted.
(* Proof. normalize. Qed. *)

Example error_eval2 : <[ (ref 1) ::= error ]> / [] -->* <[ error ]> / [T_Nat 1].
Admitted.
(* Proof. normalize. Qed. *)

Example error_eval3 : <[ fix (! error) ]> / [] -->* <[ error ]> / [].
Admitted.
(* Proof. normalize. Qed. *)
