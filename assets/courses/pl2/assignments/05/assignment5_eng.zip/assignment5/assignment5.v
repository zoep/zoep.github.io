From Stdlib Require Import Strings.String Arith.Arith Lists.List.

Import ListNotations.

From Assignment5 Require Import miniML.

Open Scope ML_scope.

(** Student Information
Name:
Student ID:
*)


(** * Assignment 5 (100 points) *)

(** The purpose of this assignment is to familiarize yourself with lambda
    calculus and its extensions.

    Instructions:

    - The submitted file must compile. You can check this on your
      terminal by running `make` in the assignment directory (or with
      the command `rocq compile -R . Assignment5 assignment5.v`). Files
      that do not compile will not be graded.

    - Do not change the code that has been given to you. Do not write inside the
      grading comments. This is necessary for smooth and timely grading of
      assignments. You can write where the instruction (* ___ FILL IN HERE ___
      *) appears. If it helps,
      you can define helper functions, lemmas, definitions,
      etc.

    - Do not change the names of the files. Write your answers
      only in this file. Exercises 2 and 3 do not require code.

    - Fill in your information correctly at the beginning of the file. This
      is necessary for correct grading of assignments. *)

(** ** Exercise 1: Interpreter for miniML (60 points) *)

Module Interpreter.

  (** This exercise asks you to write an interpreter for miniML from the lecture
      notes which we have extended with references and recursion. Specifically,
      we extend our language with the following constructs:

      Types:

      A := ... | Ref A

      Terms:

      t, u := let ref f (x : A) : B := e1 in e2 | ref t | !t | t ::= u

      The construct [let ref f (x : A) : B := e1 in e2] allows us to define a
      recursive function with name [f], an argument with name [x] and type [A],
      and return type [B].

      In languages like ML, the type [ref A] denotes values of type [A] which
      however can change via assignment. They function like a "memory box" whose
      value can change.

      We define a reference with the term [ref t], which creates a new memory
      location and puts inside the value of term [t].

      A reference can change value with an assignment [t ::= u]. We can read the
      value that is stored in a reference with the operator [!t].

      For example, the following program returns 42.

      let counter := ref 40 in let _ := counter ::= !counter + 1 in let _ :=
      counter ::= !counter + 1 in !counter *)
  
  (** The interpreter we will write is essentially a big-step semantics for our
      language, but we have defined it as a function instead of a mathematical
      relation, so that we can perform computations. Since when there is
      recursion, the interpreter may not terminate. To define such a function in
      Rocq, we pass an additional parameter, the fuel, which we decrease on each
      recursive call.

      Instead of doing substitutions, which force us to traverse the body of a
      function each time we do a function application, we will use an
      environment, which maps variables to their values.

      Additionally, since we have references, we need a "store" that maps memory
      boxes (which we represent as natural numbers) to their values. *)


  (** We define key-value stores to represent the environments and the store of
      our program.

      This particular implementation uses lists. If we cared about the
      efficiency of our implementation, we could use some tree-based structure,
      provided by the standard library of Rocq. *)
  
  Definition map (K V : Type) : Type := list (K * V).
  
  Definition empty {K V : Type} : map K V := [].

  Definition lookup_map {K V : Type} (eqb : K -> K -> bool) (key : K) (m : map K V) : option V :=
    match find (fun '(k, _) => eqb k key) m with
    | Some (_, v) => Some v
    | None => None
    end.

  Definition extend_map {K V : Type} (key : K) (val : V) (m : map K V) : map K V :=
    (key, val) :: m.


  (** Environments: the keys are variables *)
  Definition env (T : Type) : Type := map string T.
  Definition lookup_env {T} (key : string) (e : env T) : option T :=  lookup_map String.eqb key e.
  Definition extend_env {T} (key : string) (v : T) (e : env T) : env T := extend_map key v e.


  (** Store: the keys are natural numbers *)
  Definition store (T : Type) : Type := map nat T. 
  Definition lookup_store {T} (key : nat) (e : store T) : option T :=  lookup_map Nat.eqb key e.
  Definition extend_store {T} (key : nat) (v : T) (e : store T) : store T := extend_map key v e.


  (** We define the type that corresponds to the evaluated terms of
      our language, which will also be the return type of the interpreter.

      Note that there is a special value called closure:
      this is a function together with the environment in which it was defined.
   *)

  Inductive value : Type :=
  | V_Bool : bool -> value
  | V_Nat : nat -> value
  | V_Closure : string -> string -> term -> env value -> value
  | V_Pair : value -> value -> value
  | V_Inl : value -> value
  | V_Inr : value -> value
  | V_Loc : nat -> value
  | V_Unit : value.


  (** You are given the basic skeleton of the interpreter, and you
      are asked to fill in the "interesting" cases. *)

  (** Helper function for evaluating binary operators. *)
  Definition eval_bop (op : bop) (v1 v2 : value) : option value :=
    match op, v1, v2 with
    | Plus, V_Nat n1, V_Nat n2 => Some (V_Nat (n1 + n2))
    | Minus, V_Nat n1, V_Nat n2 => Some (V_Nat (n1 - n2))
    | Mult, V_Nat n1, V_Nat n2 => Some (V_Nat (n1 * n2))
    | And, V_Bool b1, V_Bool b2 => Some (V_Bool (b1 && b2))
    | Or, V_Bool b1, V_Bool b2 => Some (V_Bool (b1 || b2))
    | Lt, V_Nat n1, V_Nat n2 => Some (V_Bool (n1 <? n2))
    | Eq, V_Nat n1, V_Nat n2 => Some (V_Bool (n1 =? n2))
    | Eq, V_Bool b1, V_Bool b2 => Some (V_Bool (Bool.eqb b1 b2))
    | _, _, _ => None
    end.

  (** Helper function for evaluating unary operators. *)
  Definition eval_uop (op : uop) (v : value) : option value :=
    match op, v with
    | Neg, V_Bool b => Some (V_Bool (negb b))
    | _, _ => None
    end.

  (** This function returns the next available memory location for allocation.
      You must fill in the correct definition. *)
  Definition next_loc (s : store value) : nat := 42.

  (* The result of evaluation. *)
  Inductive result :=
  | Res : value * store value -> result
  | Error : string -> result (* runtime error *)
  | OutOfFuel : term * env value * store value -> result (* fuel ran out *). 

  
  (** The interpreter *)
  Fixpoint eval (fuel : nat) (env : env value) (s : store value) (t : term) : result :=
    match fuel with
    | 0 => OutOfFuel (t, env, s)
    | S fuel' =>
        match t with
        | T_Var x => Error "Fill in here!"
        | T_Nat n => Res (V_Nat n, s)
        | T_Bool b => Res (V_Bool b, s)
        | T_Lambda x ty body => Error "Fill in here!"
        | T_App t1 t2 => Error "Fill in here!"
        | T_LetRec f x T1 T2 t1 t2 => Error "Fill in here!"
        | T_Let x t1 t2 =>
            match eval fuel' env s t1 with
            | Res (v1, s1) =>
                let new_env := extend_env x v1 env in
                eval fuel' new_env s1 t2
            | res => res
            end
        | T_If t1 t2 t3 =>
            match eval fuel' env s t1 with
            | Res (V_Bool true, s1) => eval fuel' env s1 t2
            | Res (V_Bool false, s1) => eval fuel' env s1 t3
            | Res _ => Error "Expecting a boolean"
            | res => res
            end
        | T_BOp op t1 t2 =>
            match eval fuel' env s t1 with
            | Res (v1, s1) =>
                match eval fuel' env s1 t2 with
                | Res (v2, s2) =>
                    match eval_bop op v1 v2 with
                    | Some v => Res (v, s2)
                    | None => Error "Error when evaluating binary operator"
                    end
                | res => res
                end
            | res => res
            end
        | T_UOp op t1 =>
            match eval fuel' env s t1 with
            | Res (v1, s1) =>
                match eval_uop op v1 with
                | Some v => Res (v, s1)
                | None => Error "Error when evaluating unary operator"
                end
            | res => res
            end
        | T_Pair t1 t2 =>
            match eval fuel' env s t1 with
            | Res (v1, s1) =>
                match eval fuel' env s1 t2 with
                | Res (v2, s2) => Res (V_Pair v1 v2, s2)
                | res => res
                end
            | res => res
            end
        | T_Fst t1 =>
            match eval fuel' env s t1 with
            | Res (V_Pair v1 v2, s1) => Res (v1, s1)
            | Res _ => Error "Expecting a pair"
            | res => res
            end
        | T_Snd t1 =>
            match eval fuel' env s t1 with
            | Res (V_Pair v1 v2, s1) => Res (v2, s1)
            | Res _ => Error "Expecting a pair"
            | res => res
            end
        | T_Inl ty t1 => Error "Fill in here!"
        | T_Inr ty t1 => Error "Fill in here!"
        | T_Case t0 x1 t1 x2 t2 => Error "Fill in here!"
        | T_Ref t1 => Error "Fill in here!"
        | T_Deref t1 => Error "Fill in here!"
        | T_Assign t1 t2 => Error "Fill in here!"
        end
    end.

  (* [eval] grade 0/40 *)

  (** Convenience function to run interpreter with empty environment and store. *)
  Definition run_eval (fuel : nat) (t : term) : option value :=
    match eval fuel empty empty t with
    | Res (v, _) => Some v
    | _ => None
    end.

  Definition x := "x"%string.
  Definition z := "z"%string.
  Definition y := "y"%string.
  Definition f := "f"%string.
  Definition fact := "fact"%string.


  (* If your definition is correct, the following tests should succeed *)

  Example test_app : 
    run_eval 100 <[ (fun x : Nat => x + 1) 5 ]> = Some (V_Nat 6).
  Admitted.
  (* Proof. compute. reflexivity. Qed. *)

  
  Example test_closure :
    run_eval 100 <[ let x := 10 in
                    let f := fun y : Nat => x + y in
                    let x := 5 in
                    f 3 ]> = Some (V_Nat 13).
  Admitted.
  (* Proof. compute. reflexivity. Qed. *)


  Definition fact5 :=
    <[ let rec fact ( x : Nat ) : Nat := if x = 0 then 1 else x * fact (x - 1) in fact 5 ]>.  

  Example test_fact5:
    run_eval 1000 <[ fact5 ]> = Some (V_Nat 120).
  Admitted.
  (* Proof. compute. reflexivity. Qed. *)

  Example test_ref1:
    run_eval 1000 <[ let x := ref 0 in let z := x ::= 42 in !x ]> = Some (V_Nat 42).
  Admitted.
  (* Proof. compute. reflexivity. Qed. *)

  Example test_ref2:
    run_eval 100 <[ let x := ref 31 in
                    let y := ref 11 in
                    let z := y ::= !x + !y  in
                    !y ]> = Some (V_Nat 42).
  Admitted.
  (* Proof. compute. reflexivity. Qed. *)


  (** Without using let rec, write

      1. A program that does not terminate

      2. A program that computes the factorial

      Use references to implement the programs. *)


  Definition loop : term (* := ___ FILL IN HERE ___ *).
  Admitted.

  (* [loop] grade 0/10 *)

  Example test_loop:
    exists t s, eval 1000 empty empty loop = OutOfFuel (t, s).
  Admitted.
  (* Proof. eexists. eexists. compute. reflexivity. Qed. *)


  Definition fact_ref (n : nat) : term (* := ___ FILL IN HERE ___ *).
  Admitted.

  (* [fact_ref] grade 0/10 *)

  Example test_fact_ref:
    run_eval 1000 (fact_ref 5) = Some (V_Nat 120).
  Admitted.
  (* Proof. compute. reflexivity. Qed. *)
              
End Interpreter.


(* Exercise 2: Type safety for MiniML: trapped and untrapped errors (20 points) *)

(* The type safety theorem for miniML tells us that a
   well-typed term is either already a value (evaluated), or can take
   a reduction step to a well-typed term. In other words, a well-typed
   term cannot get "stuck" during execution.

   Suppose we extend the language with the division operator (/) and define
   that division by 0 constitutes a (trapped) error during execution.

   Questions:

   a) Would the progress and preservation theorems hold as we know them?
      Explain why yes or why not.

   b) How would you adapt the small-step semantics of the language to
      model the division by 0 error?

   c) How would you adapt the progress and preservation theorems so that the
      type safety theorem says that: "a well-typed term cannot
      get stuck, but can lead to some trapped error (such as
      division by 0)"?

   Describe briefly and clearly the changes you would make to the
   semantics and theorems. You don't need to define anything in Rocq,
   but explain your reasoning clearly.
*)


(* [trapped_errors] grade 0/20 *)

(* Exercise 3: Fix operator (20 points) *)

(* In untyped lambda calculus we saw that we can define recursion with a
   fixed-point combinator. This is not possible in
   typed lambda calculus. However, we can define a primitive operator [fix]
   that has the same semantics as the fixed-point combinator. Using this
   operator, we can define let-rec as a derived form.

   Fill in the static and dynamic semantics of such an operator and define let-rec
   based on fix.

   The book "Types and Programming Languages" will be useful.
   
*)

(* Static semantics: 


                ???
       -----------------------------------
            Γ ⊢ fix t : ???

*)


(* Dynamic semantics: 


               
       -----------------------------------
             fix (λx. t)  --> ???
               
       -----------------------------------
                fix t  -->   ???

*)


(* Let rec as a derived form:


let rec f x = t1 in t2 ≡ ??? 

*)

(* [fix] grade 0/20 *)
