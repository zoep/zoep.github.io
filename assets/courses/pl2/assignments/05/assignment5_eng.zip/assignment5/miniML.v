From Stdlib Require Import Strings.String Arith.Arith Lists.List.

Import ListNotations.

(** ** Syntax **)

(** We start the formalization by defining the abstract syntax of the extended STLC. *)

(** The abstract syntax of types. *)
Inductive type : Type :=
| Arrow : type -> type -> type
| Nat   : type
| Bool  : type
| Unit  : type
| Sum   : type -> type -> type
| Prod  : type -> type -> type
| Ref   : type -> type.

(** Binary Operators. *)
Inductive bop :=
(* arithmetic operators *)
| Plus | Minus | Mult
(* boolean operators *)
| And | Or
(* comparison operators *)
| Lt | Eq.

(** Unary Operators. *)
Inductive uop :=
| Neg.

(** The abstract syntax of terms. *)
Inductive term : Type :=
(* Pure STLC fragment with functions, applications, and variables. *)
| T_App : term -> term -> term
| T_Lambda : string -> type -> term -> term
| T_Var : string -> term
(* Let *)
| T_Let : string -> term -> term -> term                      
(* LetRec *)
| T_LetRec : string -> string -> type -> type -> term -> term -> term
(* Booleans *)
| T_Bool : bool -> term
(* If *)
| T_If : term -> term -> term -> term
(* Natural Numbers *)
| T_Nat : nat -> term
(* Binary Operators *)
| T_BOp : bop -> term -> term -> term
(* Unary Operatos *)
| T_UOp : uop -> term -> term
(* Pairs *)
| T_Pair : term -> term -> term
| T_Fst : term -> term
| T_Snd : term -> term
(* Sums *)
| T_Inl : type -> term -> term
| T_Inr : type -> term -> term
| T_Case : term -> string -> term -> string -> term -> term
(* References *)
| T_Ref : term -> term
| T_Deref : term -> term
| T_Assign : term -> term -> term
.


Declare Scope ML_scope.

Declare Custom Entry ML.
Declare Custom Entry ML_ty.

Notation "<[ e ]>" := e (e custom ML at level 99) : ML_scope.
Notation "( x )" := x (in custom ML, x at level 99).
Notation "x" := x (in custom ML at level 0, x constr at level 0).


Notation "<[[ e ]]>" := e (e custom ML_ty at level 99) : ML_scope.
Notation "( x )" := x (in custom ML_ty, x at level 99).
Notation "x" := x (in custom ML_ty at level 0, x constr at level 0).

(** Types *)

Notation "'Ref' T" := (Ref T) (in custom ML_ty at level 4, no associativity).
Notation "X * Y" :=
  (Prod X Y) (in custom ML_ty at level 3, left associativity).
Notation "S + T" := (Sum S T) (in custom ML_ty at level 3, left associativity).
Notation "S -> T" := (Arrow S T) (in custom ML_ty at level 50, right associativity).

(** Terms *)

Notation "x y" := (T_App x y) (in custom ML at level 20, left associativity).

Notation "'fun'  x ':' T '=>' y" := (T_Lambda x T y) (in custom ML at level 90,
                                          x at level 99,
                                          T custom ML_ty at level 99,
                                          y custom ML at level 99,
                                          left associativity) : ML_scope.

Notation "'let' x ':=' y 'in' z" := (T_Let x y z) (in custom ML at level 90,
                                          x at level 99,
                                          y custom ML at level 100,
                                          z custom ML at level 100, left associativity) : ML_scope.

Notation "'let' 'rec' f '(' x ':' T1 ')' ':' T2 ':=' y 'in' z" := 
    (T_LetRec f x T1 T2 y z) (in custom ML at level 90,
                                  f at level 0,
                                  x at level 0,
                                  T1 custom ML_ty at level 99,
                                  T2 custom ML_ty at level 99,
                                  y custom ML at level 100,
                                  z custom ML at level 100, left associativity) : ML_scope.

Notation "'if' x 'then' y 'else' z" :=
  (T_If x y z)
    (in custom ML at level 89, x at level 99,
        y at level 99, z at level 99) : ML_scope.

Notation "x < y" := (T_BOp Lt x y)
                      (in custom ML at level 60, no associativity) : ML_scope.
Notation "x = y" := (T_BOp Eq x y)
                      (in custom ML at level 60, no associativity) : ML_scope.
Notation "x <= y" := (T_BOp Or (T_BOp Lt x y) (T_BOp Eq x y))
                       (in custom ML at level 60, no associativity) : ML_scope.
Notation "x <> y" := (T_UOp Neg (T_BOp Eq x y))
                       (in custom ML at level 60, no associativity) : ML_scope.

Notation "x && y" := (T_BOp And x y) (in custom ML at level 70, left associativity) : ML_scope.
Notation "x || y" := (T_BOp Or x y) (in custom ML at level 75, left associativity) : ML_scope.

Notation "'~' b" := (T_UOp Neg b) (in custom ML at level 30, right associativity) : ML_scope.

Notation "x * y" := (T_BOp Mult x y) (in custom ML at level 40, left associativity) : ML_scope.
Notation "x + y" := (T_BOp Plus x y) (in custom ML at level 50, left associativity) : ML_scope.
Notation "x - y" := (T_BOp Minus x y) (in custom ML at level 50, left associativity) : ML_scope.

Notation "'inl' T t" := (T_Inl T t) (in custom ML at level 5,
                              T custom ML_ty at level 0,
                              t custom ML at level 0).
Notation "'inr' T t" := (T_Inr T t) (in custom ML at level 5,
                              T custom ML_ty at level 0,
                              t custom ML at level 0).
Notation "'case' t 'of' '|' 'inl' x1 '=>' t1 '|' 'inr' x2 '=>' t2" :=
  (T_Case t x1 t1 x2 t2) (in custom ML at level 89,
        t custom ML at level 99,
        x1 custom ML at level 99,
        t1 custom ML at level 99,
        x2 custom ML at level 99,
        t2 custom ML at level 99,
        left associativity).


Notation "( x ',' y )" := (T_Pair x y) (in custom ML at level 0,
                                x custom ML at level 99,
                                y custom ML at level 99).

Notation "'ref' y" := (T_Ref y)
                      (in custom ML at level 5,
                          no associativity) : ML_scope.

Notation "'!' y" := (T_Deref y)
                      (in custom ML at level 5,
                          no associativity) : ML_scope.

Notation "t '.1'" := (T_Fst t) (in custom ML at level 5).
Notation "t '.2'" := (T_Snd t) (in custom ML at level 5).

Notation "x '::=' y" := (T_Assign x y)
                       (in custom ML at level 80,
                           no associativity) : ML_scope.

(* antiquotation *)

Notation "{ x }" := x (in custom ML at level 1, x constr).

Coercion T_Var : string >-> term.
Coercion T_Nat : nat >-> term.
Coercion T_Bool : bool >-> term.
