Οδηγίες για την άσκηση 5
========================

- Στο αρχείο `assignment5.v` θα συμπληρώσετε τις απαντήσεις σας.

- Το συμπληρωματικό αρχείο `miniML.v` περιλαμβάνει τους
  ορισμούς της γλώσσας miniML.

- Παραδοτέα: Το αρχείο `assignment5.v`

- Προσοχή: Συμπληρώστε τις απαντήσεις σας μόνο σε αυτά τα αρχεία.

- Προκειμένου να κάνετε compile το project:

  - Σε λειτουργικό Linux/macOS ή σε Windows μέσω WSL:

    1. Από ένα terminal ανοίξτε το directory `assignment5`.
    2. Εκτελέστε την εντολή `make`.
    3. Ανοίξτε το αρχείο στον IDE σας.
       VSCode:
       - Ανοίξτε το directory `assignment5` μέσα από το VSCode (File > Open Folder).
       - Επιλέξτε το αρχείο `assignment5.v`.
       - Η εντολή `From Assignment5 Require Import miniML.` στην αρχή του αρχείου θα
         πρέπει να επιτυγχάνει.

       Emacs:
       - Ανοίξτε το αρχείο `assignment5.v` μέσα από το directory `assignment5`.
       - Η εντολή `From Assignment5 Require Import miniML.` στην αρχή του αρχείου θα
         πρέπει να επιτυγχάνει.

    4. Συμπληρώστε την άσκηση.

  - Σε λειτουργικό Windows με CoqIDE

    1. Ανοίξτε το αρχείο `miniML.v` στο CoqIDE. Στο μενού Compile πατήστε
       την επιλογή Compile Buffer.
    2. Ανοίξτε το αρχείο `assignment5.v` στο CoqIDE. Η εντολή `From Assignment5
       Require Import miniML.` στην αρχή του αρχείου θα πρέπει να επιτυγχάνει.
    3. Συμπληρώστε την άσκηση.
