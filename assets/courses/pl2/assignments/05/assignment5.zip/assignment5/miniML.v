From Stdlib Require Import Strings.String Arith.Arith Lists.List Lia.
From Stdlib Require Import Logic.FunctionalExtensionality.

Import ListNotations.

(** * MiniML with Fixed Points, References and Errors *)

(** This file contains the definitions that are shared by the
    assignment: the syntax of the language, notations, substitution,
    typing contexts and stores. Do not modify this file. *)

(** ** Syntax *)

(** The abstract syntax of types. *)
Inductive type : Type :=
| Arrow : type -> type -> type
| Nat   : type
| Bool  : type
| Unit  : type
| Sum   : type -> type -> type
| Prod  : type -> type -> type
(* References *)
| Ref   : type -> type.

(** Binary Operators. *)
Inductive bop :=
(* arithmetic operators *)
| Plus | Minus | Mult | Div
(* boolean operators *)
| And | Or
(* comparison operators *)
| Lt | Eq.

(** Unary Operators. *)
Inductive uop :=
| Neg.

(** The abstract syntax of terms. *)
Inductive term : Type :=
(* Pure STLC fragment with functions, applications, and variables. *)
| T_App : term -> term -> term
| T_Lambda : string -> type -> term -> term
| T_Var : string -> term
(* Let *)
| T_Let : string -> term -> term -> term
(* Booleans *)
| T_Bool : bool -> term
(* If *)
| T_If : term -> term -> term -> term
(* Natural Numbers *)
| T_Nat : nat -> term
(* Binary Operators *)
| T_BOp : bop -> term -> term -> term
(* Unary Operators *)
| T_UOp : uop -> term -> term
(* Pairs *)
| T_Pair : term -> term -> term
| T_Fst : term -> term
| T_Snd : term -> term
(* Sums *)
| T_Inl : type -> term -> term
| T_Inr : type -> term -> term
| T_Case : term -> string -> term -> string -> term -> term
(* Unit *)
| T_Unit : term
(* Fixed-point operator *)
| T_Fix : term -> term
(* References *)
| T_Ref : term -> term          (* allocation:  ref t   *)
| T_Deref : term -> term        (* dereference: !t      *)
| T_Assign : term -> term -> term (* assignment: t1 ::= t2 *)
| T_Loc : nat -> term           (* memory location (appears only during evaluation) *)
(* Errors *)
| T_Error : term.

(** ** Notations *)

(** Terms of the object language are written inside quotations
    [ <[ t ]> ]. Standalone types of the object language are written
    inside quotations [ <[[ t ]]> ]. Inside quotations, we can use
    standard Rocq syntax using the anti-quotation [ { t } ]. *)

Declare Scope ML_scope.

Declare Custom Entry ML.
Declare Custom Entry ML_ty.

Notation "<[ e ]>" := e (e custom ML at level 99) : ML_scope.
Notation "( x )" := x (in custom ML, x at level 99).
Notation "x" := x (in custom ML at level 0, x constr at level 0).

Notation "<[[ e ]]>" := e (e custom ML_ty at level 99) : ML_scope.
Notation "( x )" := x (in custom ML_ty, x at level 99).
Notation "x" := x (in custom ML_ty at level 0, x constr at level 0).

(** Types *)

Notation "'Ref' T" := (Ref T) (in custom ML_ty at level 1, T custom ML_ty at level 0).
Notation "S + T" := (Sum S T) (in custom ML_ty at level 3, left associativity).
Notation "X * Y" :=
  (Prod X Y) (in custom ML_ty at level 2, X custom ML_ty, Y custom ML_ty at level 0).
Notation "S -> T" := (Arrow S T) (in custom ML_ty at level 50, right associativity).

(** Terms *)

Notation "x y" := (T_App x y) (in custom ML at level 1, left associativity).

(** The type annotation of a function is a type of the object
    language. Function types must be written in parentheses, e.g.
    [ fun f : (Nat -> Nat) -> f 1 ]. *)
Notation "'fun' x ':' T '->' y" := (T_Lambda x T y) (in custom ML at level 90,
                                           x at level 99,
                                           T custom ML_ty at level 0,
                                           y custom ML at level 99,
                                           left associativity) : ML_scope.

Notation "'let' x ':=' y 'in' z" := (T_Let x y z) (in custom ML at level 90,
                                          x at level 99,
                                          y custom ML at level 100,
                                          z custom ML at level 100, left associativity) : ML_scope.

Notation "'if' x 'then' y 'else' z" :=
  (T_If x y z)
    (in custom ML at level 89, x at level 99,
        y at level 99, z at level 99) : ML_scope.

Notation "x <= y" := (T_BOp Or (T_BOp Lt x y) (T_BOp Eq x y))
                       (in custom ML at level 70, no associativity) : ML_scope.
Notation "x < y" := (T_BOp Lt x y)
                      (in custom ML at level 70, no associativity) : ML_scope.
Notation "x = y" := (T_BOp Eq x y)
                      (in custom ML at level 70, no associativity) : ML_scope.

Notation "x <> y" := (T_UOp Neg (T_BOp Eq x y))
                       (in custom ML at level 70, no associativity) : ML_scope.

Notation "x && y" := (T_BOp And x y) (in custom ML at level 80, left associativity) : ML_scope.
Notation "x || y" := (T_BOp Or x y) (in custom ML at level 80, left associativity) : ML_scope.

Notation "'~' b" := (T_UOp Neg b) (in custom ML at level 75, right associativity) : ML_scope.

Notation "x + y" := (T_BOp Plus x y) (in custom ML at level 50, left associativity) : ML_scope.
Notation "x - y" := (T_BOp Minus x y) (in custom ML at level 50, left associativity) : ML_scope.
Notation "x * y" := (T_BOp Mult x y) (in custom ML at level 40, left associativity) : ML_scope.
Notation "x / y" := (T_BOp Div x y) (in custom ML at level 40, left associativity) : ML_scope.

Notation "'inl' T t" := (T_Inl T t) (in custom ML at level 0,
                              T custom ML_ty at level 0,
                              t custom ML at level 0).
Notation "'inr' T t" := (T_Inr T t) (in custom ML at level 0,
                              T custom ML_ty at level 0,
                              t custom ML at level 0).
Notation "'case' t 'of' '|' 'inl' x1 '=>' t1 '|' 'inr' x2 '=>' t2" :=
  (T_Case t x1 t1 x2 t2) (in custom ML at level 89,
        t custom ML at level 99,
        x1 custom ML at level 99,
        t1 custom ML at level 99,
        x2 custom ML at level 99,
        t2 custom ML at level 99,
        left associativity).

Notation "( x ',' y )" := (T_Pair x y) (in custom ML at level 0,
                                x custom ML at level 99,
                                y custom ML at level 99).
Notation "t '.1'" := (T_Fst t) (in custom ML at level 1).
Notation "t '.2'" := (T_Snd t) (in custom ML at level 1).

Notation "'unit'" := T_Unit (in custom ML at level 0).

Notation "'fix' t" := (T_Fix t) (in custom ML at level 1, t custom ML at level 0).

Notation "'ref' t" := (T_Ref t) (in custom ML at level 1, t custom ML at level 0).
Notation "'!' t" := (T_Deref t) (in custom ML at level 1, t custom ML at level 0).
Notation "t1 '::=' t2" := (T_Assign t1 t2) (in custom ML at level 85, no associativity).
Notation "'loc' l" := (T_Loc l) (in custom ML at level 0, l constr at level 0).

Notation "'error'" := T_Error (in custom ML at level 0).

(* antiquotation *)
Notation "{ x }" := x (in custom ML at level 1, x constr).

Coercion T_Var : string >-> term.
Coercion T_Nat : nat >-> term.
Coercion T_Bool : bool >-> term.

Open Scope ML_scope.

(** ** Substitution *)

(** As in the notes, substitution is not capture-avoiding. This is
    fine as long as we only substitute closed terms, which is the case
    when we evaluate closed programs. *)

Reserved Notation "'[' x ':=' s ']' t" (in custom ML at level 20, x constr).

Fixpoint subst (x : string) (t' : term) (t : term) : term :=
  match t with
  (* pure stlc *)
  | T_Var y =>
      if String.eqb x y then t' else t
  | <[ fun y : T -> t1 ]> =>
      if String.eqb x y then t else <[ fun y : T -> [x:=t']t1 ]>
  | <[ t1 t2 ]> =>
      <[ ([x:=t'] t1) ([x:=t'] t2) ]>
  (* nats and bools *)
  | T_Nat _ => t
  | T_Bool _ => t
  | T_BOp bop t1 t2 => T_BOp bop <[ [x:=t'] t1 ]>  <[ [x:=t'] t2 ]>
  | T_UOp uop t1 => T_UOp uop <[ [x:=t'] t1 ]>
  | <[ if t1 then t2 else t3 ]> =>
      <[ if [x := t'] t1 then [x := t'] t2 else [x := t'] t3 ]>
  (* pairs *)
  | <[ (t1, t2) ]> => <[ ([x:=t'] t1, [x:=t'] t2) ]>
  | <[ t.1 ]> => <[ ([x:=t'] t).1 ]>
  | <[ t.2 ]> => <[ ([x:=t'] t).2 ]>
  (* sums *)
  | <[ inl T2 t1 ]> =>
      <[ inl T2 ([x:=t'] t1) ]>
  | <[ inr T1 t2 ]> =>
      <[ inr T1 ( [x:=t'] t2) ]>
  | <[ case t of | inl y1 => t1 | inr y2 => t2 ]> =>
      let t1' := if String.eqb x y1 then t1 else <[ [x:=t'] t1 ]> in
      let t2' := if String.eqb x y2 then t2 else <[ [x:=t'] t2 ]> in
      <[ case ([x:=t'] t) of
         | inl y1 => t1'
         | inr y2 => t2' ]>
  (* let *)
  | <[ let y := t1 in t2 ]> =>
      let t2' := if String.eqb x y then t2 else <[ [x:=t'] t2 ]> in
      <[ let y := [x:=t'] t1 in t2' ]>
  (* unit *)
  | <[ unit ]> => t
  (* fix *)
  | <[ fix t1 ]> => <[ fix ([x:=t'] t1) ]>
  (* references *)
  | <[ ref t1 ]> => <[ ref ([x:=t'] t1) ]>
  | <[ ! t1 ]> => <[ ! ([x:=t'] t1) ]>
  | <[ t1 ::= t2 ]> => <[ ([x:=t'] t1) ::= ([x:=t'] t2) ]>
  | <[ loc _ ]> => t
  (* errors *)
  | <[ error ]> => t
  end
where "'[' x ':=' s ']' t" := (subst x s t) (in custom ML).

(** ** Operators *)

(** Helper functions to distinguish between operators of different
    types and define their interpretation. *)

Definition is_nat_op (op : bop) : bool :=
  match op with
  | Plus | Minus | Mult => true
  | _ => false
  end.

Definition nat_op (op : bop) : option (nat -> nat -> nat) :=
  match op with
  | Plus => Some Nat.add
  | Minus => Some Nat.sub
  | Mult => Some Nat.mul
  | _ => None
  end.

Definition is_bool_op (op : bop) : bool :=
  match op with
  | And | Or => true
  | _ => false
  end.

Definition bool_op (op : bop) : option (bool -> bool -> bool) :=
  match op with
  | And => Some andb
  | Or => Some orb
  | _ => None
  end.

Definition is_cmp_op (op : bop) : bool :=
  match op with
  | Eq | Lt => true
  | _ => false
  end.

Definition cmp_op (op : bop) : option (nat -> nat -> bool) :=
  match op with
  | Eq => Some Nat.eqb
  | Lt => Some Nat.ltb
  | _  => None
  end.

Lemma is_nat_op_lemma :
  forall bop, is_nat_op bop = true -> exists f, nat_op bop = Some f.
Proof. intros []; simpl; try discriminate; eauto. Qed.

Lemma is_bool_op_lemma :
  forall bop, is_bool_op bop = true -> exists f, bool_op bop = Some f.
Proof. intros []; simpl; try discriminate; eauto. Qed.

Lemma is_cmp_op_lemma :
  forall bop, is_cmp_op bop = true -> exists f, cmp_op bop = Some f.
Proof. intros []; simpl; try discriminate; eauto. Qed.

(** ** Typing Contexts *)

(** As in the notes, typing contexts are partial maps from variable
    names to types. *)

Definition partial_map A := string -> option A.

Definition empty {A : Type} : partial_map A :=
  fun _ => None.

Definition update {A : Type} (m : partial_map A)
           (x : string) (v : A) :=
  fun x' => if String.eqb x x' then Some v else m x'.

Notation "x '|->' v ';' m" := (update m x v)
  (at level 100, v at level 39, right associativity).

Notation "x '|->' v" := (update empty x v)
  (at level 100).

(** The type of typing contexts. *)
Definition context := string -> option type.

(** A map [m] is a submap of [m'] if every binding of [m] is also in [m']. *)
Definition submap {A : Type} (m m' : partial_map A) : Prop :=
  forall x v, m x = Some v -> m' x = Some v.

Lemma update_eq : forall (A : Type) (m : partial_map A) x v,
  (x |-> v ; m) x = Some v.
Proof.
  intros. unfold update. rewrite String.eqb_refl. reflexivity.
Qed.

Lemma update_neq : forall (A : Type) (m : partial_map A) x1 x2 v,
  x2 <> x1 ->
  (x2 |-> v ; m) x1 = m x1.
Proof.
  intros A m x1 x2 v H.
  unfold update.
  apply String.eqb_neq in H. rewrite H. reflexivity.
Qed.

Lemma submap_update :
  forall (A : Type) (m m' : partial_map A) (x : string) (vx : A),
  submap m m' ->
  submap (x |-> vx ; m) (x |-> vx ; m').
Proof.
  unfold submap.
  intros A m m' x vx H.
  intros y vy.
  destruct (String.eqb_spec x y) as [Hxy | Hxy].
  - rewrite Hxy.
    rewrite update_eq. rewrite update_eq. intro H1. apply H1.
  - rewrite update_neq.
    + rewrite update_neq.
      * apply H.
      * apply Hxy.
    + apply Hxy.
Qed.

Lemma update_shadow :
  forall (A : Type) (m : partial_map A) x v1 v2,
    (x |-> v2 ; x |-> v1 ; m) = (x |-> v2 ; m).
Proof.
  intros A m x v1 v2. unfold update.
  apply functional_extensionality. intros y.
  destruct (String.eqb_spec x y); subst; eauto.
Qed.

Lemma update_permute :
  forall (A : Type) (m : partial_map A) x1 x2 v1 v2,
    x2 <> x1 ->
    (x1 |-> v1 ; x2 |-> v2 ; m) = (x2 |-> v2 ; x1 |-> v1 ; m).
Proof.
  intros A m x1 x2 v1 v2 Hneq. unfold update.
  apply functional_extensionality. intros y.
  destruct (String.eqb_spec x1 y); subst; eauto.
  destruct (String.eqb_spec x2 y); subst; eauto.
  congruence.
Qed.

(** ** Stores *)

(** A store is a list of terms. A location [l] is a position in the
    list: the value stored at location [l] is [nth_error s l]. A new
    location is allocated at the end of the list, i.e., at position
    [length s].

    A store typing gives the type of each location. It is a list of
    types: the type of location [l] is [nth_error Sigma l]. *)

Definition store := list term.

Definition store_ty := list type.

(** NOTE: Because of the notation for the typing judgment, list
    literals with more than one element, such as [[Nat; Bool]], cannot
    be parsed in the assignment file. Write them as [Nat :: Bool :: nil]
    or [[Nat] ++ [Bool]] instead. *)

(** [replace n x l] replaces the [n]-th element of [l] with [x]. *)
Fixpoint replace {A : Type} (n : nat) (x : A) (l : list A) : list A :=
  match l with
  | [] => []
  | h :: t =>
      match n with
      | O => x :: t
      | S n' => h :: replace n' x t
      end
  end.

(** Lemmas about lists. Apart from the lemmas below, you may find the
    following lemmas of the standard library useful:

    - [nth_error_app1 : n < length l -> nth_error (l ++ l') n = nth_error l n]
    - [nth_error_app2 : length l <= n -> nth_error (l ++ l') n = nth_error l' (n - length l)]
    - [nth_error_Some : nth_error l n <> None <-> n < length l]
    - [nth_error_None : nth_error l n = None <-> length l <= n]
    - [length_app : length (l ++ l') = length l + length l'] *)

Lemma length_replace : forall A n (x : A) l,
    length (replace n x l) = length l.
Proof.
  intros A n x l. revert n.
  induction l as [| h t IH]; intros [| n]; simpl; auto.
Qed.

Lemma nth_error_replace_eq : forall A n (x : A) l,
    n < length l ->
    nth_error (replace n x l) n = Some x.
Proof.
  intros A n x l. revert n.
  induction l as [| h t IH]; intros [| n] Hlt; simpl in *; try lia; auto.
  apply IH. lia.
Qed.

Lemma nth_error_replace_neq : forall A n m (x : A) l,
    n <> m ->
    nth_error (replace n x l) m = nth_error l m.
Proof.
  intros A n m x l. revert n m.
  induction l as [| h t IH]; intros [| n] [| m] Hneq; simpl; auto; try congruence.
Qed.

Lemma nth_error_snoc : forall A (l : list A) x,
    nth_error (l ++ [x]) (length l) = Some x.
Proof.
  intros A l x. rewrite nth_error_app2 by lia.
  rewrite Nat.sub_diag. reflexivity.
Qed.

(** ** Multi-step relation *)

Inductive multi {A : Type} (R : A -> A -> Prop) : A -> A -> Prop :=
| multi_refl : forall x, multi R x x
| multi_step : forall x y z,
    R x y ->
    multi R y z ->
    multi R x z.

(** ** Tactics *)

Ltac inv H := inversion H; clear H; subst.
