From Stdlib Require Import Strings.String Arith.Arith Lists.List Lia.

Import ListNotations.

Require Import miniML.

Open Scope ML_scope.

(** Στοιχεία Σπουδαστή
Όνομα:
ΑΜ:
*)


(** * Εργασία 5 (105 μονάδες) *)

(** Σε αυτή την εργασία θα επεκτείνετε τον λάμβδα λογισμό με τύπους των
    σημειώσεων του μαθήματος με έναν τελεστή σταθερού σημείου, αναφορές
    και σφάλματα, και θα αποδείξετε την ασφάλεια τύπων για τη νέα
    γλώσσα.

    Οδηγίες:

    - Το παραδοτέο αρχείο θα πρέπει να κάνει compile. Τα αρχεία που δεν
      κάνουν compile δεν θα βαθμολογούνται. Αν δεν μπορείτε να
      ολοκληρώσετε μια απόδειξη, χρησιμοποιήστε [admit] για τις
      περιπτώσεις που δεν ολοκληρώσατε και τελειώστε την απόδειξη με
      [Admitted].

    - Μην αλλάζετε τον κώδικα που σας έχει δοθεί. Μην γράφετε μέσα στα
      σχόλια της βαθμολόγησης. Αυτό είναι απαραίτητο για την ομαλή και
      έγκαιρη βαθμολόγηση των εργασιών. Μπορείτε να γράψετε όπου υπάρχει
      η οδηγία (* ___ FILL IN HERE ___ *). Εάν σας εξυπηρετεί, μπορείτε
      να ορίζετε βοηθητικές συναρτήσεις, λήμματα, ορισμούς, κ.α.

    - Προσθέστε τους κανόνες σας στους ορισμούς των [value], [step] και
      [has_type] στα σημεία που σημειώνονται με
      (* ___ FILL IN HERE ___ *), μετά τους κανόνες που σας δίνονται, και
      χρησιμοποιήστε τα ονόματα κανόνων που ορίζουν οι ασκήσεις. Μην
      αλλάζετε αυτά τα ονόματα. Αφού ολοκληρώσετε τους κανόνες,
      ολοκληρώστε τις αποδείξεις της ασφάλειας τύπων.

    - **Μην αλλάζετε τα ονόματα των αρχείων**. Γράψτε τις απαντήσεις
      σας μόνο σε αυτό το αρχείο.

    - Συμπληρώστε σωστά τα στοιχεία σας στην αρχή του αρχείου. Αυτό
      είναι απαραίτητο για τη σωστή βαθμολόγηση των εργασιών. *)

(** ** Η γλώσσα *)

(** Το αρχείο [miniML.v] περιέχει τη σύνταξη της γλώσσας. Σε σχέση με
    τις σημειώσεις, η γλώσσα έχει τις εξής νέες δομές:

      Τύποι:  A ::= ... | Ref A
      Όροι:   t ::= ... | fix t | ref t | !t | t1 ::= t2 | loc l | error | t1 / t2

    - Ο όρος [fix t] είναι ο τελεστής σταθερού σημείου (Άσκηση 1).

    - Ο όρος [ref t] δεσμεύει μια νέα θέση μνήμης και αποθηκεύει σε αυτή
      την τιμή του [t]. Ο όρος [!t] επιστρέφει την τιμή που είναι
      αποθηκευμένη στη θέση [t]. Ο όρος [t1 ::= t2] αποθηκεύει την τιμή
      του [t2] στη θέση [t1] και επιστρέφει [unit] (Ασκήσεις 2 και 3).

    - Ο όρος [loc l] είναι η θέση μνήμης [l]. Οι θέσεις μνήμης δεν
      εμφανίζονται στην επιφανειακή σύνταξη (surface syntax).
      Δημιουργούνται από το [ref t] κατά την αποτίμηση.

    - Ο όρος [error] είναι ένα σφάλμα εκτέλεσης (Άσκηση 4). Όταν ένας
      υποόρος που αποτιμάται γίνει [error], ολόκληρος ο όρος γίνεται
      [error].

    - Ο όρος [t1 / t2] είναι η διαίρεση φυσικών αριθμών (Άσκηση 4.4).

    Η μνήμη (store) [s] είναι μια λίστα τιμών: η τιμή στη θέση [l] είναι
    το [nth_error s l], και μια νέα θέση δεσμεύεται στο τέλος της λίστας,
    δηλαδή στη θέση [length s] (βλ. [miniML.v]).

    Η σημασιολογία είναι μια σχέση ανάμεσα σε ζεύγη [t / s], τα οποία
    παριστάνουν έναν όρο [t] μαζί με μια μνήμη [s].

      t / s --> t' / s'

    Η σχέση τύπων επεκτείνεται με έναν τύπο μνήμης (store typing)
    [Sigma], ο οποίος είναι μια λίστα τύπων που δίνει τον τύπο κάθε
    θέσης μνήμης.

      Sigma ; Gamma ⊢ t : A

    Οι ορισμοί και οι αποδείξεις των σημειώσεων δίνονται παρακάτω,
    προσαρμοσμένοι σε μνήμες και τύπους μνήμης.
 *)

(** ** Ασκήσεις *)

(** *** Άσκηση 1: Τελεστής σταθερού σημείου και let rec (15 μονάδες) *)

(** Στον λάμβδα λογισμό χωρίς τύπους μπορούμε να ορίσουμε την αναδρομή
    με έναν συνδυαστή σταθερού σημείου (π.χ. Y, Z ή Θ). Αυτοί οι
    συνδυαστές δεν έχουν τύπο στον λάμβδα λογισμό με τύπους. Αντί γι'
    αυτό, προσθέτουμε έναν πρωτογενή τελεστή [fix] που συμπεριφέρεται
    σαν συνδυαστής σταθερού σημείου: ο όρος [fix (fun f : A -> t)]
    ξεδιπλώνεται στο σώμα [t], όπου οι αναδρομικές κλήσεις [f]
    αναφέρονται στο ίδιο το [fix (fun f : A -> t)]. Θα σας φανεί
    χρήσιμο το βιβλίο "Types and Programming Languages" (Ενότητα 11.11).

    1.1 (6 μονάδες) Προσθέστε στο [step] τους κανόνες αποτίμησης του
        [fix]: [Step_FixAbs] (το ξεδίπλωμα του [fix (fun f : A -> t)])
        και [Step_Fix] (αποτίμηση του ορίσματος του [fix]). Προσθέστε
        στο [has_type] τον κανόνα τύπων [Ty_Fix].

    1.2 (9 μονάδες) Ορίστε το let rec ως παραγόμενη μορφή, με χρήση
        του [fix], και αποδείξτε τον κανόνα τύπων του (λήμμα
        [letrec_typing]). *)

(** *** Άσκηση 2: Αναφορές (25 μονάδες) *)

(** 2.1 Ποιοι από τους νέους όρους είναι τιμές; Προσθέστε στο
        κατηγόρημα [value] τον απαραίτητο κανόνα με όνομα [V_New].

    2.2 Προσθέστε στο [step] τους κανόνες αποτίμησης των αναφορών:
        - [Step_RefValue] (δέσμευση θέσης) και [Step_Ref],
        - [Step_DerefLoc] (ανάγνωση θέσης) και [Step_Deref],
        - [Step_Assign] (εγγραφή σε θέση), [Step_Assign1] και
          [Step_Assign2].
        Όπως και για τις υπόλοιπες δομές, οι υποόροι αποτιμώνται από
        αριστερά προς τα δεξιά. Για τη μνήμη χρησιμοποιήστε τα [length],
        [++], [nth_error] και [replace] (βλ. [miniML.v]).

    2.3 Προσθέστε στο [has_type] τους κανόνες τύπων [Ty_Loc], [Ty_Ref],
        [Ty_Deref] και [Ty_Assign]. *)

(** *** Άσκηση 3: Λήμματα για τη μνήμη (20 μονάδες) *)

(** Αποδείξτε τα λήμματα [extends_snoc], [store_weakening],
    [store_well_typed_alloc], [store_well_typed_assign] και
    [canonical_forms_ref] παρακάτω. *)

(** *** Άσκηση 4: Σφάλματα (20 μονάδες) *)

(** Οι κανόνες που μεταφέρουν ένα σφάλμα προς τα έξω μέσα από τις δομές
    των σημειώσεων σας δίνονται ([Step_AppErr1], [Step_AppErr2], κ.λπ.).

    4.1 (5 μονάδες) Προσθέστε τους αντίστοιχους κανόνες για τις νέες
        δομές: [Step_FixErr], [Step_RefErr], [Step_DerefErr],
        [Step_AssignErr1] και [Step_AssignErr2]. Προσθέστε στο
        [has_type] τον κανόνα τύπων [Ty_Error].

    4.2 (5 μονάδες) Η διατύπωση του progress από τις σημειώσεις δεν
        ισχύει πλέον. Αποδείξτε το (λήμμα [progress_old_false]).

    4.3 (5 μονάδες) Γράψτε τη σωστή διατύπωση του progress (θεώρημα
        [progress]).

    4.4 (5 μονάδες) Η διαίρεση [t1 / t2] φυσικών αριθμών (τελεστής
        [Div] στο [miniML.v]) δεν έχει ακόμη κανόνες. Προσθέστε στο
        [has_type] τον κανόνα τύπων [Ty_Div] και στο [step] τους
        κανόνες αποτίμησης [Step_Div] και [Step_DivZero], ώστε η
        διαίρεση με το μηδέν να είναι σφάλμα που παγιδεύεται (trapped
        error), δηλαδή να αποτιμάται σε [error]. *)

(** *** Άσκηση 5: Ασφάλεια τύπων (25 μονάδες) *)

(** 5.1 (10 μονάδες) Ολοκληρώστε την απόδειξη του [progress].

    5.2 (15 μονάδες) Ολοκληρώστε την απόδειξη του [preservation]. *)

(** ** Τιμές *)

Inductive value : term -> Prop :=
(* Functions *)
| V_Fun :
  forall x T t,
    value <[ fun x : T -> t ]>
(* Natural Numbers *)
| V_Nat :
  forall (n : nat),
    value <[ n ]>
(* Booleans *)
| V_Bool :
  forall (b : bool),
    value <[ b ]>
(* Unit *)
| V_Unit :
    value <[ unit ]>
(* Sums *)
| V_Inl : forall v T1,
    value v ->
    value <[ inl T1 v ]>
| V_Inr : forall v T1,
    value v ->
    value <[ inr T1 v ]>
(* Pairs *)
| V_Pair : forall v1 v2,
    value v1 ->
    value v2 ->
    value <[ (v1, v2) ]>
(* Άσκηση 2.1 *)
(* ___ FILL IN HERE ___ *)
(* [value] grade 0/3 *)
.

(** ** Σημασιολογία *)

Reserved Notation "t '/' s '-->' t' '/' s'"
  (at level 40, s at next level, t' at next level, left associativity).

Inductive step : term * store -> term * store -> Prop :=
(* pure STLC *)
| Step_AppAbs : forall x T2 t1 v2 s,
    value v2 ->
    <[ (fun x : T2 -> t1) v2 ]> / s --> <[ [x:=v2]t1 ]> / s
| Step_App1 : forall t1 t1' t2 s s',
    t1 / s --> t1' / s' ->
    <[ t1 t2 ]> / s --> <[ t1' t2 ]> / s'
| Step_App2 : forall v1 t2 t2' s s',
    value v1 ->
    t2 / s --> t2' / s' ->
    <[ v1 t2 ]> / s --> <[ v1 t2' ]> / s'
(* Let *)
| Step_LetVal : forall y v1 t2 s,
    value v1 ->
    <[ let y := v1 in t2 ]> / s --> <[ [y := v1] t2 ]> / s
| Step_Let : forall y t1 t1' t2 s s',
    t1 / s --> t1' / s' ->
    <[ let y := t1 in t2 ]> / s --> <[ let y := t1' in t2 ]> / s'
(* If then else *)
| Step_IfTrue : forall t1 t2 s,
    <[ if true then t1 else t2 ]> / s --> t1 / s
| Step_IfFalse : forall t1 t2 s,
    <[ if false then t1 else t2 ]> / s --> t2 / s
| Step_If : forall t t' t1 t2 s s',
    t / s --> t' / s' ->
    <[ if t then t1 else t2 ]> / s --> <[ if t' then t1 else t2 ]> / s'
(* Binary Operators *)
| Step_BOpNat : forall bop (n1 n2 : nat) bop_f s,
    nat_op bop = Some bop_f ->
    (T_BOp bop n1 n2) / s --> T_Nat (bop_f n1 n2) / s
| Step_BOpBool : forall bop (b1 b2 : bool) bop_f s,
    bool_op bop = Some bop_f ->
    (T_BOp bop b1 b2) / s --> T_Bool (bop_f b1 b2) / s
| Step_BOpCmp : forall bop (n1 n2 : nat) bop_f s,
    cmp_op bop = Some bop_f ->
    (T_BOp bop n1 n2) / s --> T_Bool (bop_f n1 n2) / s
| Step_Bop1 : forall bop t1 t1' t2 s s',
    t1 / s --> t1' / s' ->
    (T_BOp bop t1 t2) / s --> (T_BOp bop t1' t2) / s'
| Step_Bop2 : forall bop v1 t2 t2' s s',
    value v1 ->
    t2 / s --> t2' / s' ->
    (T_BOp bop v1 t2) / s --> (T_BOp bop v1 t2') / s'
(* Unary Operators *)
| Step_UOpBool : forall (b : bool) s,
    (T_UOp Neg b) / s --> T_Bool (negb b) / s
| Step_UOp : forall t t' s s',
    t / s --> t' / s' ->
    (T_UOp Neg t) / s --> (T_UOp Neg t') / s'
(* Pairs *)
| Step_Pair1 : forall t1 t1' t2 s s',
    t1 / s --> t1' / s' ->
    <[ (t1, t2) ]> / s --> <[ (t1', t2) ]> / s'
| Step_Pair2 : forall v1 t2 t2' s s',
    value v1 ->
    t2 / s --> t2' / s' ->
    <[ (v1, t2) ]> / s --> <[ (v1, t2') ]> / s'
| Step_FstPair : forall v1 v2 s,
    value v1 -> value v2 ->
    <[ (v1, v2).1 ]> / s --> v1 / s
| Step_Fst : forall t t' s s',
    t / s --> t' / s' ->
    <[ t.1 ]> / s --> <[ t'.1 ]> / s'
| Step_SndPair : forall v1 v2 s,
    value v1 -> value v2 ->
    <[ (v1, v2).2 ]> / s --> v2 / s
| Step_Snd : forall t t' s s',
    t / s --> t' / s' ->
    <[ t.2 ]> / s --> <[ t'.2 ]> / s'
(* Sums *)
| Step_Inl : forall t1 t1' T2 s s',
    t1 / s --> t1' / s' ->
    <[ inl T2 t1 ]> / s --> <[ inl T2 t1' ]> / s'
| Step_Inr : forall t2 t2' T1 s s',
    t2 / s --> t2' / s' ->
    <[ inr T1 t2 ]> / s --> <[ inr T1 t2' ]> / s'
| Step_Case : forall t t' x1 t1 x2 t2 s s',
    t / s --> t' / s' ->
    <[ case t of | inl x1 => t1 | inr x2 => t2 ]> / s -->
    <[ case t' of | inl x1 => t1 | inr x2 => t2 ]> / s'
| Step_CaseInl : forall v x1 t1 x2 t2 T2 s,
    value v ->
    <[ case inl T2 v of | inl x1 => t1 | inr x2 => t2 ]> / s --> <[ [x1:=v]t1 ]> / s
| Step_CaseInr : forall v x1 t1 x2 t2 T1 s,
    value v ->
    <[ case inr T1 v of | inl x1 => t1 | inr x2 => t2 ]> / s --> <[ [x2:=v]t2 ]> / s
(* Errors *)
| Step_AppErr1 : forall t2 s,
    <[ error t2 ]> / s --> <[ error ]> / s
| Step_AppErr2 : forall v1 s,
    value v1 ->
    <[ v1 error ]> / s --> <[ error ]> / s
| Step_LetErr : forall y t2 s,
    <[ let y := error in t2 ]> / s --> <[ error ]> / s
| Step_IfErr : forall t1 t2 s,
    <[ if error then t1 else t2 ]> / s --> <[ error ]> / s
| Step_BopErr1 : forall bop t2 s,
    (T_BOp bop <[ error ]> t2) / s --> <[ error ]> / s
| Step_BopErr2 : forall bop v1 s,
    value v1 ->
    (T_BOp bop v1 <[ error ]>) / s --> <[ error ]> / s
| Step_UOpErr : forall s,
    (T_UOp Neg <[ error ]>) / s --> <[ error ]> / s
| Step_PairErr1 : forall t2 s,
    <[ (error, t2) ]> / s --> <[ error ]> / s
| Step_PairErr2 : forall v1 s,
    value v1 ->
    <[ (v1, error) ]> / s --> <[ error ]> / s
| Step_FstErr : forall s,
    <[ error.1 ]> / s --> <[ error ]> / s
| Step_SndErr : forall s,
    <[ error.2 ]> / s --> <[ error ]> / s
| Step_InlErr : forall T2 s,
    <[ inl T2 error ]> / s --> <[ error ]> / s
| Step_InrErr : forall T1 s,
    <[ inr T1 error ]> / s --> <[ error ]> / s
| Step_CaseErr : forall x1 t1 x2 t2 s,
    <[ case error of | inl x1 => t1 | inr x2 => t2 ]> / s --> <[ error ]> / s
(* Άσκηση 1.1: fix *)
(* ___ FILL IN HERE ___ *)
(* [step_fix] grade 0/3 *)
(* Άσκηση 2.2: αναφορές *)
(* ___ FILL IN HERE ___ *)
(* [step_ref] grade 0/12 *)
(* Άσκηση 4.1: σφάλματα *)
(* ___ FILL IN HERE ___ *)
(* [step_error] grade 0/3 *)
(* Άσκηση 4.4: διαίρεση *)
(* ___ FILL IN HERE ___ *)
(* [step_div] grade 0/3 *)

where "t '/' s '-->' t' '/' s'" := (step (@pair term store t s) (@pair term store t' s')).

Notation "t '/' s '-->*' t' '/' s'" := (multi step (@pair term store t s) (@pair term store t' s'))
  (at level 40, s at next level, t' at next level, left associativity).

(** ** Σύστημα τύπων *)

Reserved Notation "Sigma ';' Gamma '⊢' t ':' T"
  (at level 40, t custom ML, T custom ML_ty at level 0).

Inductive has_type (Sigma : store_ty) : context -> term -> type -> Prop :=
  (* Pure STLC *)
  | Ty_Var : forall Gamma x A,
      Gamma x = Some A ->
      Sigma ; Gamma ⊢ x : A
  | Ty_Abs : forall Gamma x t A B,
      Sigma ; (x |-> A ; Gamma) ⊢ t : B ->
      Sigma ; Gamma ⊢ (fun x : A -> t) : (A -> B)
  | Ty_App : forall Gamma t1 t2 A B,
      Sigma ; Gamma ⊢ t1 : (A -> B) ->
      Sigma ; Gamma ⊢ t2 : A ->
      Sigma ; Gamma ⊢ t1 t2 : B
  (* Let *)
  | Ty_Let : forall Gamma x t1 t2 A B,
      Sigma ; Gamma ⊢ t1 : A ->
      Sigma ; (x |-> A ; Gamma) ⊢ t2 : B ->
      Sigma ; Gamma ⊢ (let x := t1 in t2) : B
  (* Bools *)
  | Ty_Bool : forall Gamma (b : bool),
      Sigma ; Gamma ⊢ b : Bool
  | Ty_If : forall Gamma t1 t2 t3 A,
      Sigma ; Gamma ⊢ t1 : Bool ->
      Sigma ; Gamma ⊢ t2 : A ->
      Sigma ; Gamma ⊢ t3 : A ->
      Sigma ; Gamma ⊢ if t1 then t2 else t3 : A
  | Ty_BopBool : forall Gamma bop t1 t2,
      Sigma ; Gamma ⊢ t1 : Bool ->
      Sigma ; Gamma ⊢ t2 : Bool ->
      is_bool_op bop = true ->
      Sigma ; Gamma ⊢ { T_BOp bop t1 t2 } : Bool
  | Ty_UOp : forall Gamma uop t1,
      Sigma ; Gamma ⊢ t1 : Bool ->
      Sigma ; Gamma ⊢ { T_UOp uop t1 } : Bool
  (* Numbers *)
  | Ty_Nat : forall Gamma (n : nat),
      Sigma ; Gamma ⊢ n : Nat
  | Ty_BopNat : forall Gamma bop t1 t2,
      Sigma ; Gamma ⊢ t1 : Nat ->
      Sigma ; Gamma ⊢ t2 : Nat ->
      is_nat_op bop = true ->
      Sigma ; Gamma ⊢ { T_BOp bop t1 t2 } : Nat
  | Ty_BopCmp : forall Gamma bop t1 t2,
      Sigma ; Gamma ⊢ t1 : Nat ->
      Sigma ; Gamma ⊢ t2 : Nat ->
      is_cmp_op bop = true ->
      Sigma ; Gamma ⊢ { T_BOp bop t1 t2 } : Bool
  (* Pairs *)
  | Ty_Pair : forall Gamma t1 t2 A B,
      Sigma ; Gamma ⊢ t1 : A ->
      Sigma ; Gamma ⊢ t2 : B ->
      Sigma ; Gamma ⊢ (t1, t2) : (A * B)
  | Ty_Fst : forall Gamma t1 A B,
      Sigma ; Gamma ⊢ t1 : (A * B) ->
      Sigma ; Gamma ⊢ t1.1 : A
  | Ty_Snd : forall Gamma t1 A B,
      Sigma ; Gamma ⊢ t1 : (A * B) ->
      Sigma ; Gamma ⊢ t1.2 : B
  (* Sums *)
  | Ty_Inl : forall Gamma t1 A B,
      Sigma ; Gamma ⊢ t1 : A ->
      Sigma ; Gamma ⊢ (inl B t1) : (A + B)
  | Ty_Inr : forall Gamma t2 A B,
      Sigma ; Gamma ⊢ t2 : B ->
      Sigma ; Gamma ⊢ (inr A t2) : (A + B)
  | Ty_Case : forall Gamma t x1 A t1 x2 B t2 C,
      Sigma ; Gamma ⊢ t : (A + B) ->
      Sigma ; (x1 |-> A ; Gamma) ⊢ t1 : C ->
      Sigma ; (x2 |-> B ; Gamma) ⊢ t2 : C ->
      Sigma ; Gamma ⊢ (case t of | inl x1 => t1 | inr x2 => t2) : C
  (* Unit *)
  | Ty_Unit : forall Gamma,
      Sigma ; Gamma ⊢ unit : Unit
  (* Άσκηση 1.1: fix *)
  (* ___ FILL IN HERE ___ *)
  (* [typing_fix] grade 0/3 *)
  (* Άσκηση 2.3: αναφορές *)
  (* ___ FILL IN HERE ___ *)
  (* [typing_ref] grade 0/10 *)
  (* Άσκηση 4.1: σφάλματα *)
  (* ___ FILL IN HERE ___ *)
  (* [typing_error] grade 0/2 *)
  (* Άσκηση 4.4: διαίρεση *)
  (* ___ FILL IN HERE ___ *)
  (* [typing_div] grade 0/2 *)

where "Sigma ';' Gamma '⊢' t ':' T" := (has_type Sigma Gamma t T).

#[global] Hint Constructors value : core.
#[global] Hint Constructors step : core.
#[global] Hint Constructors has_type : core.

(** ** Τύποι μνήμης *)

(** [extends Sigma' Sigma]: κάθε θέση μνήμης που έχει τύπο στο [Sigma]
    έχει τον ίδιο τύπο στο [Sigma']. *)
Definition extends (Sigma' Sigma : store_ty) : Prop :=
  forall l T, nth_error Sigma l = Some T -> nth_error Sigma' l = Some T.

Lemma extends_refl : forall Sigma, extends Sigma Sigma.
Proof. unfold extends. auto. Qed.

#[global] Hint Resolve extends_refl : core.

(** Μια μνήμη [s] είναι well typed ως προς έναν τύπο μνήμης [Sigma] αν
    έχουν τις ίδιες θέσεις, και η τιμή σε κάθε θέση έχει τον τύπο που
    δίνει το [Sigma] σε αυτή τη θέση. *)
Definition store_well_typed (Sigma : store_ty) (s : store) : Prop :=
  length s = length Sigma /\
  (forall l v T,
      nth_error s l = Some v ->
      nth_error Sigma l = Some T ->
      Sigma ; empty ⊢ v : T).

(** ** Άσκηση 1.2: let rec ως παραγόμενη μορφή *)

(** Ο όρος [let rec f (x : A) : B := t1 in t2] ορίζει μια αναδρομική
    συνάρτηση [f] με όρισμα [x] τύπου [A] και τύπο επιστροφής [B], με
    σώμα το [t1]. Η συνάρτηση [f] μπορεί να χρησιμοποιηθεί στο [t1] και
    στο [t2].

    Ορίστε το [letrec f x A B t1 t2] με χρήση του [fix]. *)

Definition letrec (f x : string) (A B : type) (t1 t2 : term) : term
  (* := ___ FILL IN HERE ___ *).
Admitted.

(* [letrec] grade 0/4 *)

Notation "'let' 'rec' f '(' x ':' T1 ')' ':' T2 ':=' y 'in' z" :=
  (letrec f x T1 T2 y z)
    (in custom ML at level 90,
        f at level 0,
        x at level 0,
        T1 custom ML_ty at level 99,
        T2 custom ML_ty at level 99,
        y custom ML at level 100,
        z custom ML at level 100, left associativity) : ML_scope.

(** Αποδείξτε τον κανόνα τύπων του let rec. *)

Lemma letrec_typing : forall Sigma Gamma f x A B C t1 t2,
    Sigma ; (x |-> A ; f |-> <[[ A -> B ]]> ; Gamma) ⊢ t1 : B ->
    Sigma ; (f |-> <[[ A -> B ]]> ; Gamma) ⊢ t2 : C ->
    Sigma ; Gamma ⊢ (let rec f (x : A) : B := t1 in t2) : C.
Proof.
  (* ___ FILL IN HERE ___ *)
Admitted.

(* [letrec_typing] grade 0/5 *)

(** ** Άσκηση 3: Λήμματα για τη μνήμη *)

(** Η δέσμευση μιας νέας θέσης δεν αλλάζει τους τύπους των θέσεων που
    υπάρχουν ήδη. *)
Lemma extends_snoc : forall Sigma A,
    extends (Sigma ++ [A]) Sigma.
Proof.
  (* ___ FILL IN HERE ___ *)
Admitted.

(* [extends_snoc] grade 0/3 *)

(** Οι τύποι διατηρούνται όταν ο τύπος μνήμης μεγαλώνει. *)
Lemma store_weakening : forall Sigma Sigma' Gamma t A,
    extends Sigma' Sigma ->
    Sigma ; Gamma ⊢ t : A ->
    Sigma' ; Gamma ⊢ t : A.
Proof.
  (* ___ FILL IN HERE ___ *)
Admitted.

(* [store_weakening] grade 0/4 *)

(** Η δέσμευση μιας νέας θέσης διατηρεί τη μνήμη well typed. *)
Lemma store_well_typed_alloc : forall Sigma s v A,
    store_well_typed Sigma s ->
    Sigma ; empty ⊢ v : A ->
    store_well_typed (Sigma ++ [A]) (s ++ [v]).
Proof.
  (* ___ FILL IN HERE ___ *)
Admitted.

(* [store_well_typed_alloc] grade 0/5 *)

(** Η ανάθεση διατηρεί τη μνήμη well typed. *)
Lemma store_well_typed_assign : forall Sigma s l v A,
    store_well_typed Sigma s ->
    nth_error Sigma l = Some A ->
    Sigma ; empty ⊢ v : A ->
    store_well_typed Sigma (replace l v s).
Proof.
  (* ___ FILL IN HERE ___ *)
Admitted.

(* [store_well_typed_assign] grade 0/5 *)

(** ** Κανονικές μορφές *)

Lemma canonical_forms_bool : forall Sigma t,
    Sigma ; empty ⊢ t : Bool ->
    value t ->
    (t = <[ true ]>) \/ (t = <[ false ]>).
Proof.
  intros Sigma t Htyp Hval.
  inv Hval; inv Htyp.
  destruct b; auto.
Qed.

Lemma canonical_forms_nat : forall Sigma t,
    Sigma ; empty ⊢ t : Nat ->
    value t ->
    exists (n : nat), t = <[ n ]>.
Proof.
  intros Sigma t Htyp Hval.
  inv Hval; inv Htyp. eauto.
Qed.

Lemma canonical_forms_fun : forall Sigma t A B,
    Sigma ; empty ⊢ t : (A -> B) ->
    value t ->
    exists x u, t = <[ fun x : A -> u ]>.
Proof.
  intros Sigma t A B Htyp Hval.
  inv Hval; inv Htyp. eauto.
Qed.

Lemma canonical_forms_sum : forall Sigma t A B,
    Sigma ; empty ⊢ t : (A + B) ->
    value t ->
    (exists v, t = <[ inl B v ]> /\ value v) \/
    (exists v, t = <[ inr A v ]> /\ value v).
Proof.
  intros Sigma t A B Htyp Hval.
  inv Hval; inv Htyp; eauto.
Qed.

Lemma canonical_forms_prod : forall Sigma t A B,
    Sigma ; empty ⊢ t : (A * B) ->
    value t ->
    exists v1 v2, t = <[ (v1, v2) ]> /\ value v1 /\ value v2.
Proof.
  intros Sigma t A B Htyp Hval.
  inv Hval; inv Htyp; eauto.
Qed.

(** Άσκηση 3 *)
Lemma canonical_forms_ref : forall Sigma t A,
    Sigma ; empty ⊢ t : (Ref A) ->
    value t ->
    exists l, t = <[ loc l ]>.
Proof.
  (* ___ FILL IN HERE ___ *)
Admitted.

(* [canonical_forms_ref] grade 0/3 *)

(** ** Progress *)

(** *** Άσκηση 4.2 *)

(** Η διατύπωση του progress από τις σημειώσεις, προσαρμοσμένη σε
    μνήμες. *)
Definition progress_old : Prop :=
  forall t T Sigma s,
    Sigma ; empty ⊢ t : T ->
    store_well_typed Sigma s ->
    value t \/ exists t' s', t / s --> t' / s'.

(** Αποδείξτε ότι δεν ισχύει. *)
Lemma progress_old_false : ~ progress_old.
Proof.
  (* ___ FILL IN HERE ___ *)
Admitted.

(* [progress_old_false] grade 0/5 *)

(** *** Ασκήσεις 4.3 και 5.1 *)

(** Αντικαταστήστε το [True] με το σωστό συμπέρασμα του progress
    (Άσκηση 4.3). Μην αλλάξετε την υπόλοιπη διατύπωση.

    Η απόδειξη για τις δομές των σημειώσεων δίνεται παρακάτω, σε σχόλιο,
    και είναι γραμμένη για τη σωστή διατύπωση. Αφού γράψετε τη
    διατύπωση:
    1. σβήστε το [Admitted] και τα σύμβολα σχολίου γύρω από τη δοσμένη
       απόδειξη,
    2. προσθέστε τις περιπτώσεις για τους νέους κανόνες τύπων σας
       (Άσκηση 5.1). *)

Theorem progress : forall t T Sigma s,
    Sigma ; empty ⊢ t : T ->
    store_well_typed Sigma s ->
    (* ___ FILL IN HERE ___ *)
    True.
Proof.
Admitted.
(*
Proof.
  intros t T Sigma s Ht Hst.
  remember empty as Gamma.
  induction Ht; subst.
  - (* Ty_Var *)
    discriminate H.
  - (* Ty_Abs *)
    left. constructor.
  - (* Ty_App *)
    right. right.
    destruct IHHt1 as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    destruct IHHt2 as [Hv2 | [-> | [t2' [s2' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    destruct (canonical_forms_fun Sigma t1 A B Ht1 Hv1) as [x [u ->]].
    eauto.
  - (* Ty_Let *)
    right. right.
    destruct IHHt1 as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | now eauto | now eauto | now eauto ].
  - (* Ty_Bool *)
    left. constructor.
  - (* Ty_If *)
    right. right.
    destruct IHHt1 as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    destruct (canonical_forms_bool Sigma t1 Ht1 Hv1) as [-> | ->]; eauto.
  - (* Ty_BopBool *)
    right. right.
    destruct IHHt1 as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    destruct IHHt2 as [Hv2 | [-> | [t2' [s2' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    edestruct is_bool_op_lemma as [f Hf]; [ eassumption | ].
    destruct (canonical_forms_bool Sigma t1 Ht1 Hv1) as [-> | ->];
      destruct (canonical_forms_bool Sigma t2 Ht2 Hv2) as [-> | ->]; eauto.
  - (* Ty_UOp *)
    right. right.
    (* [Neg] is the only unary operator *)
    match goal with |- context [ T_UOp ?op _ ] => destruct op end.
    destruct IHHt as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    destruct (canonical_forms_bool Sigma t1 Ht Hv1) as [-> | ->]; eauto.
  - (* Ty_Nat *)
    left. constructor.
  - (* Ty_BopNat *)
    right. right.
    destruct IHHt1 as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    destruct IHHt2 as [Hv2 | [-> | [t2' [s2' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    edestruct is_nat_op_lemma as [f Hf]; [ eassumption | ].
    destruct (canonical_forms_nat Sigma t1 Ht1 Hv1) as [n1 ->].
    destruct (canonical_forms_nat Sigma t2 Ht2 Hv2) as [n2 ->].
    eauto.
  - (* Ty_BopCmp *)
    right. right.
    destruct IHHt1 as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    destruct IHHt2 as [Hv2 | [-> | [t2' [s2' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    edestruct is_cmp_op_lemma as [f Hf]; [ eassumption | ].
    destruct (canonical_forms_nat Sigma t1 Ht1 Hv1) as [n1 ->].
    destruct (canonical_forms_nat Sigma t2 Ht2 Hv2) as [n2 ->].
    eauto.
  - (* Ty_Pair *)
    destruct IHHt1 as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | | right; right; now eauto | right; right; now eauto ].
    destruct IHHt2 as [Hv2 | [-> | [t2' [s2' Hstp]]]];
      [ reflexivity | left; now eauto | right; right; now eauto | right; right; now eauto ].
  - (* Ty_Fst *)
    right. right.
    destruct IHHt as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    destruct (canonical_forms_prod Sigma t1 A B Ht Hv1) as [v1 [v2 [-> [Hv1' Hv2']]]].
    eauto.
  - (* Ty_Snd *)
    right. right.
    destruct IHHt as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    destruct (canonical_forms_prod Sigma t1 A B Ht Hv1) as [v1 [v2 [-> [Hv1' Hv2']]]].
    eauto.
  - (* Ty_Inl *)
    destruct IHHt as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | left; now eauto | right; right; now eauto | right; right; now eauto ].
  - (* Ty_Inr *)
    destruct IHHt as [Hv1 | [-> | [t1' [s1' Hstp]]]];
      [ reflexivity | left; now eauto | right; right; now eauto | right; right; now eauto ].
  - (* Ty_Case *)
    right. right.
    destruct IHHt1 as [Hv | [-> | [t' [s' Hstp]]]];
      [ reflexivity | | now eauto | now eauto ].
    destruct (canonical_forms_sum Sigma t A B Ht1 Hv) as [[v [-> Hv']] | [v [-> Hv']]];
      eauto.
  - (* Ty_Unit *)
    left. constructor.
  (* Άσκηση 5.1 *)
  (* ___ FILL IN HERE ___ *)
Qed.
*)

(* [progress_statement] grade 0/5 *)

(* [progress] grade 0/10 *)

(** ** Weakening *)

Lemma weakening : forall Sigma Gamma Gamma' t A,
    submap Gamma Gamma' ->
    Sigma ; Gamma ⊢ t : A ->
    Sigma ; Gamma' ⊢ t : A.
Proof.
  intros Sigma Gamma Gamma' t A Hsub Ht.
  revert Gamma' Hsub.
  induction Ht; eauto 7 using submap_update.
Qed.

Corollary weakening_empty : forall Sigma Gamma t A,
    Sigma ; empty ⊢ t : A ->
    Sigma ; Gamma ⊢ t : A.
Proof.
  intros Sigma Gamma t A.
  eapply weakening.
  discriminate.
Qed.

(** ** Η αντικατάσταση διατηρεί τους τύπους *)

Lemma substitution_preserves_typing : forall Sigma Gamma x v t A B,
    Sigma ; (x |-> B ; Gamma) ⊢ t : A ->
    Sigma ; empty ⊢ v : B ->
    Sigma ; Gamma ⊢ [x:=v]t : A.
Proof.
  intros Sigma Gamma x v t A B Ht Hv.
  revert Gamma A Ht Hv.
  induction t; intros Gamma A Ht1 Ht2; inv Ht1; simpl; eauto.
  - (* T_Abs *)
    destruct (String.eqb_spec x s); subst; apply Ty_Abs.
    + (* x = s *)
      rewrite update_shadow in H4. assumption.
    + (* x <> s *)
      apply IHt; auto.
      rewrite update_permute; auto.
  - (* T_Var *)
    destruct (String.eqb_spec x s); subst.
    + (* x = s *)
      rewrite update_eq in H1. inv H1.
      apply weakening_empty. assumption.
    + (* x <> y *)
      apply Ty_Var. rewrite update_neq in H1; auto.
  - (* T_let *)
    eapply Ty_Let.
    + eapply IHt1; eauto.
    + destruct (String.eqb_spec x s); subst.
      * (* x = s *)
        rewrite update_shadow in H5. assumption.
      * (* x <> s *)
        eapply IHt2; auto.
        rewrite update_permute; eauto.
  - (* T_Case *)
    eapply Ty_Case.
    + now eauto.
    + destruct (String.eqb_spec x s); subst.
      * (* x = s *)
        rewrite update_shadow in H7. assumption.
      * (* x <> s *)
        apply IHt2.
        rewrite update_permute; auto.
        assumption.
    + destruct (String.eqb_spec x s0); subst.
      * (* x = s0 *)
        rewrite update_shadow in H8. assumption.
      * (* x <> s0 *)
        apply IHt3.
        rewrite update_permute; auto.
        assumption.
Qed.

(** ** Preservation *)

(** Τρεις τακτικές που χρησιμοποιούνται στην απόδειξη του
    preservation. Μπορείτε να τις χρησιμοποιήσετε και στις δικές σας
    περιπτώσεις. *)

(** [impossible_op]: κλείνει περιπτώσεις όπου ένας τελεστής
    χρησιμοποιείται με λάθος τύπο, π.χ. [is_nat_op op = true] και
    [cmp_op op = Some f]. *)
Ltac impossible_op :=
  match goal with
  | H : is_bool_op ?op = true |- _ => destruct op; simpl in *; congruence
  | H : is_nat_op ?op = true |- _ => destruct op; simpl in *; congruence
  | H : is_cmp_op ?op = true |- _ => destruct op; simpl in *; congruence
  end.

(** [same_store]: για βήματα που δεν αλλάζουν τον τύπο μνήμης.
    Επιλέγει [Sigma' = Sigma]. Μένουν δύο στόχοι: ο νέος όρος έχει τον
    ίδιο τύπο, και η νέα μνήμη είναι well typed. *)
Ltac same_store :=
  match goal with
  | |- exists Sigma', extends Sigma' ?Sigma /\ _ /\ _ =>
      exists Sigma; split; [ apply extends_refl | split ]
  end.

(** [use_IH IH]: για βήματα μέσα σε έναν υποόρο. Χρησιμοποιεί την
    επαγωγική υπόθεση [IH] για τον υποόρο, η οποία δίνει έναν νέο τύπο
    μνήμης [Sigma'] που επεκτείνει τον [Sigma], τον τύπο του νέου
    υποόρου ως προς [Sigma'] ([Hty']), και ότι η νέα μνήμη είναι well
    typed ως προς [Sigma'] ([Hst']). Μένει ένας στόχος: ο νέος όρος έχει
    τον ίδιο τύπο ως προς [Sigma']. *)
Ltac use_IH IH :=
  edestruct IH as [Sigma' [Hext [Hty' Hst']]];
  [ reflexivity | eassumption | eassumption |
    exists Sigma'; split; [ exact Hext | split; [ | exact Hst' ] ] ].

(** *** Άσκηση 5.2 *)

(** Η απόδειξη για τις δομές των σημειώσεων δίνεται παρακάτω, σε σχόλιο,
    επειδή χρησιμοποιεί τον κανόνα [Ty_Error] (Άσκηση 4.1). Αφού
    προσθέσετε τον κανόνα [Ty_Error]:
    1. σβήστε το [Admitted] και τα σύμβολα σχολίου γύρω από τη δοσμένη
       απόδειξη,
    2. προσθέστε τις περιπτώσεις για τους νέους κανόνες τύπων σας
       (Άσκηση 5.2). *)

Theorem preservation : forall t t' s s' T Sigma,
    Sigma ; empty ⊢ t : T ->
    store_well_typed Sigma s ->
    t / s --> t' / s' ->
    exists Sigma',
      extends Sigma' Sigma /\
      Sigma' ; empty ⊢ t' : T /\
      store_well_typed Sigma' s'.
Proof.
Admitted.
(*
Proof.
  intros t t' s s' T Sigma Ht. revert t' s'.
  remember empty as Gamma.
  induction Ht; intros t' s' Hst Hstep; subst.
  - (* Ty_Var *)
    inv Hstep.
  - (* Ty_Abs *)
    inv Hstep.
  - (* Ty_App *)
    inv Hstep.
    + (* Step_AppAbs *)
      same_store; [ | assumption ].
      inv Ht1. eapply substitution_preserves_typing; eauto.
    + (* Step_App1 *)
      use_IH IHHt1. eauto using store_weakening.
    + (* Step_App2 *)
      use_IH IHHt2. eauto using store_weakening.
    + (* Step_AppErr1 *)
      same_store; auto.
    + (* Step_AppErr2 *)
      same_store; auto.
  - (* Ty_Let *)
    inv Hstep.
    + (* Step_LetVal *)
      same_store; [ | assumption ].
      eapply substitution_preserves_typing; eauto.
    + (* Step_Let *)
      use_IH IHHt1. eauto using store_weakening.
    + (* Step_LetErr *)
      same_store; auto.
  - (* Ty_Bool *)
    inv Hstep.
  - (* Ty_If *)
    inv Hstep; try (same_store; now auto).
    (* Step_If *)
    use_IH IHHt1. eauto using store_weakening.
  - (* Ty_BopBool *)
    (* Οι περιπτώσεις όπου ο τελεστής έχει λάθος τύπο είναι αδύνατες. *)
    inv Hstep; try (same_store; now auto); try impossible_op.
    + (* Step_Bop1 *)
      use_IH IHHt1. eauto using store_weakening.
    + (* Step_Bop2 *)
      use_IH IHHt2. eauto using store_weakening.
  - (* Ty_UOp *)
    inv Hstep; try (same_store; now auto).
    (* Step_UOp *)
    use_IH IHHt. eauto using store_weakening.
  - (* Ty_Nat *)
    inv Hstep.
  - (* Ty_BopNat *)
    (* Οι περιπτώσεις όπου ο τελεστής έχει λάθος τύπο είναι αδύνατες. *)
    inv Hstep; try (same_store; now auto); try impossible_op.
    + (* Step_Bop1 *)
      use_IH IHHt1. eauto using store_weakening.
    + (* Step_Bop2 *)
      use_IH IHHt2. eauto using store_weakening.
  - (* Ty_BopCmp *)
    (* Οι περιπτώσεις όπου ο τελεστής έχει λάθος τύπο είναι αδύνατες. *)
    inv Hstep; try (same_store; now auto); try impossible_op.
    + (* Step_Bop1 *)
      use_IH IHHt1. eauto using store_weakening.
    + (* Step_Bop2 *)
      use_IH IHHt2. eauto using store_weakening.
  - (* Ty_Pair *)
    inv Hstep; try (same_store; now auto).
    + (* Step_Pair1 *)
      use_IH IHHt1. eauto using store_weakening.
    + (* Step_Pair2 *)
      use_IH IHHt2. eauto using store_weakening.
  - (* Ty_Fst *)
    inv Hstep; try (same_store; now auto).
    + (* Step_FstPair *)
      same_store; [ | assumption ].
      inv Ht. assumption.
    + (* Step_Fst *)
      use_IH IHHt. eauto using store_weakening.
  - (* Ty_Snd *)
    inv Hstep; try (same_store; now auto).
    + (* Step_SndPair *)
      same_store; [ | assumption ].
      inv Ht. assumption.
    + (* Step_Snd *)
      use_IH IHHt. eauto using store_weakening.
  - (* Ty_Inl *)
    inv Hstep; try (same_store; now auto).
    (* Step_Inl *)
    use_IH IHHt. eauto using store_weakening.
  - (* Ty_Inr *)
    inv Hstep; try (same_store; now auto).
    (* Step_Inr *)
    use_IH IHHt. eauto using store_weakening.
  - (* Ty_Case *)
    inv Hstep; try (same_store; now auto).
    + (* Step_Case *)
      use_IH IHHt1. eauto using store_weakening.
    + (* Step_CaseInl *)
      same_store; [ | assumption ].
      inv Ht1. eapply substitution_preserves_typing; eauto.
    + (* Step_CaseInr *)
      same_store; [ | assumption ].
      inv Ht1. eapply substitution_preserves_typing; eauto.
  - (* Ty_Unit *)
    inv Hstep.
  (* Άσκηση 5.2 *)
  (* ___ FILL IN HERE ___ *)
Qed.
*)

(* [preservation] grade 0/15 *)

(** ** Tests *)

(** Αν οι ορισμοί σας είναι σωστοί, τα παρακάτω tests επιτυγχάνουν.
    Για να τρέξετε ένα test, σβήστε το [Admitted] και τα σύμβολα σχολίου
    γύρω από την απόδειξή του. *)

(** Hints για τα tests: ισότητες όπως [Gamma x = Some A] και
    [nat_op Plus = Some f] λύνονται με υπολογισμό, και ανισότητες
    [l < length s] με [lia]. *)
#[global] Hint Extern 1 (_ = _) => reflexivity : core.
#[global] Hint Extern 1 (_ < _) => simpl; lia : core.

(** Η τακτική [typecheck] κατασκευάζει μια παραγωγή τύπων,
    ακολουθώντας τη δομή του όρου. *)
Ltac typecheck :=
  repeat match goal with
         | |- _ ; _ ⊢ { T_BOp _ _ _ } : _ =>
             first [ eapply Ty_BopNat; [ | | reflexivity ]
                   | eapply Ty_BopBool; [ | | reflexivity ]
                   | eapply Ty_BopCmp; [ | | reflexivity ] ]
         | |- _ ; _ ⊢ _ : _ => econstructor
         | |- _ = _ => reflexivity
         end.

(** Η τακτική [normalize] αποτιμά ένα πρόγραμμα βήμα-βήμα. *)
Ltac normalize :=
  repeat (eapply multi_step; [ solve [ eauto 20 ] | simpl ]);
  apply multi_refl.

Definition f : string := "f".
Definition x : string := "x".
Definition n : string := "n".
Definition c : string := "c".
Definition r : string := "r".
Definition u : string := "u".
Definition fact : string := "fact".

(** Παραγοντικό με let rec. *)
Definition fact_rec (k : nat) : term :=
  <[ let rec fact (n : Nat) : Nat := if n = 0 then 1 else n * fact (n - 1) in
     fact k ]>.

Example fact_rec_typed : [] ; empty ⊢ {fact_rec 4} : Nat.
Admitted.
(* Proof. unfold fact_rec. apply letrec_typing; typecheck. Qed. *)

Example fact_rec_eval : exists s, fact_rec 4 / [] -->* <[ 24 ]> / s.
Admitted.
(* Proof. eexists. unfold fact_rec, letrec. normalize. Qed. *)

(** Μια θέση μνήμης. *)
Example loc_typed : [Nat] ; empty ⊢ loc 0 : (Ref Nat).
Admitted.
(* Proof. typecheck. Qed. *)

(** Ένας μετρητής. *)
Definition counter : term :=
  <[ let c := ref 40 in
     let u := c ::= !c + 1 in
     let u := c ::= !c + 1 in
     !c ]>.

Example counter_typed : [] ; empty ⊢ counter : Nat.
Admitted.
(* Proof. unfold counter. typecheck. Qed. *)

Example counter_eval : counter / [] -->* <[ 42 ]> / [T_Nat 42].
Admitted.
(* Proof. unfold counter. normalize. Qed. *)

(** Αναδρομή μέσω της μνήμης: παραγοντικό χωρίς [fix]. *)
Definition fact_knot (k : nat) : term :=
  <[ let r := ref (fun n : Nat -> 0) in
     let fact := fun n : Nat -> if n = 0 then 1 else n * (!r) (n - 1) in
     let u := r ::= fact in
     fact k ]>.

Example fact_knot_typed : [] ; empty ⊢ {fact_knot 4} : Nat.
Admitted.
(* Proof. unfold fact_knot. typecheck. Qed. *)

Example fact_knot_eval : exists s, fact_knot 4 / [] -->* <[ 24 ]> / s.
Admitted.
(* Proof. eexists. unfold fact_knot. normalize. Qed. *)

(** Σφάλματα. *)
Example error_eval1 : <[ ref (1 + error) ]> / [] -->* <[ error ]> / [].
Admitted.
(* Proof. normalize. Qed. *)

Example error_eval2 : <[ (ref 1) ::= error ]> / [] -->* <[ error ]> / [T_Nat 1].
Admitted.
(* Proof. normalize. Qed. *)

Example error_eval3 : <[ fix (! error) ]> / [] -->* <[ error ]> / [].
Admitted.
(* Proof. normalize. Qed. *)
