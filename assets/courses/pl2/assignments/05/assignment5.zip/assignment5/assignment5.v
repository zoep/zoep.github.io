From Stdlib Require Import Strings.String Arith.Arith Lists.List.

Import ListNotations.

From Assignment5 Require Import miniML.

Open Scope ML_scope.

(** Στοιχεία Σπουδαστή
Όνομα:
ΑΜ:
*)


(** * Εργασία 5 (100 μονάδες ) *)

(** Ο σκοπός αυτής της εργασίας είναι να εξοικειωθείτε με τον λάμβδα λογισμό και
    τις επεκτάσεις του.

    Οδηγίες:

    - Το παραδοτέο αρχείο θα πρέπει να κάνει compile. Αυτό μπορείτε να το
      ελέγξετε στο terminal σας εκτελώντας `make` μέσα στο directory της
      άσκησης (ή με την εντολή `rocq compile -R . Assignment5 assignment5.v`). Τα αρχεία
      που δεν κάνουν compile δεν θα βαθμολογούνται.

    - Μην αλλάζετε τον κώδικα που σας έχει δοθεί. Μην γράφετε μέσα στα σχόλια
      της βαθμολόγησης. Αυτό είναι απαραίτητο για την ομαλή και έγκαιρη
      βαθμολόγηση των εργασιών. Μπορείτε να γράψετε όπου υπάρχει η οδηγία (* ___
      FILL IN HERE ___ *). Εάν σας εξυπηρετεί,
      μπορείτε να ορίζετε βοηθητικές συναρτήσεις, λήμματα, ορισμούς,
      κ.α.

    - Μην αλλάζετε τα ονόματα των αρχείων. Γράψτε τις απαντήσεις σας
      μόνο σε αυτό το αρχείο. Οι ασκήσεις 2 και 3 δεν απαιτούν κώδικα.

    - Συμπληρώστε σωστά τα στοιχεία σας στην αρχή του αρχείου. Αυτό
      είναι απαραίτητο για τη σωστή βαθμολόγηση των εργασιών. *)

(** ** Άσκηση 1: Interpreter για miniML (60 μονάδες) *)

Module Interpreter.

  (** Η άσκηση αυτή σας ζητά να γράψετε έναν interpreter για την miniML των
      σημειώσεων την οποία έχουμε επεκτείνει με αναφορές και αναδρομή.
      Συγκεκριμένα, επεκτείνουμε τη γλώσσα μας με τις εξής δομές:

      Τύποι:

      A := ... | Ref A

      Όροι:

      t, u := let ref f (x : A) : B := e1 in e2 | ref t | !t | t ::= u

      Η δομή [let ref f (x : A) : B := e1 in e2] μας επιτρέπει να ορίσουμε μια
      αναδρομική συνάρτηση με όνομα [f], ένα όρισμα με όνομα [x] και τύπο [A],
      και τύπο επιστροφής [B].

      Σε γλώσσες σαν την ML, o τύπος [ref A] υποδηλώνει τιμές τύπου [Α] οι
      οποίες όμως μπορεί να αλλάξουν μέσω ανάθεσης. Λειτουργούν σαν ένα "κουτί
      μνήμης" του οποίου η τιμή μπορεί να αλλάξει.

      Ορίζουμε μία αναφορά με τον όρο [ref t], ο οποίος δημιουργεί μια νέα θέση
      μνήμης και βάζει μέσα την τιμή του όρου [t].

      Μια αναφορά μπορεί να αλλάξει τιμή με μια ανάθεση [t ::= u]. Μπορούμε να
      διαβάσουμε την τιμή που είναι αποθηκευμένη σε μια αναφορά με τον τελεστή
      [!t].

      Για παράδειγμα, το παρακάτω πρόγραμμα επιστρέφει 42.

      let counter := ref 40 in let _ := counter ::= !counter + 1 in let _ :=
      counter ::= !counter + 1 in !counter *)
  
  (** Ο interpreter που θα γράψουμε είναι επί της ουσίας μια big-step
      σημασιολογία για τη γλώσσα μας, που όμως την έχουμε ορίσει ως συνάρτηση
      αντί για μαθηματική σχέση, προκειμένου να μπορούμε να κάνουμε
      υπολογισμούς. Καθώς όταν υπάρχει αναδρομή, ο interpreter ενδέχεται να μην
      τερματίζει. Για να ορίσουμε μια τέτοια συνάρτηση στο Rocq, περνάμε μια
      επιπλέον παράμετρο, το fuel, την οποία μειώνουμε σε κάθε αναδρομική κλήση.

      Αντί να κάνουμε αντικαταστάσεις, που μας αναγκάζουν να διατρέξουμε το σώμα
      μιας συνάρτησης κάθε φορά που κάνουμε μια εφαρμογή συνάρτησης, θα
      χρησιμοποιήσουμε ένα περιβάλλον, που απεικονίζει τις μεταβλητές στις τιμές
      τους.

      Επιπλέον, καθώς έχουμε αναφορές, χρειαζόμαστε και μια "σωρό" που
      απεικονίζει τα κουτάκια μνήμης (που αναπαριστούμε ως φυσικούς αριθμούς)
      στις τιμές τους. *)


  (** Ορίζουμε key-value stores για να αναπαραστήσουμε τα περιβάλλοντα και τη
      σωρό του προγράμματός μας.

      Η συγκεκριμένη υλοποίηση χρησιμοποιεί λίστες. Αν μας ενδιέφερε η
      αποδοτικότητα της υλοποίησής μας, θα μπορούσαμε να χρησιμοποιήσουμε κάποια
      δομή βασισμένη σε δέντρα, που παρέχει η standard library του Rocq. *)
  
  Definition map (K V : Type) : Type := list (K * V).
  
  Definition empty {K V : Type} : map K V := [].

  Definition lookup_map {K V : Type} (eqb : K -> K -> bool) (key : K) (m : map K V) : option V :=
    match find (fun '(k, _) => eqb k key) m with
    | Some (_, v) => Some v
    | None => None
    end.

  Definition extend_map {K V : Type} (key : K) (val : V) (m : map K V) : map K V :=
    (key, val) :: m.


  (** Περιβάλλοντα: τα κλειδιά είναι μεταβλητές *)
  Definition env (T : Type) : Type := map string T.
  Definition lookup_env {T} (key : string) (e : env T) : option T :=  lookup_map String.eqb key e.
  Definition extend_env {T} (key : string) (v : T) (e : env T) : env T := extend_map key v e.


  (** Σωρός: τα κλειδιά είναι φυσικοί αριθμοί *)
  Definition store (T : Type) : Type := map nat T. 
  Definition lookup_store {T} (key : nat) (e : store T) : option T :=  lookup_map Nat.eqb key e.
  Definition extend_store {T} (key : nat) (v : T) (e : store T) : store T := extend_map key v e.


  (** Ορίζουμε τον τύπο που αντιστοιχεί στους αποτιμημένους όρους της γλώσσας
      μας, που θα είναι και ο τύπος επιστροφής του interpreter.

      Προσέξτε ότι υπάρχει μια ειδική τιμή που ονομάζεται closure: πρόκειται για
      μια συνάρτηση μαζί με το περιβάλλον στο οποίο ορίστηκε.
   *)

  Inductive value : Type :=
  | V_Bool : bool -> value
  | V_Nat : nat -> value
  | V_Closure : string -> string -> term -> env value -> value
  | V_Pair : value -> value -> value
  | V_Inl : value -> value
  | V_Inr : value -> value
  | V_Loc : nat -> value
  | V_Unit : value.


  (** Σας δείνεται ο βασικός σκελετός του interpreter, και σας
      ζητείται να συμπληρώσετε τις "ενδιαφέρουσες" περιπτώσεις. *)

  (** Βοηθητική συνάρτηση για την αποτίμηση δυαδικών τελεστών. *)
  Definition eval_bop (op : bop) (v1 v2 : value) : option value :=
    match op, v1, v2 with
    | Plus, V_Nat n1, V_Nat n2 => Some (V_Nat (n1 + n2))
    | Minus, V_Nat n1, V_Nat n2 => Some (V_Nat (n1 - n2))
    | Mult, V_Nat n1, V_Nat n2 => Some (V_Nat (n1 * n2))
    | And, V_Bool b1, V_Bool b2 => Some (V_Bool (b1 && b2))
    | Or, V_Bool b1, V_Bool b2 => Some (V_Bool (b1 || b2))
    | Lt, V_Nat n1, V_Nat n2 => Some (V_Bool (n1 <? n2))
    | Eq, V_Nat n1, V_Nat n2 => Some (V_Bool (n1 =? n2))
    | Eq, V_Bool b1, V_Bool b2 => Some (V_Bool (Bool.eqb b1 b2))
    | _, _, _ => None
    end.

  (** Βοηθητική συνάρτηση για την αποτίμηση μοναδιαίων τελεστών. *)
  Definition eval_uop (op : uop) (v : value) : option value :=
    match op, v with
    | Neg, V_Bool b => Some (V_Bool (negb b))
    | _, _ => None
    end.

  (** Η συνάρτηση αυτή επιστρέφει την επόμενη διαθέσιμη θέση μνήμης για δέσμευση.
      Πρέπει να συμπληρώσετε τον σωστό ορισμό. *)
  Definition next_loc (s : store value) : nat := 42.

  (* Το αποτέλεσμα της αποτίμησης. *)
  Inductive result :=
  | Res : value * store value -> result
  | Error : string -> result (* σφάσμα εκτέλεσης *)
  | OutOfFuel : term * env value * store value -> result (* το fuel τελείωσε *). 

  
  (** Ο interpreter *)
  Fixpoint eval (fuel : nat) (env : env value) (s : store value) (t : term) : result :=
    match fuel with
    | 0 => OutOfFuel (t, env, s)
    | S fuel' =>
        match t with
        | T_Var x => Error "Fill in here!"
        | T_Nat n => Res (V_Nat n, s)
        | T_Bool b => Res (V_Bool b, s)
        | T_Lambda x ty body => Error "Fill in here!"
        | T_App t1 t2 => Error "Fill in here!"
        | T_LetRec f x T1 T2 t1 t2 => Error "Fill in here!"
        | T_Let x t1 t2 =>
            match eval fuel' env s t1 with
            | Res (v1, s1) =>
                let new_env := extend_env x v1 env in
                eval fuel' new_env s1 t2
            | res => res
            end
        | T_If t1 t2 t3 =>
            match eval fuel' env s t1 with
            | Res (V_Bool true, s1) => eval fuel' env s1 t2
            | Res (V_Bool false, s1) => eval fuel' env s1 t3
            | Res _ => Error "Expecting a boolean"
            | res => res
            end
        | T_BOp op t1 t2 =>
            match eval fuel' env s t1 with
            | Res (v1, s1) =>
                match eval fuel' env s1 t2 with
                | Res (v2, s2) =>
                    match eval_bop op v1 v2 with
                    | Some v => Res (v, s2)
                    | None => Error "Error when evaluating binary operator"
                    end
                | res => res
                end
            | res => res
            end
        | T_UOp op t1 =>
            match eval fuel' env s t1 with
            | Res (v1, s1) =>
                match eval_uop op v1 with
                | Some v => Res (v, s1)
                | None => Error "Error when evaluating unary operator"
                end
            | res => res
            end
        | T_Pair t1 t2 =>
            match eval fuel' env s t1 with
            | Res (v1, s1) =>
                match eval fuel' env s1 t2 with
                | Res (v2, s2) => Res (V_Pair v1 v2, s2)
                | res => res
                end
            | res => res
            end
        | T_Fst t1 =>
            match eval fuel' env s t1 with
            | Res (V_Pair v1 v2, s1) => Res (v1, s1)
            | Res _ => Error "Expecting a pair"
            | res => res
            end
        | T_Snd t1 =>
            match eval fuel' env s t1 with
            | Res (V_Pair v1 v2, s1) => Res (v2, s1)
            | Res _ => Error "Expecting a pair"
            | res => res
            end
        | T_Inl ty t1 => Error "Fill in here!"
        | T_Inr ty t1 => Error "Fill in here!"
        | T_Case t0 x1 t1 x2 t2 => Error "Fill in here!"
        | T_Ref t1 => Error "Fill in here!"
        | T_Deref t1 => Error "Fill in here!"
        | T_Assign t1 t2 => Error "Fill in here!"
        end
    end.

  (* [eval] grade 0/40 *)

  (** Convenience function to run interpreter with empty environment and store. *)
  Definition run_eval (fuel : nat) (t : term) : option value :=
    match eval fuel empty empty t with
    | Res (v, _) => Some v
    | _ => None
    end.

  Definition x := "x"%string.
  Definition z := "z"%string.
  Definition y := "y"%string.
  Definition f := "f"%string.
  Definition fact := "fact"%string.


  (* Εάν ο ορισμός σας είναι σωστός, τα παρακάτω tests θα πρέπει να επιτυγχάνουν *)

  Example test_app : 
    run_eval 100 <[ (fun x : Nat => x + 1) 5 ]> = Some (V_Nat 6).
  Admitted.
  (* Proof. compute. reflexivity. Qed. *)

  
  Example test_closure :
    run_eval 100 <[ let x := 10 in
                    let f := fun y : Nat => x + y in
                    let x := 5 in
                    f 3 ]> = Some (V_Nat 13).
  Admitted.
  (* Proof. compute. reflexivity. Qed. *)


  Definition fact5 :=
    <[ let rec fact ( x : Nat ) : Nat := if x = 0 then 1 else x * fact (x - 1) in fact 5 ]>.  

  Example test_fact5:
    run_eval 1000 <[ fact5 ]> = Some (V_Nat 120).
  Admitted.
  (* Proof. compute. reflexivity. Qed. *)

  Example test_ref1:
    run_eval 1000 <[ let x := ref 0 in let z := x ::= 42 in !x ]> = Some (V_Nat 42).
  Admitted.
  (* Proof. compute. reflexivity. Qed. *)

  Example test_ref2:
    run_eval 100 <[ let x := ref 31 in
                    let y := ref 11 in
                    let z := y ::= !x + !y  in
                    !y ]> = Some (V_Nat 42).
  Admitted.
  (* Proof. compute. reflexivity. Qed. *)


  (** Χωρίς να χρησιμοποιήσετε το let rec, γράψτε

      1. Ένα πρόγραμμα που δεν τερματίζει

      2. Ένα πρόγραμμα που υπολογίζει το factorial

      Χρησιμοποιήστε αναφορές για να υλοποιήσετε τα προγράμματα. *)


  Definition loop : term (* := ___ FILL IN HERE ___ *).
  Admitted.

  (* [loop] grade 0/10 *)

  Example test_loop:
    exists t s, eval 1000 empty empty loop = OutOfFuel (t, s).
  Admitted.
  (* Proof. eexists. eexists. compute. reflexivity. Qed. *)


  Definition fact_ref (n : nat) : term (* := ___ FILL IN HERE ___ *).
  Admitted.

  (* [fact_ref] grade 0/10 *)

  Example test_fact_ref:
    run_eval 1000 (fact_ref 5) = Some (V_Nat 120).
  Admitted.
  (* Proof. compute. reflexivity. Qed. *)
              
End Interpreter.


(* Άσκηση 2: Ασφάλεια τύπων για την MiniML: trapped and untrapped errors (20 μονάδες) *)

(* Το θεώρημα ασφάλειας τύπων (type safety) για την miniML μας λέει ότι ένας
   well-typed όρος είτε είναι ήδη τιμή (αποτιμημένος), είτε μπορεί να κάνει ένα
   βήμα αναγωγής σε έναν well-typed όρο. Με άλλα λόγια, ένας well-typed όρος δεν
   μπορεί να "κολλήσει" (stuck) κατά την εκτέλεση.

   Έστω ότι επεκτείνουμε τη γλώσσα με τον τελεστή διαίρεσης (/) και ορίζουμε ότι
   η διαίρεση με το 0 αποτελεί ένα (trapped) σφάλμα κατά την εκτέλεση.

   Ερωτήσεις:

   α) Θα ίσχυαν τα θεωρήματα progress και preservation όπως τα ξέρουμε; Εξηγήστε
      γιατί ναι ή γιατί όχι.

   β) Πώς θα προσαρμόζατε την small-step σημασιολογία της γλώσσας ώστε να
      μοντελοποιήσει το σφάλμα διαίρεσης με το 0;

   γ) Πώς θα προσαρμόζατε τα θεωρήματα progress και preservation ώστε το θεώρημα
      ασφάλειας τύπων να λέει ότι: "ένας well-typed όρος δεν μπορεί να κολλήσει,
      αλλά μπορεί να οδηγήσει σε κάποιο trapped error (όπως διαίρεση με το 0)";

   Περιγράψτε με συντομία και σαφήνεια τις αλλαγές που θα κάνατε στη
   σημασιολογία και στα θεωρήματα. Δεν χρειάζεται να ορίσετε κάτι στο Rocq, αλλά
   να εξηγήσετε τη λογική σας με σαφήνεια.
*)


(* [trapped_errors] grade 0/20 *)

(* Άσκηση 3: Τελεστής fix (20 μονάδες) *)

(* Στον λάμβδα λογισμό χωρίς τύπους είδαμε ότι μπορούμε να ορίσουμε την αναδρομή
   με έναν συνδυαστή σταθερού σημείου (fixed-point combinator). Κάτι τέτοιο δεν
   είναι δυνατό στον λάμβδα λογισμό με τύπους. Ωστόσο, μπορούμε να ορίσουμε έναν
   πρωτογενή τελεστή [fix] που έχει την ίδια σημασιολογία με τον συνδυαστή
   σταθερού σημείου. Χρησιμοποιώντας αυτόν τον τελεστή, μπορούμε να ορίσουμε το
   let-rec ως παραγόμενη μορφή.

   Συμπληρώστε τη στατική και δυναμική σημασιολογία ενός τέτοιου τελεστή και
   ορίστε το let-rec με βάση το fix.

   Θα σας φανεί χρήσιμο το βιβλίο "Types and Programming Languages". 

*)

(* Στατική σημασιολογία: 


                ???
       -----------------------------------
            Γ ⊢ fix t : ???

*)


(* Δυναμική σημασιολογία: 


               
       -----------------------------------
             fix (λx. t)  --> ???
               
       -----------------------------------
                fix t  -->   ???

*)


(* Let rec ως παραγόμενη μορφή:


let rec f x = t1 in t2 ≡ ??? 

*)

(* [fix] grade 0/20 *)
