Οδηγίες για την άσκηση 4
========================

- Στα αρχεία `assignment4.v` και `fastexp.dfy` θα συμπληρώσετε τις απαντήσεις σας.

- Τα συμπληρωματικά αρχεία `imp.v` και `hoare.v` περιλαμβάνουν τους
  ορισμούς της γλώσσας Imp και του Hoare logic που διδάχτηκαν στην 5η
  διάλεξη.

- Παραδοτέα: Το αρχείο `assignment4.v` ή/και το αρχείο `fastexp.dfy`.

- Προσοχή: Συμπληρώστε τις απαντήσεις σας μόνο σε αυτά τα αρχεία.

- Προκειμένου να κάνετε compile το project:

  - Σε λειτουργικό Linux/macOS ή σε Windows μέσω WSL:

    1. Από ένα terminal ανοίξτε το directory `assignment4`.
    2. Εκτελέστε την εντολή `make`.
    3. Ανοίξτε το αρχείο στον IDE σας.
       VsCode:
       - Ανοίξτε το directory `assignment4` μέσα από το VSCode (File > Open Folder).
       - Επιλέξτε το αρχείο `assignment4.v`.
       - Η εντολή `From Assignment4 Require Import imp hoare.` στην αρχή του αρχείου θα
         πρέπει να επιτυγχάνει.

       Emacs:
       - Ανοίξτε το αρχείο `assignment4.v` μέσα από το directory `assignment4`.
       - Η εντολή `From Assignment4 Require Import imp hoare.` στην αρχή του αρχείου θα
         πρέπει να επιτυγχάνει.

    4. Συμπληρώστε την άσκηση.

  - Σε λειτουργικό Windows με CoqIDE

    1. Ανοίξτε το αρχείο `imp.v` στο CoqIDE. Στο μενού Compile πατήστε
       την επιλογή Compile Buffer.
    2. Ανοίξτε το αρχείο `hoare.v` στο CoqIDE. Στο μενού Compile πατήστε
       την επιλογή Compile Buffer.
    3. Ανοίξτε το αρχείο `assignment4.v` στο CoqIDE. Η εντολή `From Assignment4
       Require Import imp hoare.` στην αρχή του αρχείου θα πρέπει να επιτυγχάνει.
    4. Συμπληρώστε την άσκηση.
