From Stdlib Require Import Strings.String Arith.Arith Init.Nat Lia.
From Assignment4 Require Import imp hoare.

(* Suppress warnings when overriding notations *)
Set Warnings "-notation-overridden, -parsing".

(** Στοιχεία Σπουδαστή
Όνομα:
ΑΜ:
*)


(** * Εργασία 4 (100 μονάδες + 30 μονάδες bonus) *)

(** Ο σκοπός αυτής της εργασίας είναι να εξοικειωθείτε με την
    επαλήθευση προγραμμάτων χρησιμοποιώντας τη λογική Hoare.

    Οδηγίες:

    - Μπορείτε να διαλέξετε 2 από τις 3 ασκήσεις. Η επιλογή και των
      τριών δίνει 30 μονάδες bonus.

    - Εάν κολλήσετε σε κάποιο ενδιάμεσο lemma ή proof goal, μπορείτε
      να χρησιμοποιήσετε [admit] ώστε να ολοκληρώσετε την άσκηση και
      να βαθμολογηθείτε για ό,τι έχετε λύσει.

    - Το παραδοτέο αρχείο θα πρέπει να κάνει compile. Αυτό μπορείτε να το
      ελέγξετε στο terminal σας εκτελώντας `make` μέσα στο directory της
      άσκησης (ή με την εντολή `rocq compile -R . Assignment4 assignment4.v`). Τα αρχεία
      που δεν κάνουν compile δεν θα βαθμολογούνται.

    - Όταν ολοκληρώνετε κάποια απόδειξη, αντικαταστήστε το τελικό
      [Admitted] με [Qed].

    - Μην αλλάζετε τον κώδικα που σας έχει δοθεί. Μην γράφετε μέσα στα
      σχόλια της βαθμολόγησης. Αυτό είναι απαραίτητο για την ομαλή και
      έγκαιρη βαθμολόγηση των εργασιών. Μπορείτε να γράψετε όπου
      υπάρχει η οδηγία (* ___ FILL IN HERE ___ *). Εάν σας εξυπηρετεί,
      μπορείτε να ορίζετε βοηθητικές συναρτήσεις, λήμματα, ορισμούς,
      κ.α.

    - Μην αλλάζετε τα ονόματα των αρχείων. Γράψτε τις απαντήσεις σας
      μόνο σε αυτό το αρχείο και στο αρχείο fastpow.dfy αν επιλέξετε
      να κάνετε την άσκηση 3.

    - Συμπληρώστε σωστά τα στοιχεία σας στην αρχή του αρχείου. Αυτό
      είναι απαραίτητο για τη σωστή βαθμολόγηση των εργασιών. *)


(** ** Άσκηση 1: Επαναλαμβανόμενος τετραγωνισμός στην Imp (50 μονάδες) *)

(** Η άσκηση σας ζητά να γράψετε ένα πρόγραμμα στη γλώσσα Imp που θα
    υπολογίζει την ύψωση σε δύναμη χρησιμοποιώντας τη μέθοδο του
    επαναλαμβανόμενου τετραγωνισμού (exponentiation by squaring). Η
    βάση και ο εκθέτης δίνονται ως ορίσματα. Στη συνέχεια, η άσκηση
    σας ζητά να αποδείξετε την ορθότητα του προγράμματος
    χρησιμοποιώντας τη λογική Hoare.

    Μπορείτε να ακολουθήσετε μία από τις παρακάτω μεθόδους:

    - Να γράψετε το πρόγραμμα σε απλή Imp και να αποδείξετε το
      πρόγραμμα σωστό χρησιμοποιώντας τους κανόνες της λογικής Hoare.

    - Να γράψετε το πρόγραμμα σε annotated Imp, όπου το while loop θα
      πρέπει να είναι annotated με ένα κατάλληλο assertion, και να το
      αποδείξετε σωστό χρησιμοποιώντας weakest preconditions και
      verification conditions μέσω του λήμματος [verify_triple].

    Σημείωση: Οι τύποι και οι διατυπώσεις που έχουν δοθεί αντιστοιχούν
    στην δεύτερη μεθοδολογία. Εάν επιλέξετε την πρώτη θα πρέπει να τους
    προσαρμόσετε κατάλληλα.

    Σε κάθε περίπτωση θα πρέπει να βρείτε ένα κατάλληλο loop
    invariant. Θα σας βοηθήσει να σκεφτείτε μια έκφραση που
    περιλαμβάνει τις μεταβλητές που μεταβάλλονται κατά τη διάρκεια του
    loop, της οποίας όμως η τιμή παραμένει σταθερή κατά την είσοδο στο
    loop και μετά από κάθε επανάληψη.

    Σημείωση: Για τη διευκόληνση των ορισμών, οι αριθμητικές εκφράσεις
    στο συνοδευτικό αρχείο imp.v έχουν επεκταθεί με τις πράξεις της
    ακαίρεας διαίρεσης (div) και του υπόλοιπου της ακαίρεας διαίρεσης
    (mod). Μπορείτε να δείτε τη σημασιολογία τους αλλά και τα
    notations τους στο αρχείο imp.v. *)


Definition BASE := "base".
Definition EXP := "exp".


Definition FAST_EXP (base exp : nat) : acom (* :=   ___ FILL IN HERE ___. *)
. Admitted. (* Διαγράψτε αυτή τη γραμμή και συμπληρώστε την από πάνω *)

(* [FAST_EXP] grade 0/15 *)


(** Sanity check: Εάν οι παραπάνω ορισμοί είναι σωστοί, τότε τα
    παρακάτω tests θα πρέπει να επιτυγχάνουν. *)

Example FAST_EXP_2_6 :
  match cinterp 20 (_ !-> 0) (erase (FAST_EXP 2 6)) with
  | Some st => Some (st RES) (* Get the value of variable [RES] in the state *)
  | None => None
  end = Some 64.
Admitted. (* Για να ελέγξετε τον ορισμό σας, διαγράψτε αυτή τη γραμμή και κάντε uncomment την από κάτω. *)
(* Proof. reflexivity. Qed. *)

Example FAST_EXP_3_4 :
  match cinterp 20 (_ !-> 0) (erase (FAST_EXP 3 4)) with
  | Some st => Some (st RES) (* Get the value of variable [RES] in the state *)
  | None => None
  end = Some 81.
Admitted. (* Για να ελέγξετε τον ορισμό σας, διαγράψτε αυτή τη γραμμή και κάντε uncomment την από κάτω. *)
(* Proof. reflexivity. Qed. *)

(** Η παρακάτω εντολή θα αποτρέψει τους ορισμούς του [modulo] και του [div]
    να γίνουν simplify κατά τη διάρκεια της απόδειξης σας. *)
Opaque modulo div.

(** Αποδείξτε ότι μετά την εκτέλεση του προγράμματος [FAST_EXP], η
    μεταβλητή [RES] θα έχει την τιμή [pow base exp], όπου [pow] είναι
    η συνάρτηση ύψωσης σε δύναμη από τo standard library. Μπορείτε να
    χρησιμοποιήσετε οποιοδήποτε λήμμα από τη βιβλιοθήκη χρειάζεται για
    την απόδειξη, όπως τα [Nat.pow_mul_l] και [Nat.pow_add_r], τα
    οποία μπορεί να φανούν χρήσιμα.

    Tips:

    - Χρησιμοποιήστε την εντολή [Search] για να βρείτε διαθέσιμα
      λήμματα που σχετίζονται με αριθμητικές ιδιότητες. Για
      παράδειγμα, η εντολή [Search (_ mod _).] εμφανίζει όλα τα
      λήμματα που αφορούν τον τελεστή [mod] του standard library.

    - Μπορείτε να χρησιμοποιήσετε τα tactics [unfold_all] και
      [simplify_env] που ορίσαμε στο μάθημα για να απλοποιήσετε
      το proof state.

    - Ίσως σας φανεί χρήσιμο να αποδείξετε τη διατήρηση του loop
      invariant και την επάρκειά του (ότι δηλαδή συνεπάγεται το
      επιθυμητό postcondition) "στο χαρτί" πριν προχωρήσετε στην
      απόδειξη σε Rocq.

    - Θυμηθήτε ότι μπορείτε να χρησιμοποιείτε το tactic [lia].

 *)

Theorem FAST_EXP_CORRECT (base exp : nat) :
  {{ fun _ => True }} erase (FAST_EXP base exp) {{ fun st => st RES = pow base exp }}.
Proof.
(*  ___ FILL IN HERE ___ *)
Admitted.


(* [FAST_EXP_CORRECT] grade 0/35 *)


(** ** Άσκηση 2: Havoc (50 μονάδες) *)

(** Σε αυτή την άσκηση, επεκτείνουμε τη γλώσσα Imp με μία νέα εντολή,
    [HAVOC x]. Η εντολή HAVOC αναθέτει στη μεταβλητή [x] μια αυθαίρετη
    (μη-ντετερμινιστική) τιμή. Η εντολή είναι χρήσιμη για τη
    μοντελοποίηση μη-ντετερμινιστικής συμπεριφοράς προγραμμάτων.

    Σκοπός της άσκησης είναι:

    1. Να επεκτείνετε τη σημασιολογία (big-step semantics) ώστε να
       περιλαμβάνει κανόνα εκτέλεσης για [HAVOC].

    3. Να επεκτείνετε τους κανόνες της λογικής Hoare ώστε να
       περιλαμβάνουν έναν νέο κανόνα.

    5. Να επεκτείνετε την απόδειξη συνέπειας (soundness) της λογικής Hoare
       ώστε να καλύπτει τον νέο κανόνα.
*)

Module Havoc.

  Inductive com : Type :=
  | CSkip : com
  | CAsgn : string -> aexp -> com
  | CSeq : com -> com -> com
  | CIf : bexp -> com -> com -> com
  | CWhile : bexp -> com -> com
  | CHavoc : string -> com (* νέα εντολή! *)
  .

  Notation "'skip'" :=
    CSkip (in custom com at level 0) : com_scope.
  Notation "x := y" :=
    (CAsgn x y)
      (in custom com at level 0, x constr at level 0,
          y at level 85, no associativity) : com_scope.
  Notation "x ; y" :=
    (CSeq x y)
      (in custom com at level 90,
          right associativity) : com_scope.
  Notation "{ x }" := x (in custom com, x at level 50) : com_scope.
  Notation "'if' x 'then' y 'else' z" :=
    (CIf x y z)
      (in custom com at level 88, x at level 89,
          y at level 89, z at level 89) : com_scope.
  Notation "'while' x 'do' y" :=
    (CWhile x y)
      (in custom com at level 88, x at level 89,
          y at level 89) : com_scope.

  (* νέο notation! *)
  Notation "'HAVOC' x" :=
    (CHavoc x)
      (in custom com at level 0, x constr at level 0,
          no associativity) : com_scope.


  (** Eπεκτείνετε τη σημασιολογία ώστε να
      περιλαμβάνει κανόνες για το [havoc]. *)
  
  Inductive ceval : imp_state -> com -> imp_state -> Prop :=
  | E_Skip : forall st,
      st =[ skip ]=> st
  | E_Asgn : forall st a n x,
      ainterp st a = n ->
      st =[ x := a ]=> (x !-> n ; st)
  | E_Seq : forall c1 c2 st st' st'',
      st =[ c1 ]=> st' ->
                   st' =[ c2 ]=> st'' ->
                                 st =[ c1 ; c2 ]=> st''
  | E_IfTrue : forall st st' b c1 c2,
      binterp st b = true ->
      st =[ c1 ]=> st' ->
                   st =[ if b then c1 else c2]=> st'
  | E_IfFalse : forall st st' b c1 c2,
      binterp st b = false ->
      st =[ c2 ]=> st' ->
                   st =[ if b then c1 else c2 ]=> st'
  | E_WhileFalse : forall b st c,
      binterp st b = false ->
      st =[ while b do c ]=> st
  | E_WhileTrue : forall st st' st'' b c,
      binterp st b = true ->
      st =[ c ]=> st' ->
      st' =[ while b do c ]=> st'' ->
      st =[ while b do c ]=> st''
  (*  ___ FILL IN HERE ___ *)

  where "st =[ c ]=> st'" := (ceval st c st').


  (* [ceval] grade 0/5 *)


  (** Εάν ο ορισμός της σημασιολογίας είναι σωστός, θα πρέπει να
      μπορείτε να αποδείξετε τo παρακάτω λήμμα. *)

  Example eval_havoc :
    forall st n, exists st', st =[ HAVOC X ]=> st' /\ st' X = n.
    (*  ___ FILL IN HERE ___ *)
  Admitted.

  (* [eval_havoc] grade 0/5 *)




  (** Στη συνέχεια ορίζουμε κανόνες λογικής Hoare για την επέκταση της
      Imp.  Η νέα σημασιολογία μιας τρίπλας [{{ P }} c {{ Q }}] είναι
      η εξής:

      Εάν το πρόγραμμα [c] ξεκινώντας από μια αρχική κατάσταση που
      ικανοποιεί το [P] τερματίζει σε ένα αποτέλεσμα, τότε το
      αποτέλεσμα είναι μία επιτυχής τελική κατάσταση που ικανοποιεί το
      [Q]. 

      Οι κανόνες για τις ήδη υπάρχουσες εντολές παραμένουν οι ίδιοι.
      Προσθέστε έναν καινούριο κανόνα για την εντολή [HAVOC]. *)

  Reserved Notation "{{ P }} c {{ Q }}"
    (at level 90, c custom com at level 99).

  Inductive triple : assertion -> com -> assertion -> Type :=
  | H_Skip :
    forall (P : assertion),
      {{ P }} <{ skip }> {{ P }}
  | H_Asgn :
    forall (Q : assertion) (X : string) (a : aexp),
      {{ Q [X |-> a] }} <{ X := a }> {{ Q }}
  | H_Seq :
    forall (P Q R : assertion) (c1 c2 : com),
     {{ Q }} c2 {{ R }} ->
     {{ P }} c1 {{ Q }} ->
     {{ P }} <{ c1 ; c2 }> {{ R }}
  | H_If :
    forall (P Q : assertion) (b : bexp) (c1 c2 : com),
     {{ P AND (TRUE b) }} c1 {{ Q }} ->
     {{ P AND (FALSE b) }} c2 {{ Q }} ->
     {{ P }} <{if b then c1 else c2 }> {{ Q }}
  | H_While :
    forall (P : assertion) (b : bexp) (c : com),
      {{ P AND (TRUE b) }} c {{ P }} ->
      {{ P }} <{ while b do c }> {{ P AND (FALSE b) }}
  | H_PostWeakening :
    forall (P Q Q' : assertion) (c : com),
      {{ P }} c {{ Q' }} ->
      (Q' ->> Q) -> (* weakening of the postcondition *)
      {{ P }} c {{ Q }}
  |  H_PreStrengthening :
    forall (P Q P' : assertion) (c : com),
      {{ P' }} c {{ Q }} ->
      (P ->> P') -> (* strengthening of the precondition *)
      {{ P }} c {{ Q }}
 (*  ___ FILL IN HERE ___ *)
  where "{{ P }} c {{ Q }}" := (triple P c Q) : hoare_spec_scope.

  (* [triple] grade 0/15 *)

  (** Εάν ο ορισμός του κανόνα είναι σωστός, θα πρέπει να
      μπορείτε να αποδείξετε τa παρακάτω λήμματα. *)

  
  Lemma havoc_triple1 Q X :
    {{ fun st => forall n, Q n }} HAVOC X {{ fun st => Q (st X) }}.
  Proof.
    (*  ___ FILL IN HERE ___ *)
  Admitted.

  (* [havoc_triple1] grade 0/5 *)


  (* Για το δεύτερο λήμμα θα χρειαστείτε το axiom του function
     extensionality το οποίο λέει ότι δύο συναρτήσεις είναι ίσες άν
     δίνουν ίδιο αποτέλεσμα για όλα τα σημεία του πεδίου ορισμού
     τους. Αυτή η πρόταση δεν μπορεί να αποδειχτεί στην κατασκευαστική
     λογική, είναι όμως συνεπής (δηλαδή μπορούμε να την υποθέσουμε
     χωρίς βλάβη της συνέπειας του συστήματος).
      *)
  Axiom function_extensionality :
    forall A B (f g : A -> B),
      (forall x, f x = g x) -> f = g.
  
  Lemma havoc_triple2 Q X (n : nat):
    {{ Q [X |-> n] }} HAVOC X; X := n {{ Q }}.
  Proof.
    (*  ___ FILL IN HERE ___ *)
  Admitted.

  (* [havoc_triple2] grade 0/10 *)
        
  (** Τέλος, επεκτείνετε την απόδειξη της συνέπειας της λογικής Hoare για τον νέο κανόνα. *)

  Definition valid (P : assertion) (c : com) (Q : assertion) : Prop :=
  forall st st',
    st =[ c ]=> st' -> (* if the program starting from [st] terminates in [st'] *)
    P st ->            (* and [st] satisfies [P] *)
    Q st'.             (* then [st'] also satisfies [Q]. *)

  Theorem hoare_triple_sound :
    forall (P Q : assertion) (c : com),
      {{ P }} c {{ Q }} ->
      valid P c Q.
  Proof.
    unfold valid.
    intros P Q c Htriple.
    induction Htriple; intros st1 st2 Heval HP;
      try now (inv Heval; eauto).
    - inv Heval.
      + (* binterp st1 b = true *)
        eapply IHHtriple1; hoare_auto.
      + (* binterp st1 b = false *)
        eapply IHHtriple2; hoare_auto.
  - remember <{ while b do c }> as loop eqn:Heq.
    induction Heval; try congruence; inv Heq.
    + (* E_WhileFalse *)
      split; eauto.
    + (* E_WhileTrue *)
      apply IHHeval2. reflexivity.
      eapply IHHtriple; hoare_auto.
  - hoare_auto.
  - hoare_auto.
    (*  ___ FILL IN HERE ___ *)
  Admitted.

  (* [hoare_triple_sound] grade 0/10 *)

End Havoc.



(** ** Άσκηση 3: Fast Exponentiation in Dafny (50 μονάδες) *)

  (** Συμπληρώστε το αρχείο [fastexp.dfy]. Θα πρέπει να γράψετε ένα
      πρόγραμμα Dafny που υπολογίζει την ύψωση σε δύναμη με τη μέθοδο
      του επαναλαμβανόμενου τετραγωνισμού. Το πρόγραμμα θα πρέπει να
      ικανοποιεί το δοσμένο postcondition, που δηλώνει ότι υπολογίζει
      σωστά την ύψωση σε δύναμη σε σχέση με τη συναρτησιακή
      προδιαγραφή [pow].

      Hint: Μπορείτε να γράψετε ένα λήμμα που να περιγράφει με τι
      ισούται η τιμή [pow(x,n)] στην περίπτωση που το [n] είναι άρτιος
      και στην περίπτωση που το [n] είναι περιττός. *)
