Instructions for Assignment 4
=============================

- In the files `assignment4.v` and `fastexp.dfy` you will fill in your answers.

- The supplementary files `imp.v` and `hoare.v` include the
  definitions of the Imp language and Hoare logic that were taught in the 5th
  lecture.

- Deliverables: The file `assignment4.v` and/or the file `fastexp.dfy`.

- Attention: Fill in your answers only in these files.

- To compile the project:

  - On Linux/macOS operating system or on Windows via WSL:

    1. From a terminal open the directory `assignment4`.
    2. Execute the command `make`.
    3. Open the file in your IDE.
       VsCode:
       - Open the directory `assignment4` from within VSCode (File > Open Folder).
       - Select the file `assignment4.v`.
       - The command `From Assignment4 Require Import imp hoare.` at the beginning of the file should
         succeed.

       Emacs:
       - Open the file `assignment4.v` from within the directory `assignment4`.
       - The command `From Assignment4 Require Import imp hoare.` at the beginning of the file should
         succeed.

    4. Complete the assignment.

  - On Windows operating system with CoqIDE

    1. Open the file `imp.v` in CoqIDE. In the Compile menu press
       the Compile Buffer option.
    2. Open the file `hoare.v` in CoqIDE. In the Compile menu press
       the Compile Buffer option.
    3. Open the file `assignment4.v` in CoqIDE. The command `From Assignment4
       Require Import imp hoare.` at the beginning of the file should succeed.
    4. Complete the assignment.
