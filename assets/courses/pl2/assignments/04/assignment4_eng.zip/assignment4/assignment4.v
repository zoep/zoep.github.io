From Stdlib Require Import Strings.String Arith.Arith Init.Nat Lia.
From Assignment4 Require Import imp hoare.

(* Suppress warnings when overriding notations *)
Set Warnings "-notation-overridden, -parsing".

(** Student Information
Name:
ID:
*)


(** * Assignment 4 (100 points + 30 bonus points) *)

(** The purpose of this assignment is to become familiar with
    program verification using Hoare logic.

    Instructions:

    - You can choose 2 out of the 3 exercises. Choosing all
      three gives 30 bonus points.

    - If you get stuck on some intermediate lemma or proof goal, you can
      use [admit] to complete the exercise and
      get graded for what you have solved.

    - The deliverable file should compile. You can check this on your
      terminal by running `make` in the assignment directory (or with
      the command `rocq compile -R . Assignment4 assignment4.v`). Files
      that do not compile will not be graded.

    - When you complete a proof, replace the final
      [Admitted] with [Qed].

    - Do not change the code that has been given to you. Do not write inside the
      grading comments. This is necessary for smooth and
      timely grading of assignments. You can write wherever
      there is the instruction (* ___ FILL IN HERE ___ *). If it helps you,
      you can define helper functions, lemmas, definitions,
      etc.

    - Do not change the file names. Write your answers
      only in this file and in the fastpow.dfy file if you choose
      to do exercise 3.

    - Fill in your information correctly at the beginning of the file. This
      is necessary for correct grading of assignments. *)


(** ** Exercise 1: Repeated Squaring in Imp (50 points) *)

(** The exercise asks you to write a program in the Imp language that calculates
      exponentiation using the method of repeated squaring. The base and
      exponent are given as arguments. Subsequently, the exercise asks you to
      prove the correctness of the program using Hoare logic.

    You can follow one of the following methods:

    - Write the program in plain Imp and prove the program correct using the
      rules of Hoare logic.

    - Write the program in annotated Imp, where the while loop should be
      annotated with an appropriate assertion, and prove it correct using
      weakest preconditions and verification conditions via the [verify_triple]
      lemma.

    Note: The types and formulations that have been given correspond to the
    second methodology. If you choose the first you will need to adapt them
    appropriately.

    In any case you will need to find an appropriate loop invariant. It will
    help you to think of an expression that includes the variables that change
    during the loop, but whose value remains constant upon entering the loop and
    after each iteration.

    Note: For the convenience of definitions, the arithmetic expressions in the
    accompanying file imp.v have been extended with the operations of integer
    division (div) and the remainder of integer division (mod). You can see
    their semantics as well as their notations in the imp.v file. *)


Definition BASE := "base".
Definition EXP := "exp".


Definition FAST_EXP (base exp : nat) : acom (* :=   ___ FILL IN HERE ___. *)
. Admitted. (* Delete this line and fill in the one above *)

(* [FAST_EXP] grade 0/15 *)


(** Sanity check: If the above definitions are correct, then the
    following tests should succeed. *)

Example FAST_EXP_2_6 :
  match cinterp 20 (_ !-> 0) (erase (FAST_EXP 2 6)) with
  | Some st => Some (st RES) (* Get the value of variable [RES] in the state *)
  | None => None
  end = Some 64.
Admitted. (* To check your definition, delete this line and uncomment the one below. *)
(* Proof. reflexivity. Qed. *)

Example FAST_EXP_3_4 :
  match cinterp 20 (_ !-> 0) (erase (FAST_EXP 3 4)) with
  | Some st => Some (st RES) (* Get the value of variable [RES] in the state *)
  | None => None
  end = Some 81.
Admitted. (* To check your definition, delete this line and uncomment the one below. *)
(* Proof. reflexivity. Qed. *)

(** The following command will prevent the definitions of [modulo] and [div]
    from being simplified during your proof. *)
Opaque modulo div.

(** Prove that after executing the program [FAST_EXP], the
    variable [RES] will have the value [pow base exp], where [pow] is
    the exponentiation function from the standard library. You can
    use any lemma from the library needed for
    the proof, such as [Nat.pow_mul_l] and [Nat.pow_add_r], which
    may prove useful.

    Tips:

    - Use the [Search] command to find available
      lemmas related to arithmetic properties. For
      example, the command [Search (_ mod _).] displays all
      lemmas concerning the [mod] operator of the standard library.

    - You can use the tactics [unfold_all] and
      [simplify_env] that we defined in class to simplify
      the proof state.

    - It might be useful to prove the preservation of the loop
      invariant and its adequacy (that it implies the
      desired postcondition) "with pen and paper" before proceeding to the
      proof in Rocq.

    - Remember that you can use the [lia] tactic.

 *)

Theorem FAST_EXP_CORRECT (base exp : nat) :
  {{ fun _ => True }} erase (FAST_EXP base exp) {{ fun st => st RES = pow base exp }}.
Proof.
(*  ___ FILL IN HERE ___ *)
Admitted.


(* [FAST_EXP_CORRECT] grade 0/35 *)


(** ** Exercise 2: Havoc (50 points) *)

(** In this exercise, we extend the Imp language with a new command,
    [HAVOC x]. The HAVOC command assigns an arbitrary
    (non-deterministic) value to the variable [x]. The command is useful for
    modeling non-deterministic behavior of programs.

    The purpose of the exercise is:

    1. To extend the semantics (big-step semantics) to
       include an execution rule for [HAVOC].

    3. To extend the rules of Hoare logic to
       include a new rule.

    5. To extend the soundness proof of Hoare logic
       to cover the new rule.
*)

Module Havoc.

  Inductive com : Type :=
  | CSkip : com
  | CAsgn : string -> aexp -> com
  | CSeq : com -> com -> com
  | CIf : bexp -> com -> com -> com
  | CWhile : bexp -> com -> com
  | CHavoc : string -> com (* new command! *)
  .

  Notation "'skip'" :=
    CSkip (in custom com at level 0) : com_scope.
  Notation "x := y" :=
    (CAsgn x y)
      (in custom com at level 0, x constr at level 0,
          y at level 85, no associativity) : com_scope.
  Notation "x ; y" :=
    (CSeq x y)
      (in custom com at level 90,
          right associativity) : com_scope.
  Notation "{ x }" := x (in custom com, x at level 50) : com_scope.
  Notation "'if' x 'then' y 'else' z" :=
    (CIf x y z)
      (in custom com at level 88, x at level 89,
          y at level 89, z at level 89) : com_scope.
  Notation "'while' x 'do' y" :=
    (CWhile x y)
      (in custom com at level 88, x at level 89,
          y at level 89) : com_scope.

  (* new notation! *)
  Notation "'HAVOC' x" :=
    (CHavoc x)
      (in custom com at level 0, x constr at level 0,
          no associativity) : com_scope.


  (** Extend the semantics to
      include rules for [havoc]. *)
  
  Inductive ceval : imp_state -> com -> imp_state -> Prop :=
  | E_Skip : forall st,
      st =[ skip ]=> st
  | E_Asgn : forall st a n x,
      ainterp st a = n ->
      st =[ x := a ]=> (x !-> n ; st)
  | E_Seq : forall c1 c2 st st' st'',
      st =[ c1 ]=> st' ->
                   st' =[ c2 ]=> st'' ->
                                 st =[ c1 ; c2 ]=> st''
  | E_IfTrue : forall st st' b c1 c2,
      binterp st b = true ->
      st =[ c1 ]=> st' ->
                   st =[ if b then c1 else c2]=> st'
  | E_IfFalse : forall st st' b c1 c2,
      binterp st b = false ->
      st =[ c2 ]=> st' ->
                   st =[ if b then c1 else c2 ]=> st'
  | E_WhileFalse : forall b st c,
      binterp st b = false ->
      st =[ while b do c ]=> st
  | E_WhileTrue : forall st st' st'' b c,
      binterp st b = true ->
      st =[ c ]=> st' ->
      st' =[ while b do c ]=> st'' ->
      st =[ while b do c ]=> st''
  (*  ___ FILL IN HERE ___ *)

  where "st =[ c ]=> st'" := (ceval st c st').


  (* [ceval] grade 0/5 *)


  (** If the semantics definition is correct, you should be able to
      prove the following lemma. *)

  Example eval_havoc :
    forall st n, exists st', st =[ HAVOC X ]=> st' /\ st' X = n.
    (*  ___ FILL IN HERE ___ *)
  Admitted.

  (* [eval_havoc] grade 0/5 *)




  (** Next, we define Hoare logic rules for the extension of
      Imp. The new semantics of a triple [{{ P }} c {{ Q }}] is
      as follows:

      If the program [c] starting from an initial state that
      satisfies [P] terminates to a result, then the
      result is a successful final state that satisfies
      [Q].

      The rules for the existing commands remain the same.
      Add a new rule for the [HAVOC] command. *)

  Reserved Notation "{{ P }} c {{ Q }}"
    (at level 90, c custom com at level 99).

  Inductive triple : assertion -> com -> assertion -> Type :=
  | H_Skip :
    forall (P : assertion),
      {{ P }} <{ skip }> {{ P }}
  | H_Asgn :
    forall (Q : assertion) (X : string) (a : aexp),
      {{ Q [X |-> a] }} <{ X := a }> {{ Q }}
  | H_Seq :
    forall (P Q R : assertion) (c1 c2 : com),
     {{ Q }} c2 {{ R }} ->
     {{ P }} c1 {{ Q }} ->
     {{ P }} <{ c1 ; c2 }> {{ R }}
  | H_If :
    forall (P Q : assertion) (b : bexp) (c1 c2 : com),
     {{ P AND (TRUE b) }} c1 {{ Q }} ->
     {{ P AND (FALSE b) }} c2 {{ Q }} ->
     {{ P }} <{if b then c1 else c2 }> {{ Q }}
  | H_While :
    forall (P : assertion) (b : bexp) (c : com),
      {{ P AND (TRUE b) }} c {{ P }} ->
      {{ P }} <{ while b do c }> {{ P AND (FALSE b) }}
  | H_PostWeakening :
    forall (P Q Q' : assertion) (c : com),
      {{ P }} c {{ Q' }} ->
      (Q' ->> Q) -> (* weakening of the postcondition *)
      {{ P }} c {{ Q }}
  |  H_PreStrengthening :
    forall (P Q P' : assertion) (c : com),
      {{ P' }} c {{ Q }} ->
      (P ->> P') -> (* strengthening of the precondition *)
      {{ P }} c {{ Q }}
 (*  ___ FILL IN HERE ___ *)
  where "{{ P }} c {{ Q }}" := (triple P c Q) : hoare_spec_scope.

  (* [triple] grade 0/15 *)

  (** If the rule definition is correct, you should be able to
      prove the following lemmas. *)

  
  Lemma havoc_triple1 Q X :
    {{ fun st => forall n, Q n }} HAVOC X {{ fun st => Q (st X) }}.
  Proof.
    (*  ___ FILL IN HERE ___ *)
  Admitted.

  (* [havoc_triple1] grade 0/5 *)


  (* For the second lemma you will need the axiom of function
     extensionality which says that two functions are equal if
     they give the same result for all points in their domain.
     This proposition cannot be proven in constructive
     logic, but it is consistent (i.e., we can assume it
     without harming the consistency of the system). *)
  Axiom function_extensionality :
    forall A B (f g : A -> B),
      (forall x, f x = g x) -> f = g.
  
  Lemma havoc_triple2 Q X (n : nat):
    {{ Q [X |-> n] }} HAVOC X; X := n {{ Q }}.
  Proof.
    (*  ___ FILL IN HERE ___ *)
  Admitted.

  (* [havoc_triple2] grade 0/10 *)
        
  (** Finally, extend the soundness proof of Hoare logic for the new rule. *)

  Definition valid (P : assertion) (c : com) (Q : assertion) : Prop :=
  forall st st',
    st =[ c ]=> st' -> (* if the program starting from [st] terminates in [st'] *)
    P st ->            (* and [st] satisfies [P] *)
    Q st'.             (* then [st'] also satisfies [Q]. *)

  Theorem hoare_triple_sound :
    forall (P Q : assertion) (c : com),
      {{ P }} c {{ Q }} ->
      valid P c Q.
  Proof.
    unfold valid.
    intros P Q c Htriple.
    induction Htriple; intros st1 st2 Heval HP;
      try now (inv Heval; eauto).
    - inv Heval.
      + (* binterp st1 b = true *)
        eapply IHHtriple1; hoare_auto.
      + (* binterp st1 b = false *)
        eapply IHHtriple2; hoare_auto.
  - remember <{ while b do c }> as loop eqn:Heq.
    induction Heval; try congruence; inv Heq.
    + (* E_WhileFalse *)
      split; eauto.
    + (* E_WhileTrue *)
      apply IHHeval2. reflexivity.
      eapply IHHtriple; hoare_auto.
  - hoare_auto.
  - hoare_auto.
    (*  ___ FILL IN HERE ___ *)
  Admitted.

  (* [hoare_triple_sound] grade 0/10 *)

End Havoc.



(** ** Exercise 3: Fast Exponentiation in Dafny (50 points) *)

  (** Complete the file [fastexp.dfy]. You should write a
      Dafny program that calculates exponentiation using the method
      of repeated squaring. The program should
      satisfy the given postcondition, which states that it correctly calculates
      exponentiation in relation to the functional
      specification [pow].

      Hint: You can write a lemma that describes what
      the value [pow(x,n)] equals in the case where [n] is even
      and in the case where [n] is odd. *)
