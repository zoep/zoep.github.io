Instructions for Assignment 3
========================

- Assignment 3 follows the same format as the previous assignments. In the file `assignment3.v` you will fill in your answers.

- The file `imp.v` includes the definitions of the Imp language that were taught in the 3rd lecture. The file `assignment3.v` imports the file `imp.v` so that these definitions can be used in the assignment.
  
- Deliverable: Only the file `assignment3.v`.

- Attention: Fill in your answers only in the file `assignment3.v`.

- In order to compile the project:

  - On Linux/MacOS or on Windows via WSL:
  
    1. From a terminal, open the directory `assignment3`. 
    2. Run the command `make`.
    3. Open the file in your IDE.
       VSCode:
       - Open the directory `assignment3` in VSCode (File > Open Folder).
       - Select the file `assignment3.v`. 
       - The command `From Assignment3 Require Import imp.` at the beginning of the file should succeed.
	 
       Emacs:
       - Open the file `assignment3.v` from the directory `assignment3`.
       - The command `From Assignment3 Require Import imp.` at the beginning of the file should succeed.
	   
    4. Complete the exercise.
	
  - On Windows with CoqIDE
 
    1. Open the file `imp.v` in CoqIDE. In the Compile menu, click the option Compile Buffer.
    2. Open the file `assignment3.v` in CoqIDE. The command `From Assignment3 Require Import imp.` at the beginning of the file should succeed.
    3. Complete the exercise.
