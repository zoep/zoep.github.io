From Stdlib Require Import Strings.String Arith.Arith Lia.
(* Suppress warnings when overriding notations *)
Set Warnings "-notation-overridden, -parsing".

From Assignment3 Require Import imp.

(** Student Information
Name:  
ID: 
*)


(** * Assignment 3 (100 points + 20 bonus points) *)

(** The purpose of this assignment is to familiarize yourself with
    the semantic definitions of simple languages and proofs of
    semantic correctness.

    Instructions:

    - Do not change the names of the files provided to you.

    - [NEW] You may find the tactic [lia] useful, which implements a procedure
      that solves goals in linear integer arithmetic.

    - [NEW] You may use any tactics you want. The tactics we
      have covered in class are sufficient to solve the problems.

    - [NEW] You may use theorems from the library.

    - If you get stuck on some intermediate lemma, you may use
      [admit] in order to complete the exercise and get credit for what
      you have solved.

    - The deliverable file must compile. You can check this on your
      terminal by running `make` in the assignment directory (or with
      the command `rocq compile -R . Assignment3 assignment3.v`). Files
      that do not compile will not be graded.

    - When you complete a proof, replace the final [Admitted] with
      [Qed].

    - Do not change the code and the text that have been given to you. Do not write
      inside the grading comments. This is necessary for the smooth and
      timely grading of the assignments. You may write wherever there is the
      directive (*  ___ FILL IN HERE ___ *). If it helps you, you may
      define helper functions, lemmas, definitions, etc.

    - Fill in your information correctly at the beginning of the file. This is
      necessary for the correct grading of the assignments. *)


(** ** Exercise 1: Warm-up (10 points + 10 bonus points) *)

(** This exercise asks you to write an Imp program that swaps
    two variables **without** using temporary variables and to
    prove a specification for this program. *)

(** Variable names *)
Definition X : string := "X".
Definition Y : string := "Y".

Definition SWAP : com
(* :=   ___ FILL IN HERE ___. *)
. Admitted. (* Delete this line and complete it above *)

(* [swap] grade 0/2 *)

(* Hint: The lemmas [Nat.leb_gt] and [leb_complete] will be useful to you *)

Lemma swap_correct :
  forall st,
  exists st', st =[ SWAP ]=> st' /\ st' X = st Y /\ st' Y = st X.
Proof.
(*  ___ FILL IN HERE ___ *)
Admitted.

(* [swap_correct] grade 0/5 *)

(** Is this specification sufficient? How could we prove
    that the program does not affect other variables? Answer
    briefly.

    Answer: ___ FILL IN HERE ___

 *)

(* [swap_spec] grade 0/3 *)

(** Bonus: Also formally prove that the program [SWAP] does not affect
    other variables. The lemma [eqb_neq] will be useful to you. *)

Lemma swap_frame :
  forall (st : imp_state), False (* ___ FILL IN HERE ___ *).
Proof.
(*  ___ FILL IN HERE ___ *)
Admitted.

(* [swap_frame] bonus grade 0/10 *)

(** ** Exercise 2: Correctness of Constant Folding (50 points) *)

(** Constant folding is a code optimization used by
    compilers during which the value of constant expressions is computed
    and simplifications are applied.

    This exercise asks you to write a constant folding pass for
    Imp and prove it correct.

    We will start with arithmetic expressions.

    The goal is to statically compute the values of expressions that do not
    contain variables and to apply specific
    arithmetic simplifications. The simplifications are as follows:

    e + 0 = e
    0 + e = e
    0 - e = 0
    e - 0 = e
    e * 1 = e
    1 * e = e
    e * 0 = 0
    0 * e = 0

 *)

(** Write a (non-recursive) function [simplify_aexp] that simplifies
    an arithmetic expression according to the above.

    For example the term [<{ 0 + e }>] (i.e., [APlus (ANum 0) e])
    should be simplified to [e] while the term [<{ 11 + 31 }>] to
    [42] *)

Definition simplify_aexp (e : aexp) : aexp
(* := ___ FILL IN HERE ___ *).
Admitted.

(* [simplify_aexp] grade 0/4 *)

(** Next, write a recursive function [optimize_aexp] that
    applies the function [simplify_aexp] to every node of the abstract
    syntax tree [aexp] in a bottom-up manner (i.e., from inner nodes
    toward outer nodes). *)

Fixpoint optimize_aexp (e : aexp) : aexp
(* := ___ FILL IN HERE ___ *).
Admitted.

(* [optimize_aexp] grade 0/4 *)

(** Sanity check: If the above definitions are correct and complete,
    then the following tests should pass. *)
Example test_optimize_aexp1: (optimize_aexp <{ 3 + (X * 1) - (1 * 4) * (1 * Y - 0) }> = <{ 3 + X - 4 * Y }>).
Admitted.
(* Proof. simpl. reflexivity. Qed. *)

Example test_optimize_aexp2: (optimize_aexp <{ 3 + (X * 1) - Z * (0 * Y + (11 - 2)) }> = <{ 3 + X - Z * 9 }>).
Admitted.
(* Proof. simpl. reflexivity. Qed. *)

Example test_optimize_aexp3: (optimize_aexp <{ (0 + (0 * X + 0)) - Z }> = <{ 0 }>).
Admitted.
(* Proof. simpl. reflexivity. Qed. *)


(** Do the same for boolean expressions. Find which expressions
    you can evaluate statically and which simplifications you can
    make. *)

Definition simplify_bexp (e : bexp) : bexp
(* := ___ FILL IN HERE ___ *).
Admitted.

(* [simplify_bexp] grade 0/4 *)

Fixpoint optimize_bexp (e : bexp) : bexp
(* := ___ FILL IN HERE ___ *).
Admitted.

(* [optimize_bexp] grade 0/4 *)

(** Sanity check: If the above definitions are correct and complete,
    then the following tests should pass. *)
Example test_optimize_bexp1: (optimize_bexp <{ 17 <= 42 || 0 < X }> = <{ true }>).
Admitted.
(* Proof. simpl. reflexivity. Qed. *)

Example test_optimize_bexp2: (optimize_bexp <{ 42 < Y && 12 = 4 }> = <{ false }>).
Admitted.
(* Proof. simpl. reflexivity. Qed. *)

(* Finally, apply these simplifications to the nodes of the
   abstract syntax tree of Imp. Simplify those commands
   that after the simplifications can be evaluated statically. *)

Fixpoint optimize_com (c : com) : com
(* := ___ FILL IN HERE ___ *).
Admitted.

(* [optimize_com] grade 0/4 *)

(** Sanity check: If the above definition is correct and complete,
    then the following test should pass. *)

Example test_optimize_com: (optimize_com <{ if (0 <= X * 0) then X := 0 else X := 1 end }> = <{ X := 0 }>).
Admitted.
(* Proof. simpl. reflexivity. Qed. *)


(** Prove that the above functions are correct, i.e.,
    they preserve the semantics of the original expression. *)

(** Start by proving that [ainterp st (simplify_aexp e) = ainterp st e].

    Note 1: Since the definition of the above function is not
    recursive, you will not need to do an induction proof.

    Note 2: The proof below has many similar cases.
    You can use the techniques we learned in class to
    group different cases of the proof.

    To make this easier, you are given the tactic
    [simpl_arith] which applies the above simplification rules
    to natural numbers. This tactic groups various
    simplifications that you will need to make to the result of the
    interpreter in various cases of your proof. You will find it
    useful so that you can write proof scripts that can be applied to
    many similar cases of the proof.  *)

Ltac simpl_arith :=
  try rewrite <- plus_n_O; try rewrite plus_O_n;
  try rewrite PeanoNat.Nat.mul_1_r; try rewrite PeanoNat.Nat.mul_1_l;
  try rewrite PeanoNat.Nat.mul_0_r; try rewrite PeanoNat.Nat.mul_0_l;
  try rewrite PeanoNat.Nat.sub_0_l; try rewrite PeanoNat.Nat.sub_0_r.


Lemma simplify_aexp_correct :
  forall st (e : aexp), ainterp st (simplify_aexp e) = ainterp st e.
Proof.
(*  ___ FILL IN HERE ___ *)
Admitted.

(* [simplify_aexp_correct] grade 0/8 *)

(** Next do the same for [simplify_bexp] *)

Ltac simpl_bool :=
  try rewrite Bool.orb_true_r; try rewrite Bool.orb_true_l;
  try rewrite Bool.andb_true_l;  try rewrite Bool.andb_true_r;
  try rewrite Bool.orb_false_r; try rewrite Bool.orb_false_l;
  try rewrite Bool.andb_false_l;  try rewrite Bool.andb_false_r.

Lemma simplify_bexp_correct :
  forall st (e : bexp), binterp st (simplify_bexp e) = binterp st e.
Proof.
(*  ___ FILL IN HERE ___ *)
Admitted.

(* [simplify_bexp_correct] grade 0/8 *)

(** Using the above lemma, prove that
    [ainterp st (optimize_aexp e) = ainterp st e] and that
    [binterp st (optimize_bexp e) = binterp st e]. *)

(** The following commands will prevent the function definitions
    from being expanded when you do [simpl]. This is useful
    so that calls to [simplify] are not replaced with the body
    of the function and you can apply the lemmas you have
    shown. *)

Opaque simplify_aexp.
Opaque simplify_bexp.

Lemma optimize_aexp_correct :
  forall (st : imp_state) (e : aexp), ainterp st e = ainterp st (optimize_aexp e).
Proof.
(*  ___ FILL IN HERE ___ *)
Admitted.

(* [optimize_aexp_correct] grade 0/3 *)


Lemma optimize_bexp_correct :
  forall (st : imp_state) (e : bexp), binterp st e = binterp st (optimize_bexp e).
Proof.
(*  ___ FILL IN HERE ___ *)
Admitted.

(* [optimize_bexp_correct] grade 0/3 *)

(** Finally, state and prove a theorem for the correctness
    of this transformation [optimize_com]. Use the definition
    [ceval] of the big-step semantics. *)

Opaque optimize_bexp.
Opaque optimize_aexp.

Theorem optimize_com_correct :
  forall st c st',
    st =[ c ]=> st' ->
    st =[ optimize_com c ]=> st'.
Proof.
(*  ___ FILL IN HERE ___ *)
Admitted.

(* [optimize_com_correct] grade 0/8 *)

Theorem optimize_com_correct_rev :
  forall st c st',
    st =[ optimize_com c ]=> st' ->
    st =[ c ]=> st'.
Proof.
(*  ___ FILL IN HERE ___ *)
Admitted.

Transparent simplify_aexp.
Transparent simplify_bexp.
Transparent optimize_bexp.
Transparent optimize_aexp.

(** ** Exercise 3: For Loops (40 points) *)

(** In this exercise you are asked to add for loops to the
    definition of the commands [com] of Imp.

    A for loop extends the grammar of commands <com> as follows:

    <com> := ... | for <com>; <bexp>; <com> do <com>

    The first parameter <com> is executed once at the beginning of the
    loop’s execution.

    The second parameter <bexp> is the condition that determines whether
    the execution of the loop will continue.

    The third parameter <com> is executed after the end of each repetition
    of the loop body.

    Finally, the fourth parameter <com> is the body of the loop.

    For example the following program adds 5 to the value of
    variable [Y].

    <{ for (Z = 0, Z < 5, Z := Z + 1) { Y := Y + 1; } }> *)

Module ForLoops.

  (** Extend the definition of [com] with a node [CFor] that
      represents the for loop *)
  Inductive com : Set :=
  | CSkip : com
  | CAsgn : string -> aexp -> com
  | CSeq : com -> com -> com
  | CIf : bexp -> com -> com -> com
  | CWhile : bexp -> com -> com
  (** __ FILL IN HERE __ **)
  .

  (* [com] grade 0/2 *)
  
  (** We redefine the relevant notations so that they refer to the new
      [com] definition. *)

  Notation "'skip'" :=
    CSkip (in custom com at level 0) : com_scope.
  Notation "x := y" :=
    (CAsgn x y)
      (in custom com at level 0, x constr at level 0,
          y at level 85, no associativity) : com_scope.
  Notation "x ; y" :=
    (CSeq x y)
      (in custom com at level 90,
          right associativity) : com_scope.
  Notation "{ x }" := x (in custom com, x at level 50) : com_scope.
  Notation "'if' x 'then' y 'else' z 'end'" :=
    (CIf x y z)
      (in custom com at level 88, x at level 89,
          y at level 89, z at level 89) : com_scope.
  Notation "'while' x 'do' y" :=
    (CWhile x y)
      (in custom com at level 88, x at level 89,
          y at level 89) : com_scope.

 Notation "'for' i ';' b ';' f 'do' c" :=
 (* Attention!!! This definition is wrong.  *)
   (CIf b (CSeq i f) c)
     (in custom com at level 88, b at level 89,
         i at level 89, f at level 89, c at level 89) : com_scope.
 (* After you complete the above definitions, delete the above
    notation definition and uncomment the code below. *)
 (*   (CFor i b f c) *)
 (*     (in custom com at level 88, b at level 89, *)
 (*         i at level 89, f at level 89, c at level 89) : com_scope. *)
  
  Reserved Notation "st '=[' c ']=>' st'"
    (at level 40, c custom com at level 99, st constr, st' constr at next level).

 (** Extend the definition [ceval] of the big-step semantics with the
     necessary cases for the execution of For. It may help to first
     write on paper the inference rules for for loops and then turn
     them into code. *)
  
  Inductive ceval : imp_state -> com -> imp_state -> Prop :=
  | E_Skip : forall st,
      st =[ skip ]=> st
  | E_Asgn : forall st a n x,
      ainterp st a = n ->
      st =[ x := a ]=> (x !-> n ; st)
  | E_Seq : forall c1 c2 st st' st'',
      st =[ c1 ]=> st' ->
      st' =[ c2 ]=> st'' ->
      st =[ c1 ; c2 ]=> st''
  | E_IfTrue : forall st st' b c1 c2,
      binterp st b = true ->
      st =[ c1 ]=> st' ->
      st =[ if b then c1 else c2 end]=> st'
  | E_IfFalse : forall st st' b c1 c2,
      binterp st b = false ->
      st =[ c2 ]=> st' ->
      st =[ if b then c1 else c2 end]=> st'
  | E_WhileFalse : forall b st c,
      binterp st b = false ->
      st =[ while b do c ]=> st
  | E_WhileTrue : forall st st' st'' b c,
      binterp st b = true ->
      st =[ c ]=> st' ->
      st' =[ while b do c ]=> st'' ->
      st =[ while b do c ]=> st''
  (** __ FILL IN HERE __ **)
                                                                  
  where "st =[ c ]=> st'" := (ceval st c st').

  (* [ceval] grade 0/10 *)
  (** Uncomment the following program. *)
  Definition powY3 : com
  . Admitted.
  (* :=  <{ for Z := 0; Z < 3 ; Z := Z + 1 do Y := Y * Y }>.  *)

  (** Prove the following specification for the program [powY3]. You are
      given the tactic [simplify_state] which simplifies the states that
      result from the above program.

      Specifically, it performs the following simplifications, for every [st] and [v]:

       (Ζ !-> v; st) Y = st y
       (Y !-> v; st) Y = v

      You can use it to simplify intermediate and final states.
      To apply it many times, use it together with the tactical [repeat]. *)

  
  Ltac simplify_state :=
    match goal with
    | |- context[update_st ?st1 Z ?v Y] => 
        replace (update_st st1 Z v Y) with (st1 Y) by reflexivity
    | |- context[update_st ?st1 Y ?v Y] => 
        replace (update_st st1 Y v Y) with v by reflexivity
    end.

  
  Lemma powY3_correct :
    forall st,
    exists st', st =[ powY3 ]=> st' /\ st' Y = st Y ^ 8. 
  Proof.
  (*  ___ FILL IN HERE ___ *)
  Admitted.
  (* [powY3_correct] grade 0/8 *)
  
  (** Extend the proof that [ceval] is a deterministic relation. *) 
  Lemma ceval_deterministic :
    forall st c st1 st2, 
      st =[ c ]=> st1 ->
      st =[ c ]=> st2 ->
      st1 = st2.
  Proof.
    intros st c st1 st2 Heval1. revert st2.
    induction Heval1; intros st2 Heval2.
    - (* E_Skip *)
      inversion Heval2; subst. reflexivity. 
    - (* E_Asgn *)
      inversion Heval2; subst. reflexivity. 
    - (* E_Seq *)
      inversion Heval2; subst. apply IHHeval1_2.
      
      rewrite IHHeval1_1 with (st2 := st'0). 
      + assumption.
      + assumption.

    - (* E_IfTrue *)
      inversion Heval2; subst. (* can be either [E_IfTrue] or [E_IfFalse] *)
      + apply IHHeval1. assumption.
      + congruence. (* contradiction *)

    - (* E_IfFalse *)
      inversion Heval2; subst. (* can be either [E_IfTrue] or [E_IfFalse] *)
      + congruence. (* contradiction *)
      + apply IHHeval1. assumption.

    - (* E_WhileFalse *)
      inversion Heval2; subst. (* can be either [E_WhileFalse] or [E_WhileTrue] *)
      + reflexivity.
      + congruence. (* contradiction *)

    - (* E_WhileTrue *)
      inversion Heval2; subst. (* can be either [E_WhileFalse] or [E_WhileTrue] *)
      + congruence. (* contradiction *)
      + apply IHHeval1_2.
        
        rewrite IHHeval1_1 with (st2 := st'0). 
        * assumption.
        * assumption.
  (*  ___ FILL IN HERE ___ *)
  Admitted.

  (* [ceval_deterministic] grade 0/20 *)

  (** Bonus questions: prove that [for] can be written equivalently as while. *)

  (** First prove that if starting from a state the for
      terminates in a final state, then the execution of the while on the
      same initial state terminates in the same final state *)


  Lemma for_while :
    forall (st st' : imp_state) (i : com) (b : bexp) (f c : com),
      st =[ for i ; b ; f do c ]=> st' ->
      st =[ i; while b do { c ; f } ]=> st'.
  Proof.
    intros st st' i b f c Heval.
    (* in order to do induction on the derivation Heval all of its
       arguments must be variables. For this reason
       we set a new variable [c'] with the value [for i ; b ; f do c ]
       and substitute it in the type of [Heval]. *)

    remember (<{ for i; b; f do c }>) as c' eqn:Heq.

    (* we generalize all variables that do not appear in [Heval] *)
    revert i b c f Heq.

    (* we do induction on the derivation [Heval] *)
    induction Heval.
    (*  ___ FILL IN HERE ___ *)
  Admitted.

  (* [for_while] bonus grade 0/5 *)


  (** To show the other direction, first prove that a
      while is equivalent to a for without an initialization command. *)

  Lemma while_for_aux :
    forall (st st' : imp_state) (i : com) (b : bexp) (f c : com),
      st =[ while b do { c ; f } ]=> st' ->
      st =[ for skip ; b ; f do c ]=> st'.
  Proof.
    intros st st' i b f c Heval.
    (* for the induction we follow the same technique as in the lemma above *)
    remember (<{ while b do { c ; f } }> ) as c' eqn:Heq.
    revert b c f Heq.
    induction Heval.
    (*  ___ FILL IN HERE ___ *)
  Admitted.

  (* [while_for_aux] bonus grade 0/4 *)


  (** Using the above lemma, we can show the final lemma. *)

  Lemma while_for :
    forall (st st' : imp_state) (i : com) (b : bexp) (f c : com),
      st =[ i; while b do { c ; f } ]=> st' ->
      st =[ for i ; b ; f do c ]=> st'.
  Proof.
    (*  ___ FILL IN HERE ___ *)
  Admitted.

  (* [while_for] bonus grade 0/1 *)

End ForLoops.
